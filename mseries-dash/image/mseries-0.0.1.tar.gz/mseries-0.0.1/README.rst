mseries
=======================

mseries is a tool for parsing various mongo related metrics.

Currently it only supports ftdc packages.

Getting started
---------------

First install mseries pip_:

::

    $ pip install mseries

.. _PyPM: http://code.activestate.com/pypm/
.. _pip: http://pip.openplans.org/


Write the archive to the URI endpoint with:

::

    $ python ./mseries/tools/main.py write --uri=$FTDC_URI ./metrics.2016-10-13T15-53-28Z-00000

List the contents of an archive with:

::

    $ python ./mseries/tools/main.py list  ./mongo/data/diagnostic.data/metrics.2016-10-08T18-55-52Z-00000


Credits
-------
