from mseries.utils import Logger, NameEncoder


class LatencyPipeline(Logger):
    """ calculate the latency from the replsetGetStatus"""

    def __init__(self, cfg=None, name=__name__):
        """Create a pipeline instance to calculate the lag from the metrics

        :Parameters:
          - `cfg`: the base configuration (for the name encoder)

        """
        Logger.__init__(self, name=name)
        self._cfg = cfg
        self._encoder = None

    @property
    def encoder(self):
        """ get a name encoder instances """
        if self._encoder is None:
            self._encoder = NameEncoder(self._cfg)
        return self._encoder

    def translate(self, measurement, values, out=None, memo=None):
        """For the server status measurement, get the replSetGetStatus date and compute difference
        between the replSetGetStatus[('date')] - replSetGetStatus[('members', 'X', 'lastHeartbeatRecv')]
        , and put the output in out

        :Parameters:
          - `measurement`: the measurement name
          - `values`: a dict of names / values
          - `out`: a dict to store the results in
          - `memo`: a dict of interesting metrics

        """
        # if measurement == 'replSetGetStatus':
        if measurement == 'serverStatus':
            memo = memo if memo is not None else {}
            out = out if out is not None else {}
            latencies = {}
            date_key = self.encoder.key_to_name((u'replSetGetStatus', u'date'))
            if date_key in values:
                date = values[date_key]
                for member in range(min(50, len(memo))):
                    key = self.encoder.key_to_name((u'replSetGetStatus', u'members', str(member), u'_id'))
                    if key in values:
                        key = self.encoder.key_to_name((u'replSetGetStatus', u'members', str(member), u'lastHeartbeatRecv'))
                        if key in values:
                            value = values[key]
                            delta = (date - value)
                            latencies[(u'replSetGetStatus', u'members', str(member), u'latency')] = delta
                            self.logger.debug("%s : %s %s (%s)", key, date, value, delta)
                    else:
                        break

            if latencies:
                out[u'latency'] = latencies
        return values
