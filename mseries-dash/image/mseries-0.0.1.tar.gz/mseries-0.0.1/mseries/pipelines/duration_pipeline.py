from mseries.utils import Logger, NameEncoder


class DurationPipeline(Logger):
    """ calculate the elapsed durations of the ftdc service calls"""

    def __init__(self, cfg=None, name=__name__):
        """Create a pipeline instance to get the durations from the metrics

        :Parameters:
          - `cfg`: the base configuration (for the name encoder)

        """
        Logger.__init__(self, name=name)
        self._cfg = cfg
        self._encoder = None

    @property
    def encoder(self):
        """ get a name encoder instances """
        if self._encoder is None:
            self._encoder = NameEncoder(self._cfg)
        return self._encoder

    def translate(self, measurement, values, out=None, memo=None):
        """For the server status measurement get the start / end times from
        memo (the positions were calculated by *flatten*), and put the output in
        out

        :Parameters:
          - `measurement`: the measurement name
          - `values`: a dict of names / values
          - `out`: a dict to store the results in
          - `memo`: a dict of interesting metrics

        """
        if measurement == 'serverStatus':
            out = out if out is not None else {}
            memo = memo if memo is not None else {}
            durations = {}
            rates = {}
            for key in memo:
                if key[-1] == u'start':
                    kfin = key[0:-1] + (u'end', )
                    fin = values[self.encoder.key_to_name(kfin)]
                    start = values[self.encoder.key_to_name(key)]
                    duration = fin - start
                    if key == (u'start', ):
                        okey = (u'total', )
                    else:
                        okey = key[0:-1]
                    durations[okey + (u'duration', )] = duration
                    rates[okey + (u'rate', )] = 1000.0 / duration if duration else 0
            if durations:
                self.logger.debug("durations %r", durations)
                out[u'durations'] = durations
                if durations[(u'total', u'duration')] > 2:
                    pass
            if rates:
                self.logger.debug("rates %r", rates)
                out[u'rates'] = rates
        return values
