from mseries.utils import Logger, NameEncoder


class LagPipeline(Logger):
    """ calculate the lag of the ftdc service calls"""

    def __init__(self, cfg=None, name=__name__):
        """Create a pipeline instance to calculate the lag from the metrics

        :Parameters:
          - `cfg`: the base configuration (for the name encoder)

        """
        Logger.__init__(self, name=name)
        self._cfg = cfg
        self._encoder = None

    @property
    def encoder(self):
        """ get a name encoder instances """
        if self._encoder is None:
            self._encoder = NameEncoder(self._cfg)
        return self._encoder

    def translate(self, measurement, values, out=None, memo=None):
        """For the server status measurement get the replSetGetStatus times from
        memo (the positions were calculated by *flatten*), and put the output in
        out

        :Parameters:
          - `measurement`: the measurement name
          - `values`: a dict of names / values
          - `out`: a dict to store the results in
          - `memo`: a dict of interesting metrics

        """
        # if measurement == 'replSetGetStatus':
        if measurement == 'serverStatus':
            memo = memo if memo is not None else {}
            out = out if out is not None else {}
            optimes = []
            last = None
            for member in range(min(50, len(memo))):
                key = ('replSetGetStatus', 'members', str(member), 'optimeDate')
                if key in memo:
                    optimes.append(values[self.encoder.key_to_name(key)])
                    last = member
                else:
                    break

            if last is not None:
                latest = max(optimes)
                lag = {}
                out[u'lag'] = lag
                for i, v in enumerate(optimes):
                    key = ('replSetGetStatus', 'members', str(i), 'lag')
                    if v != 0:
                        delta = (latest - v)
                        lag[key] = delta
                        self.logger.debug("%s : %s %s (%s)", key, latest, v, delta)
                    else:
                        # startup 2 or some such state
                        self.logger.debug("%s : startup2", key)
        return values
