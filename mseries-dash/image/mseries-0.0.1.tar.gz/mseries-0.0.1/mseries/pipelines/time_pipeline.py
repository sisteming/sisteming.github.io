from mseries.utils import Logger
from datetime import datetime, timedelta
from dateutil import tz


def to_datetime(ts, date):
    dt = datetime.strptime(ts, '%H:%M:%S')
    dt = dt.replace(year=date.year, month=date.month, day=date.day)
    dt = date.tzinfo.localize(dt)
    dt = dt.astimezone(tz.gettz('UTC')).replace(tzinfo=None)
    return dt


class TimePipeline(Logger):

    def __init__(self, cfg=None, name=__name__):
        Logger.__init__(self, name=name)
        self._configuration = cfg

    def translate(self, measurement, values, out=None, memo=None):
        out = out if out is not None else {}
        memo = memo if memo is not None else {}
        if measurement == u'mongostats':
            name = __name__
            state = memo.get(name, {})
            memo[name] = state
            date = memo.get(u'date', self._configuration.date)
            last = memo.get(u'last', None)
            time = values[u'time']
            timestamp = to_datetime(time, date)
            # rollover, deal with it
            if last is not None and last > timestamp:
                date += timedelta(days=1)
                timestamp += timedelta(days=1)
            out[u'last'] = timestamp
            out[u'date'] = date
            values.timestamp = timestamp
        return values
