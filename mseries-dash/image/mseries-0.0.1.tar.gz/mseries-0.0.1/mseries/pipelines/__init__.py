import importlib
from mseries.utils import Logger

logger = Logger.getLogger(__name__)

#
# the pipeline code will also copy missing keys from __dict__ from old to new objects instances,
# iff they are missing from the new instance. If they are not missing they are assumed to have been
# processed
#


# noinspection PyBroadException
class PipelineFactory(object):
    @staticmethod
    def get_class(name):
        m = __name__.split('.')
        m.append("{}_pipeline".format(name))
        m = '.'.join(m)
        clazz = "".join([p[:1].upper() + p[1:] for p in name.split("_")]) + "Pipeline"
        return getattr(importlib.import_module(m), clazz)

    @staticmethod
    def create(pipeline, opts, cfg):
        instances = []
        if pipeline:
            for p in pipeline:
                try:
                    clazz = PipelineFactory.get_class(p)
                    instances.append(clazz(cfg))
                except:
                    logger.warn("pipeline exception %s", p, exc_info=1)
        return instances


def run_pipeline(pipeline, measurement_name, values, out=None, memo=None):
    if pipeline:
        for element in pipeline:
            try:
                element.translate(measurement_name, values, out=out, memo=memo)
            except TypeError:
                logger.warn("run_pipeline exception %s", p, exc_info=1)
                pass
    # return values
