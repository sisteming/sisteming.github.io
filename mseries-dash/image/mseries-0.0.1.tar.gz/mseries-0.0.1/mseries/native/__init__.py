try:
    # noinspection PyUnresolvedReferences
    import mseries.native.rle
except ImportError:
    pass
