"""Bson Array reader support
"""

from mseries.types import Reader, DocReader


class ArrayReader(DocReader):
    """ Array reader is a type of document reader"""

    TYPE = Reader.T_ARRAY
    """ the TYPE value an array"""

    def read(self, buf, at):
        """read an array from the stream

        :Parameters:
          - `buf`: the buffer containing the array
          - `at`: the location to read from

        """
        _doc, at = DocReader.read(self, buf, at)
        doc = _doc.values()
        return doc, at

    def btype(self):
        """get the bson type"""
        return self.TYPE

    def size(self, buf, at):
        """get the size of an instance of this type

        :Parameters:
          - `buf`: the buffer containing the type
          - `at`: the location to read from

        """
        bson_len, _ = self.int32(buf, at)
        return bson_len

    @property
    def name(self):
        """ get the type name"""
        return 'array'


Reader.add(ArrayReader())
