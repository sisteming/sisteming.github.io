"""String type
"""

from mseries.types.reader import Reader


class StringReader(Reader):
    """ a reader for string data type"""

    TYPE = Reader.T_STRING
    """ the type value for a string """

    def read(self, buf, at):
        """read the data type from the stream

        :Parameters:
          - `buf`: the buffer containing the instance
          - `at`: the location to read from

        """
        l, at = self.uint32(buf, at)

        value = buf[at: at + l - 1]
        at += l
        return value, at

    def btype(self):
        """get the bson type"""
        return self.TYPE

    def size(self, buf, at):
        """get the size of an instance of this type

        :Parameters:
          - `buf`: the buffer containing the type
          - `at`: the location to read from

        """
        _, end = self.read(buf, at)
        return end - at

    @property
    def name(self):
        """get the type name"""
        return 'string'


Reader.add(StringReader())
