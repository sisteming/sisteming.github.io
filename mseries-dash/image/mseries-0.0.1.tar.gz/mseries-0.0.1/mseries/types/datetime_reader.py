"""Datetime type
"""

from mseries.types.reader import Reader
import datetime


class DateTimeReader(Reader):
    """ a reader for date time data type"""

    TYPE = Reader.T_DATETIME
    """ the type value for a date time """

    def read(self, buf, at):
        """read the data type from the stream

        :Parameters:
          - `buf`: the buffer containing the instance
          - `at`: the location to read from

        """
        _value, at = self.uint64(buf, at)
        value = datetime.datetime.utcfromtimestamp(_value / 1e3)
        return value, at

    def btype(self):
        """get the bson type"""
        return self.TYPE

    def size(self, buf, at):
        """get the size of an instance of this type

        :Parameters:
          - `buf`: the buffer containing the type
          - `at`: the location to read from

        """
        return self.SZ_DATETIME

    @property
    def name(self):
        """get the type name"""
        return 'datetime'


Reader.add(DateTimeReader())
