"""Bson Array reader support
"""
from collections import OrderedDict

ObjectId = str
Timestamp = OrderedDict
BinData = bytearray
NumberLong = int


class BSON(OrderedDict):

    def __init__(self, *args, **kwargs):
        OrderedDict.__init__(self, *args, **kwargs)

    def __getitem__(self, key):
        from mseries.utils.attr_value import AttrValue
        v = super(OrderedDict, self).__getitem__(key)
        if isinstance(v, AttrValue):
            v = v.value
            self[key] = v
        return v

    def get(self, k, d=None):
        try:
            return self[k]
        except KeyError:
            v = d
        return v
