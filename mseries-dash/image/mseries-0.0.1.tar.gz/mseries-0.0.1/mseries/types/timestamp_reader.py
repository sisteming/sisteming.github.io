"""Timestamp type
"""
from mseries.types import BSON, Reader


class TimestampReader(Reader):
    """ a reader for time stamp data type"""

    TYPE = Reader.T_TIMESTAMP
    """ the type value for a timestamp """

    def read(self, buf, at):
        """read the data type from the stream

        :Parameters:
          - `buf`: the buffer containing the instance
          - `at`: the location to read from

        """
        value = BSON()
        # seconds
        value['i'], at = self.uint32(buf, at)
        value['i'] = int(value['i'])

        # increment
        value['t'], at = self.uint32(buf, at)
        value['t'] = int(value['t'])
        return value, at

    def btype(self):
        """get the bson type"""
        return self.TYPE

    def size(self, buf, at):
        """get the size of an instance of this type

        :Parameters:
          - `buf`: the buffer containing the type
          - `at`: the location to read from

        """
        return self.SZ_TIMESTAMP

    @property
    def name(self):
        """get the type name"""
        return 'timestamp'


Reader.add(TimestampReader())
