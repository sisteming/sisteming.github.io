"""Double type
"""

from mseries.types.reader import Reader


class DoubleReader(Reader):
    """ a reader for double data type"""

    TYPE = Reader.T_DOUBLE
    """ the type value for double """

    def read(self, buf, at):
        """read the data type from the stream

        :Parameters:
          - `buf`: the buffer containing the instance
          - `at`: the location to read from

        """
        value, at = self.double(buf, at)
        return value, at

    def btype(self):
        """get the bson type"""
        return self.TYPE

    def size(self, buf, at):
        """get the size of an instance of this type

        :Parameters:
          - `buf`: the buffer containing the type
          - `at`: the location to read from

        """
        return self.SZ_DOUBLE

    @property
    def name(self):
        """get the type name"""
        return 'double'


Reader.add(DoubleReader())
