"""MaxKey type
"""

from mseries.types import Reader, combomethod


class MaxkeyReader(Reader):
    """ a reader for max key data type"""

    TYPE = Reader.T_MAXKEY
    """ the type value for maxkey """

    def read(self, buf, at):
        """read the data type from the stream

        :Parameters:
          - `buf`: the buffer containing the instance
          - `at`: the location to read from

        """
        value = None
        return value, at

    @combomethod
    def btype(self):
        """get the bson type"""
        return self.TYPE

    def size(self, buf, at):
        """get the size of an instance of this type

        :Parameters:
          - `buf`: the buffer containing the type
          - `at`: the location to read from

        """
        return 0

    @property
    def name(self):
        """get the type name"""
        return 'maxkey'


Reader.add(MaxkeyReader())
