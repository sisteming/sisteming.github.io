"""Int32 type
"""

from mseries.types.reader import Reader


class Int32Reader(Reader):
    """ a reader for int32 data type"""

    TYPE = Reader.T_INT32
    """ the type value for int32 """

    def read(self, buf, at):
        """read the data type from the stream

        :Parameters:
          - `buf`: the buffer containing the instance
          - `at`: the location to read from

        """
        value, at = self.int32(buf, at)
        return value, at

    def btype(self):
        """get the bson type"""
        return self.TYPE

    def size(self, buf, at):
        """get the size of an instance of this type

        :Parameters:
          - `buf`: the buffer containing the type
          - `at`: the location to read from

        """
        return self.SZ_INT32

    @property
    def name(self):
        """get the type name"""
        return 'int32'


Reader.add(Int32Reader())
