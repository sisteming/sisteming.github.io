"""Document type
"""

from mseries.types import BSON, Reader


class DocReader(Reader):
    """ a reader for document data type"""

    TYPE = Reader.T_DOC
    """ the type value for a document """

    def read(self, buf, at):
        """read the data type from the stream

        :Parameters:
          - `buf`: the buffer containing the instance
          - `at`: the location to read from

        """
        doc = BSON()
        doc_len, at = self.int32(buf, at)
        self.logger.debug("buf[%d] len %d %04x", at, doc_len, doc_len)
        doc.bson_len = doc_len
        doc_end = at + doc_len - 4
        bson_type = None
        while at < doc_end:
            bson_type, at = self.byte(buf, at)
            self.logger.debug("\tbuf[%d]= Type  %d", at, bson_type)
            if bson_type == Reader.T_EOO:
                break

            name, at = self.cstring(buf, at)
            self.logger.debug("\tbuf[%d]=  name '%s'", at, name)
            reader = Reader.find(bson_type)
            if reader is not None:
                value, at = reader.read(buf, at)
            else:
                raise Exception('unknown type %d(%x) at %d(%x)' % (bson_type, bson_type, at, at))

            if value is not None:
                doc[name] = value

        if bson_type != Reader.T_EOO:
            # should have seen an eoo and returned
            assert (not 'eoo not found')
        return doc, at

    def btype(self):
        """get the bson type"""
        return self.TYPE

    def size(self, buf, at):
        """get the size of an instance of this type

        :Parameters:
          - `buf`: the buffer containing the type
          - `at`: the location to read from

        """
        bson_len, _ = self.int32(buf, at)
        return bson_len

    @property
    def name(self):
        """get the type name"""
        return 'doc'


Reader.add(DocReader())
