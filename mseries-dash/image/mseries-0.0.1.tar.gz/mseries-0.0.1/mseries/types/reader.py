"""Reader base class and registry functionality
"""

import struct
from mseries import EOS
from mseries.utils import Logger
from mseries.types import BSON, combomethod



class BsonType:
    """ Wrapper class for type lookups to access the readers"""

    def __init__(self, bson_type, name):
        """create a type wrapper instance

        :Parameters:
          - `bson_type`: the actual bson type values look http://bsonspec.org/spec.html or
          https://docs.mongodb.com/manual/reference/mongodb-extended-json/ for more details
          - `name`: the bson type name (ie. ObjectId BinData etc.)

        """
        self._bson_type = bson_type
        self._name = name

    @property
    def bson_type(self):
        """ get the bson type """
        return self._bson_type

    def __repr__(self):
        """ string representation (the name) """
        return self._name

    def __str__(self):
        """ string representation (the name) """
        return self._name

    def __int__(self):
        """ the bson type """
        return self._bson_type


# noinspection PyMethodMayBeStatic
class Reader(Logger):
    """ reader base class for an arbitrary data type"""

    K_INT32 = struct.Struct('<i')
    """ definition for int 32 """

    K_UINT32 = struct.Struct('<I')
    """ definition for unsigned int 32 """

    K_INT64 = struct.Struct('<q')
    """ definition for int 64 """

    K_UINT64 = struct.Struct('<Q')
    """ definition for unsigned int 64 """

    K_DOUBLE = struct.Struct('<d')
    """ definition for double """

    SZ_BYTE = 1
    """ the size of a byte """

    SZ_INT32 = 4
    """ the size of an int 32 """

    SZ_UINT32 = 4
    """ the size of an unsigned int 32  """

    SZ_INT64 = 8
    """ the size of an int 64  """

    SZ_UINT64 = 8
    """ the size of an unsigned int 64 """

    SZ_DOUBLE = 8
    """ the size of a double"""

    SZ_TIMESTAMP = 8
    """ the size of a timestamp """

    SZ_DATETIME = 8
    """ the size of a date time """

    SZ_OBJECT_ID = 12
    """ the size of an object id """

    T_EOO = BsonType(0, "eoo")
    """ singleton eoo bson type instance """

    T_DOUBLE = BsonType(1, "double")
    """ singleton double bson type instance """

    T_STRING = BsonType(2, "string")
    """ singleton string bson type instance """

    T_DOC = BsonType(3, "object")
    """ singleton object bson type instance """

    T_ARRAY = BsonType(4, "array")
    """ singleton array bson type instance """

    T_BINDATA = BsonType(5, "binData")
    """ singleton binData bson type instance """

    T_OBJECT_ID = BsonType(7, "objectId")
    """ singleton objectId bson type instance """

    T_BOOL = BsonType(8, "boolean")
    """ singleton boolean bson type instance """

    T_DATETIME = BsonType(9, "date")
    """ singleton date bson type instance """

    T_NULL = BsonType(10, "null")
    """ singleton null bson type instance """

    T_INT32 = BsonType(16, "int32")
    """ singleton int32 bson type instance """

    T_TIMESTAMP = BsonType(17, "timestamp")
    """ singleton timestamp bson type instance """

    T_INT64 = BsonType(18, "int64")
    """ singleton int64 bson type instance """

    T_MINKEY = BsonType(0xff, "MinKey")
    """ singleton MinKey bson type instance """

    # noinspection SpellCheckingInspection
    T_MAXKEY = BsonType(0x7f, "MaxKey")
    """ singleton MaxKey bson type instance """

    LOOKUP = {}
    """ the lookup for types """

    def ignore(self, ftdc):
        """ should this be ignored (probably not still used) """
        return False

    def transform(self, value, ftdc):
        """transform this value

        :Parameters:
          - `value`: the value to xform

        """
        return value

    @classmethod
    def add(cls, reader):
        """add the reader instance by type and int type

        :Parameters:
          - `reader`: the reader instance to register

        """
        Reader.LOOKUP[reader.btype()] = reader
        Reader.LOOKUP[int(reader.btype())] = reader

    @classmethod
    def find(cls, bson_type):
        """find the reader by it's type

        :Parameters:
          - `bson_type`: the bson spec byte type

        """
        return Reader.LOOKUP.get(bson_type, None)

    def __init__(self):
        """ Reader constructor"""
        Logger.__init__(self, name=__name__)

    def read(self, buf, at):
        """read the data type from the stream

        :Parameters:
          - `buf`: the buffer containing the instance
          - `at`: the location to read from

        """
        raise NotImplementedError("Please Implement this method")

    def btype(self):
        """ get the bson type for the reader """
        raise NotImplementedError("Please Implement this method")

    def size(self, buf, at):
        """get the size of an instance of this type

        :Parameters:
          - `buf`: the buffer containing the type
          - `at`: the location to read from

        """
        raise NotImplementedError("Please Implement this method")

    @combomethod
    def int32(self, buf, at):
        """read an int32 from this point in the stream

        :Parameters:
          - `buf`: the buffer
          - `at`: the location in the buffer

        :Returns:

            # the (v, at), the value read and the new read location

        """
        v = self.K_INT32.unpack_from(buf, at)[0]
        at += Reader.SZ_INT32
        return v, at

    @combomethod
    def uint32(self, buf, at):
        """read an unsigned int32 from this point in the stream

        :Parameters:
          - `buf`: the buffer
          - `at`: the location in the buffer

        :Returns:

            # the (v, at), the value read and the new read location

        """
        v = self.K_UINT32.unpack_from(buf, at)[0]
        at += Reader.SZ_UINT32
        return v, at

    @combomethod
    def int64(self, buf, at):
        """read an int64 from this point in the stream

        :Parameters:
          - `buf`: the buffer
          - `at`: the location in the buffer

        :Returns:

            # the (v, at), the value read and the new read location

        """
        v = self.K_INT64.unpack_from(buf, at)[0]
        at += Reader.SZ_INT64
        # return long(v), at
        return v, at

    @combomethod
    def uint64(self, buf, at):
        """read an unsigned int64 from this point in the stream

        :Parameters:
          - `buf`: the buffer
          - `at`: the location in the buffer

        :Returns:

            # the (v, at), the value read and the new read location

        """
        v = self.K_UINT64.unpack_from(buf, at)[0]
        at += Reader.SZ_UINT64
        return v, at

    @combomethod
    def double(self, buf, at):
        """read a double from this point in the stream

        :Parameters:
          - `buf`: the buffer
          - `at`: the location in the buffer

        :Returns:

            # the (v, at), the value read and the new read location

        """
        v = self.K_DOUBLE.unpack_from(buf, at)[0]
        at += Reader.SZ_DOUBLE
        return v, at

    @combomethod
    def byte(self, buf, at):
        """read a byte from this point in the stream

        :Parameters:
          - `buf`: the buffer
          - `at`: the location in the buffer

        :Returns:

            # the (v, at), the value read and the new read location

        """
        v = ord(buf[at])
        at += Reader.SZ_BYTE
        return v, at

    # NULL = '\0'.encode("ascii")

    @combomethod
    def cstring(self, buf, at):
        """read a cstring (nul terminated) from this point in the stream. Strictly speaking
        this will not be in a stream for a value, only for an attribute name

        :Parameters:
          - `buf`: the buffer
          - `at`: the location in the buffer

        :Returns:

            # the (v, at), the value read and the new read location

        """
        name_end = buf.find(EOS, at)
        v = buf[at: name_end]
        at = name_end + 1
        return v, at

    @combomethod
    def string(self, buf, at):
        """read a string (unsigned int 32 + data) from this point in the stream.

        :Parameters:
          - `buf`: the buffer
          - `at`: the location in the buffer

        :Returns:

            # the (v, at), the value read and the new read location

        """
        l, at = self.uint32(buf, at)
        v = buf[at: at + l - 1]
        at += l
        return v, at

    @combomethod
    def bindata(self, buf, at):
        """read a bindata (unsigned int 32 + data) from this point in the stream.

        :Parameters:
          - `buf`: the buffer
          - `at`: the location in the buffer

        :Returns:

            # the (v, at), the value read and the new read location

        """
        l, at = self.uint32(buf, at)
        at += 1
        v = buf[at:at + l]
        at += l
        return v, at

    @combomethod
    def object_id(self, buf, at):
        """read an object id from this point in the stream.

        :Parameters:
          - `buf`: the buffer
          - `at`: the location in the buffer

        :Returns:

            # the (v, at), the value read and the new read location

        """
        v = buf[at:at + Reader.SZ_OBJECT_ID]
        at += Reader.SZ_OBJECT_ID
        return v, at

    @combomethod
    def datetime(self, buf, at):
        """read a datetime from this point in the stream.

        :Parameters:
          - `buf`: the buffer
          - `at`: the location in the buffer

        :Returns:

            # the (v, at), the value read and the new read location

        """
        v, at = self.uint64(buf, at)
        return v, at

    @combomethod
    def timestamp(self, buf, at):
        """read a timestamp from this point in the stream.

        :Parameters:
          - `buf`: the buffer
          - `at`: the location in the buffer

        :Returns:

            # the (v, at), the value read and the new read location

        """
        v = BSON()
        v['i'], at = self.uint32(buf, at)  # increment
        v['i'] = int(v['i'])

        v['t'], at = self.uint32(buf, at)  # second
        v['t'] = int(v['t'])
        return v, at
