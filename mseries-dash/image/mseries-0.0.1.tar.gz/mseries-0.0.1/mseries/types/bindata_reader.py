"""BinData type
"""

from mseries.types import Reader, BinData


class BindataReader(Reader):
    """ a reader for binary data type"""

    TYPE = Reader.T_BINDATA
    """ the type value for bin data """

    def read(self, buf, at):
        """read the data type from the stream

        :Parameters:
          - `buf`: the buffer containing the instance
          - `at`: the location to read from

        """
        l, at = self.uint32(buf, at)
        at += 1
        value = BinData(buf[at: at + l])
        at += l
        return value, at

    def btype(self):
        """get the bson type"""
        return self.TYPE

    def size(self, buf, at):
        """get the size of an instance of this type

        :Parameters:
          - `buf`: the buffer containing the type
          - `at`: the location to read from

        """
        l, _ = self.uint32(buf, at)
        return l + 4 + 1

    @property
    def name(self):
        """get the type name"""
        return 'bindata'


Reader.add(BindataReader())