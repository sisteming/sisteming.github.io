from mseries.py3k import PY3K, EOS
import mseries.archive
import mseries.io_stat
import mseries.backup_agent
import mseries.server_status
import mseries.mongo_stat
import mseries.ftdc

__author__ = 'jim.oleary@gmail.com'
__version__ = '0.0.1'
version = __version__
