"""
Classes representing FTDC chunks
"""
from mseries.archive import Archive
from mseries.types import BSON, Reader, EooReader
from mseries.ftdc.ftdc_metrics import FtdcMetrics, FtdcMeasurement
from mseries.utils import AttrValue, Logger, to_timestamp, lookup, to_millis
import hexdump
import mmap


class ChunkMemo(Logger):
    """A chunk flyweight
    """

    def __init__(self, at=None, identifier=None, category=None, doc=None, filename=None, bson_len=None):
        """Create a chunk flyweight that can be passed to process (on the same host).

        :Parameters:
          - `at`: a reference to the chunk location
          - `identifier`: the chunk identifier, in this case the start time
          - `category`: the chunk category / type
          - `doc`: the chunk doc
          - `filename`: the archive filename
          - `bson_len`: the size of this chunk
        """
        Logger.__init__(self, name=__name__)
        self._at = at
        self._identifier = identifier
        self._category = category
        self._bson_len = bson_len
        self._doc = doc
        self._filename = filename

    @property
    def identifier(self):
        """the chunk identifier
        """
        return self._identifier

    @property
    def category(self):
        """the chunk category / type
        """
        return self._category

    @property
    def doc(self):
        """the chunk doc, the actual contents vary depending on the category
        """
        return self._doc

    @property
    def filename(self):
        """the filename that the chunk was read from (the start location is also required)
        """
        return self._filename

    @property
    def at(self):
        """the location of the chunk  within the file
        """
        return self._at

    @property
    def bson_len(self):
        """the length of the chunk within the file
        """
        return self._bson_len

    def from_memo(self):
        """rehydrate the chunk from this flyweight
        """
        return FtdcChunk(None, None, memo=self)


class FtdcChunk(Logger):
    """
    A class representing an FTDC chunk
    """

    def __init__(self, buf, at, filename=None, memo=None):
        """Create a chunk instance.

        :Parameters:
          - `buf`: a reference to the chunk data
          - `at`: a reference to the chunk location
          - `filename`: the chunk filename
          - `memo`:  a flyweight holding the chunk state, if memo is not None
                then this state is used to rehydrate the chunk instance

        """
        Logger.__init__(self, name=__name__)
        self._doc = None
        self._measurements = None
        if memo:
            self._buf = None
            self._at = memo.at
            self._start = memo.at
            self._filename = memo.filename
            self._bson_len = memo.bson_len
            self._doc = memo.doc
        else:
            self._buf = buf
            self._at = at
            self._start = at
            self._filename = filename
            self._bson_len, self._at = Reader.int32(self._buf, self._start)
        self._metrics = None
        self._timestamp = None
        self._timestamps = None
        self._identifier = None
        self._category = None

    def tags(self, cfg, doc):
        """get the tags for a chunk

        :Parameters:
          - `cfg`: the configuration as defined by the command line invocation
          - `doc`: the document to read tags from
        """
        self.logger.debug("%s", cfg)
        t = ((u'project', cfg.project),
             (u'hostname', lookup(doc, (u'hostInfo', u'system', u'hostname')) or
              lookup(doc, (u'serverStatus', u'host'))),
             (u'version', lookup(doc, (u'buildInfo', u'version')) or
              lookup(doc, (u'serverStatus', u'version'))),
             (u'memSizeMB', lookup(doc, (u'hostInfo', u'system', u'memSizeMB'))),
             (u'numCores', lookup(doc, (u'hostInfo', u'system', u'numCores'))),
             (u'numaEnabled', lookup(doc, (u'hostInfo', u'system', u'numaEnabled'))),
             (u'os', lookup(doc, (u'hostInfo', u'os'))),
             )
        tags = (kv for kv in t if kv[-1] is not None)
        return BSON(tags)

    def from_memo(self):
        """stub to get instance from memo, just returns self
        """
        return self

    @property
    def memo(self, ref=True):
        """create a flyweight
        """
        return ChunkMemo(at=self._start, identifier=self['_id'], category=self['type'], doc=None if ref else self._doc,
                         filename=self._filename, bson_len=self._bson_len)

    @property
    def filename(self):
        """the filename that the chunk was read from (the start location is also required)
        """
        return self._filename

    @property
    def buf(self):
        """the buffer containing the chunk datga
        """
        return self._buf

    @property
    def type_str(self):
        """the string representing the category / type of this chunk
        """
        if self['type'] == 0:
            return 'metadata'
        else:
            return 'metrics'

    @property
    def timestamp(self, fmt="%Y-%m-%dT%H:%M:%S"):
        """get the chunk timestamp

        :Parameters:
          - `fmt`: the timestamp format defaults to *%Y-%m-%dT%H:%M:%S*
        """
        if self._timestamp is None:
            self._timestamp = to_timestamp(self.identifier, fmt=fmt)
        return self._timestamp

    @property
    def timestamps(self):
        """get all the chunk timestamps (serverStatus.start in this case)

        :Parameters:
          - `fmt`: the timestamp format defaults to *%Y-%m-%dT%H:%M:%S*
        :Returns:
          the long timestamps
        """
        if self._timestamps is None:
            timestamps = (to_millis(self.identifier),)
            if self.metrics:
                self.metrics.config = self.config
                self._timestamps = timestamps + self.metrics.timestamps
            else:
                self._timestamps = timestamps
        return self._timestamps

    @property
    def identifier(self):
        """get the chunk _id
        """
        if self._identifier is None:
            self._identifier = self['_id']
        return self._identifier

    @property
    def description(self):
        """the chunk description
        """
        return "Ftdc data; {} samples of {} metrics".format(self.metrics.nsamples, self.metrics.nmetrics)

    @property
    def category(self):
        """get the chunk type / category
        """
        if self._category is None:
            # TODO change name to category
            self._category = self['type']
        return self._category

    @property
    def metrics(self):
        """get the metrics from this chunk
        """
        if self._metrics is None:
            data = self.get('data', None)
            if data:
                self._metrics = FtdcMetrics(data, self._filename, self._at)
        return self._metrics

    def to_progress(self, l):
        """get a representation of this chunk to use in the progress

        :Parameters:
          - `l`: the max length for the progress
        """
        return to_timestamp(self.identifier)[0:l - 1]

    @property
    def doc(self):
        """get the document for this chunk
        """
        if self._doc is None:
            # open and map file
            with open(self._filename) as f:
                self._buf = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
                bson_len, self._at = Reader.int32(self._buf, self._start)
                assert bson_len == self._bson_len
                self._doc = self.read()

        return self._doc

    @property
    def bson_len(self):
        """get the length of this chunk
        """
        return self._bson_len

    @property
    def start(self):
        """get the starting offset of this chunk
        """
        return self._start

    def hexdump(self):
        """get a hex representation of this chunk
        """
        return hexdump.hexdump(self._buf[self._start:self._start + self.bson_len], result='return')

    @property
    def at(self):
        """get the current location within the buf
        """
        return self._at

    @at.setter
    def at(self, v):
        """set the current location

        :Parameters:
          - `v`: the new location
        """
        self._at = v

    def __getitem__(self, key):
        """get item from doc (evaluating if it is lazy)

        :Parameters:
          - `key`: the property name
        """
        v = self.doc[key]
        if isinstance(v, AttrValue):
            v = v.value
            self.doc[key] = v
        return self.doc[key]

    def get(self, key, d):
        """get item from doc or d (evaluating if it is lazy)

        :Parameters:
          - `key`: the property name
          - `d`: the default value
        """
        try:
            return self.__getitem__(key)
        except KeyError:
            return d

    def __repr__(self):
        """get a string representation of the chunk
        """
        return repr(self.doc)

    def read(self):
        """read the values from the buffer. This method is lazy, it will skip
        over values until they are explicitly read
        """
        doc = BSON()
        doc_end = self._start + self.bson_len
        while self.at < doc_end:
            av = AttrValue(self.buf, self.at, fn=self._filename)
            self.at += av.size
            self.logger.debug("read '%s' %s(%s)", av.name, Reader.find(av.bson_type).TYPE, av.bson_type)
            if av.bson_type == int(EooReader.btype()):
                break

            doc[av.name] = av

        return doc

    # hmm mutable look at frozen set
    MEASUREMENTS = map(FtdcMeasurement, [(Archive.METADATA_NAME, u'start',),
                                         (Archive.REFERENCE_SAMPLE_NAME, u'start',),
                                         Archive.SERVER_STATUS_NAME, u'local.oplog.rs.stats',
                                         u'replSetGetStatus', u'systemMetrics'])

    # noinspection PyMethodMayBeStatic
    @classmethod
    def measurements(cls):
        """get the list of measurements

        :rtype: list
        """
        return cls.MEASUREMENTS

    @classmethod
    def measurement(cls, name):
        """find the named measurement

        :Parameters:
          - `name`: the measurement to find
        """
        return next((m for m in cls.measurements() if m.name == name), None)
