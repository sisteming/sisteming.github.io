import os
import zlib
import threading
from collections import OrderedDict
import mseries.tools
import mseries.utils
from mseries.utils import AttrValue, Logger, RLEncoder, NameEncoder, update
from mseries.types import DocReader, Reader, BSON
from mseries.archive import Archive, AbstractMatcher


class FtdcMeasurement(AbstractMatcher):
    """Ftdc measurement types.
    """
    def __init__(self, name, key=None):
        """create a new holder for a measurement

        :Parameters:
          - `name`: a name or tuple (of the name and the start name)
          - `key`: not really used
        """
        if isinstance(name, (tuple,)):
            self._timestamp = name[1]
            name = name[0]
        else:
            self._timestamp = tuple([name, u'start'])

        AbstractMatcher.__init__(self, name)
        if key is None:
            self._key = name

    def timestamp(self):
        """get the name of the timestamp field
        """
        return self._timestamp


class FtdcMetrics(Logger):
    """A class representing a metrics bundle. This is decoded from a chunk of the correct type / category.

    The metrics are contained in the buffer (which is zlib compressed). The buffer has:
        * a bson encoded reference sample (which has a bson length)
        * a Run Length encoded matrix of samples. The samples are arranged in rows of
          samples (for each type, for example serverStatus.start are all in a row).
    """
    HOSTNAME = ('serverStatus', 'host')
    """The hostname key """

    VERSION = ('serverStatus', 'version')
    """The version key """

    PID = ('serverStatus', 'pid')
    """The PID key """

    START = ('serverStatus', 'start')
    """The start key """

    def __init__(self, data, fn, at):
        """Create a metrics instance

        :Parameters:
          - `data`: a buffer containing the ftdc metrics
          - `fn`: the filename of the container archive / chunk
          - `at`: the location in the file
        """
        Logger.__init__(self, name=__name__)
        self._data = buffer(data) if data else None
        # need to come back to this, decompress and hexdump expect a string
        # but python 3 does not seem to?
        if isinstance(self._data, bytearray):
            self._data = str(self._data)
        self._fn = fn
        self._at = at
        self._metrics = None
        self._decompress = None
        self._decompressed = False
        self._nmetrics = None
        self._ndeltas = None
        self._doc = None
        self._full_doc = None
        self._lock = threading.RLock()
        self._doc_len = None
        self._nsamples = None
        self._measurements = None
        self._config = None
        self._encoder = None
        self._locations = None

    @property
    def encoder(self):
        """ the name encoder property """
        if self._encoder is None:
            self._encoder = NameEncoder(self.config)
        return self._encoder

    @property
    def config(self):
        """ the config property"""
        return self._config

    @config.setter
    def config(self, config):
        self._config = config

    @property
    def description(self):
        """ the description of this metric"""
        return "Ftdc data; {} samples of {} metrics".format(self.nsamples, self.nmetrics)

    # noinspection PyMethodMayBeStatic
    def flatten(self, doc, out, locations=None):
        """flatten the metrics doc, putting the key (tuple) and values in **out** (also returned), with the
        interesting types and names in locations (for quick access later)

        :Parameters:
          - `doc`: the reference sample metrics document
          - `out`: the dict to put the flattened names / values in
          - `locations`: the location of the measurements in the array
        """
        return mseries.utils.flatten(doc, out, measurements=locations)

    @property
    def metrics(self):
        """ read the metrics from the reference sample that are incrementable (non strings / object ids etc.)

        :Returns: dict or None
        """
        with self._lock:
            if self.data and self._metrics is None:
                self._locations = {}
                self._metrics = self.flatten(self.doc, OrderedDict(), locations=self._locations)
        return self._metrics

    @property
    def timestamps(self):
        """ read the metrics from the reference sample that are incrementable (non strings / object ids etc.)
        this tuple includes the first value in the metrics prototype

        :rtype: dict
        """
        with self._lock:
            for name, values in self.iproperties():
                if name == (u'serverStatus', u'start'):
                    return (self.metrics[(u'serverStatus', u'start')], ) + values
            return ()

    @property
    def locations(self):
        """ get the measurement locations, also reads the metrics from the reference sample """
        _ = self.metrics
        return self._locations

    @property
    def data(self):
        """ get the buffer containing the metrics """
        return self._data

    @property
    def decompress(self):
        """ decompress the buffer containing the metrics """
        if self.data and not self._decompress:
            # skip uncompressed length, we don't need it
            data = self.data[4:]
            self._decompress = zlib.decompress(data)
        return self._decompress

    def keys(self):
        """ get the reference sample incrementable metrics """
        _ = self.metrics
        return self.metrics.keys()

    @property
    def doc(self):
        """ read the reference sample from the compressed buffer """
        with self._lock:
            if not self._doc:
                self.logger.debug("\n reading doc ")

                # read reference doc from chunk data, ignoring non-metric fields
                # typed here the lazy read does not need to be typed (the AttrValue knows the type anyway)
                ref_doc = self._read(self.decompress, 0,
                                     fn="{}:0x{:08X}:<decompress>".format(os.path.basename(self._fn), self._at))
                # self.logger.debug("\n%s", json.dumps(ref_doc, indent=2, default=JsonTranslater.translate))
                self._doc = ref_doc
        return self._doc

    @staticmethod
    def _read(buf, at, fn='<decompress>'):
        """read a document from *buf*, start from *at*

        :Parameters:
          - `buf`: the buffer containing the doc
          - `at`: the start location within the buffer
          - `fn`: an identifier
        """
        doc_len, _ = Reader.int32(buf, at)
        doc_end = at + doc_len
        doc = BSON()
        at += 4
        while at < doc_end:
            av = AttrValue(buf, at, fn=fn)
            at += av.size
            if av.bson_type == int(Reader.T_EOO):
                break

            doc[av.name] = av

        return doc

    @property
    def nsamples(self):
        """ get the number of samples in the metrics. This is the number of deltas + 1.
        The extra is for the ref sample"""
        if self._nsamples is None:
            self._nsamples = self.ndeltas + 1
        return self._nsamples

    @property
    def doc_len(self):
        """ get the length of the reference sample, which is a uint32 at location 0 in the decompressed buffer

        :rtype: int
        """
        if self._doc_len is None:
            self._doc_len, _ = DocReader.uint32(self.decompress, 0)
        return self._doc_len

    @property
    def nmetrics(self):
        """ get the number of metrics in the sample. This is the uint32 at location *self.doc_len* """
        if self._nmetrics is None:
            self._nmetrics, _ = DocReader.uint32(self.decompress, self.doc_len)
        return self._nmetrics

    @property
    def ndeltas(self):
        """ get the number of deltas in the sample. This is the uint32 at location *self.doc_len* + 4
        :rtype: int
        """
        if self._ndeltas is None:
            self._ndeltas, _ = DocReader.uint32(self.decompress, self.doc_len + 4)
        return self._ndeltas

    # noinspection PyUnusedLocal
    def _decorate(self, m, names, values, others, locations, pipeline):
        # doc = others.copy()
        # for i, n in enumerate(names):
        #     doc[n] = values[i]
        doc = OrderedDict(zip(names, values))
        out = OrderedDict()
        pipeline(m.name, doc, out=out, memo=locations)
        for k, v in out.items():
            m = {self.encoder.key_to_name(k): v for k, v in out[k].items()}
            doc.update(m)
        return doc

    # noinspection PyUnusedLocal
    def idecode(self, first_only=False, ftdc=False, measurements=None, pipeline=None, rate=1):
        """decode flattened documents from the metrics data

        :Parameters:
          - `first_only`: just get the first one
          - `ftdc`: get the ftdc samples only (not used but may be should be)
          - `measurements`: the measurements (not used but may be should be)
          - `pipeline`: a pipeline method to run to synthesize some further metrics like the lag
          - `rate`: the sample rate. 1 == all sample, 10 = 1 in 10 or 10%, etc.
        """

        # TODO read from measurements param (maybe or remove the param)
        ss = self.measurement(Archive.SERVER_STATUS_NAME)

        if not self._decompressed:
            names = (self.encoder.key_to_name(k) for k in self.metrics.keys())
            yield ss, self._decorate(ss, names, self.metrics.values(), OrderedDict(),
                                     self.locations, pipeline)
            if not first_only and self.ndeltas:

                buf = self.decompress
                # skip the doc, nmetrics and ndeltas
                start = self.doc_len + 4 + 4

                rle = RLEncoder(buf, start, self.config, ndeltas=self.ndeltas, metrics=self.metrics)
                if self.nmetrics != len(rle.names):
                    # xxx remove when SERVER-20602 is fixed
                    self.logger.warn('ignoring bad chunk: nmetrics=%d, i=%d, len(metrics)=%d', self.nmetrics,
                                     len(rle.names), len(self.metrics))
                    return
                for names, values, others in rle.xunpack(rate=rate):
                    yield ss, self._decorate(ss, names, values, others, self.locations, pipeline)

                # TODO fix for sample rate != 1
                # assert (rle.at == len(buf))

                self._decompressed = True
                self._decompress = None
            else:
                pass

    def idocs(self, first_only=False, rate=1):
        """decode documents from the metrics data

        :Parameters:
          - `first_only`: just get the first one
          - `ftdc`: get the ftdc samples only (not used but may be should be)
          - `pipeline`: a pipeline method to run to synthesize some further metrics like the lag
          - `rate`: the sample rate. 1 == all sample, 10 = 1 in 10 or 10%, etc.
        """

        # TODO read from measurements param (maybe or remove the param)
        ss = self.measurement(Archive.SERVER_STATUS_NAME)

        if not self._decompressed:
            yield ss, self.metrics
            if not first_only and self.ndeltas:

                buf = self.decompress
                if buf:
                    # skip the doc, nmetrics and ndeltas
                    start = self.doc_len + 4 + 4

                    rle = RLEncoder(buf, start, self.config, ndeltas=self.ndeltas, metrics=self.metrics)
                    if self.nmetrics != len(rle.names):
                        # xxx remove when SERVER-20602 is fixed
                        self.logger.warn('ignoring bad chunk: nmetrics=%d, i=%d, len(metrics)=%d', self.nmetrics,
                                         len(rle.names), len(self.metrics))
                        return

                    for names, values, others in rle.xunpack(rate=rate):
                        doc = dict(self.metrics)
                        for i, name in enumerate(names):
                            update(doc, names, values[i])
                        yield ss, doc

                    # TODO fix for sample rate != 1
                    # assert (rle.at == len(buf))

                self._decompressed = True
                self._decompress = None
            else:
                pass

    def iproperties(self, rate=1):
        """get the samples by properties (that is, not transposed)

        :Parameters:
          - `rate`: the sample rate, 1 => all, -1 => first and last only. Otherwise, it returns
          that sample.
        """

        buf = self.decompress
        if buf and self.ndeltas:
            rle = RLEncoder(buf, self.doc_len + 4 + 4, self.config, ndeltas=self.ndeltas, metrics=self.metrics)
            if self.nmetrics != len(rle.names):
                # xxx remove when SERVER-20602 is fixed
                self.logger.warn('ignoring bad chunk: nmetrics=%d, i=%d, len(metrics)=%d', self.nmetrics,
                                 len(rle.names), len(self.metrics))
                return
            names = iter(rle.incrementables)
            for values in rle.xunpack(rate=rate, transpose=False):
                yield next(names), values

    # noinspection PyMethodMayBeStatic
    def measurements(self):
        """get the list of measurements

        :rtype: list
        """
        return mseries.ftdc.FtdcChunk.measurements()
    #     if self._measurements is None:
    #         # u'MetricChunk' contains the binary data to be decompressed
    #         v = [(Archive.METADATA_NAME, u'start', ),
    #              (Archive.REFERENCE_SAMPLE_NAME, u'start', ),
    #              Archive.SERVER_STATUS_NAME, u'local.oplog.rs.stats',
    #              u'replSetGetStatus', u'systemMetrics']
    #         self._measurements = map(FtdcMeasurement, v)
    #     return self._measurements
    #
    def measurement(self, name):
        """find the named measurement

        :Parameters:
          - `name`: the measurement to find
        """
        return mseries.ftdc.FtdcChunk.measurement(name)
    #     return next((m for m in self.measurements() if m.name == name), None)
