"""
Access an FTDC archive.
The archive is read as a series of chunks yielded to the caller.
"""

import mmap
from mseries.archive import Archive
import mseries.ftdc


class FtdcArchiveMemo(object):
    """
    A flyweight object that can be passed around to sub processes (only on the same
    host at the moment).
    The flyweight tracks the filename and the configuration with
    which it was invoked
    """

    def __init__(self, archive):
        """Create a flyweight that can be sent to a sub process.

        :Parameters:
          - `archive`: The :class:`~mseries.ftdc.FtdcArchive` instance to dehydrate (for use in another process)

        """
        self._filename = archive.filename
        # noinspection PyProtectedMember
        self._configuration = archive.configuration._asdict()

    def from_memo(self):
        """Create an archive object instance from the flyweight.
        """
        clazz = FtdcArchive
        from mseries.tools.utils import configuration
        archive = clazz(self._filename)
        archive.configuration = configuration(self._configuration)
        return archive

    @property
    def identifier(self):
        """get the identifier for the archive (the filename in this case)
        """
        return self._filename

    @property
    def filename(self):
        """get the archive file name
        """
        return self._filename

    @property
    def category(self):
        """get the type / category of this object
        """
        return 1


class FtdcArchive(Archive):
    """"
    An FTDC archive is the top level file / configuration. This archive
    contains a series of chunks.
    """

    def __init__(self, fn):
        """Create an FTDC Archive instance representing the file

        :Parameters:
          - `fn`: The archive filename

        """
        Archive.__init__(self, name=__name__)
        self._fn = fn
        self._buf = None
        self._at = None

    @property
    def filename(self):
        """the archive filename
        """
        return self._fn

    @property
    def buf(self):
        """get a reference to the buffer containing the raw archive data, when opened
        the location will be set to 0 (ie. start of the archive)
        """
        if not self._buf:
            f = open(self._fn)
            self._buf = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
            self._at = 0
        return self._buf

    @property
    def at(self):
        """The current location in the archive. If not already mapped this function
        will mmap the file
        """
        _ = self.buf
        return self._at

    @at.setter
    def at(self, v):
        """Set the the current archive location

        :Parameters:
          - `v`: The new location offset in the buffer

        """
        self._at = v

    def is_valid(self):
        """test and return True iff this represents a valid FTDC archive
        """
        # noinspection PyBroadException
        try:
            self.read()
            return True
        except Exception:
            return False

    def read(self):
        """read and yield each chunk from the archive
        """
        l = len(self.buf)
        while self.at < l:
            try:
                # avoid circular reference (and madness)
                chunk = mseries.ftdc.FtdcChunk(self.buf, self.at, filename=self._fn)
                yield chunk
                self.logger.debug("read %s from %d(%d), _id=%s", chunk.type_str, self.at, chunk.bson_len, chunk['_id'])
                self.at += chunk.bson_len
            except Exception as e:
                self.logger.error("exception", exc_info=1)
                raise e
        # bson docs should exactly cover file
        assert (self._at == l)

    @property
    def memo(self):
        """get a flyweight instance that can be passed to another process
        """
        return FtdcArchiveMemo(self)

Archive.add(FtdcArchive)
