"""
A task for writing to a data endpoint
"""
from mseries.utils import Logger, lookup
from mseries.pipelines import run_pipeline
from collections import OrderedDict
from pytz import timezone
import parsedatetime
from mseries.archive import Archive
from mseries.utils import NameEncoder, check_between


class WriterTask(Logger):
    """ a writer task """

    def __init__(self, memo, progress, nxt=None):
        """Create a writer task

        :Parameters:
          - `memo`: a flyweight to write
          - `progress`: the progress call back

        """
        Logger.__init__(self, name=__name__)
        self.memo = memo
        # self._progress = progress
        self._chunk = None
        self._pb = progress
        self._pb_context = None
        self._hostname = None
        self._project = None
        self._pipeline = None
        self._config = None
        self._encoder = None
        self._nxt = nxt

    @property
    def encoder(self):
        """ a name encoder instance """
        if self._encoder is None:
            self._encoder = NameEncoder(self.configuration)
        return self._encoder

    @property
    def configuration(self):
        """ the configuration """
        return self._config

    @configuration.setter
    def configuration(self, cfg):
        self._config = cfg

    @property
    def chunk(self):
        """ get the chunk from the memo """
        if self._chunk is None:
            self._chunk = self.memo.from_memo()
        return self._chunk

    def progress_context(self, **kwargs):
        """set a context to be displayed in the progress

        :Parameters:
          - `kwargs`: a set of key words args to use

        """
        self._pb_context = dict(**kwargs)

    def progress(self, **kwargs):
        """update the progress

        :Parameters:
          - `kwargs`: a set of key words args to use

        """
        if self.pb:
            if self._pb_context:
                kwargs.update(self._pb_context)
            self.pb.update(**kwargs)

    @property
    def pb(self):
        """ the progress bar instance"""
        return self._pb

    @pb.setter
    def pb(self, val):
        self._pb = val

    # noinspection PyUnresolvedReferences
    def write(self, writer, bs=400):
        """write the chunk to the writer

        :Parameters:
          - `writer`: the writer end point
          - `bs`: the batch size
        :Returns: the size of the chunk

        """
        _id = self.chunk.identifier
        self.logger.info("Task starting {}".format(_id))
        if self.chunk.category == Archive.METADATA_TYPE:
            # TODO look at separating
            # build, cmdline and host info
            measurement = self.chunk.measurement(Archive.METADATA_NAME)

            pt = self.chunk.doc[u'doc']
            t = self.chunk.doc[u'_id']
            cal = parsedatetime.Calendar()
            date, _ = cal.parseDT(datetimeString='2016-08-02 09:04:03.014000')
            tags = self.chunk.tags(self.configuration, pt)
            point = OrderedDict([(u'measurement', measurement.name),
                                 (u'time', writer.to_timestamp(t)),
                                 (u'tags', tags),
                                 (u'fields', writer.translate(measurement.name, pt)),
                                 ])
            points = [point]
            writer.write(points, batch=bs)
            self.progress(points=len(points))
        elif self.chunk.category >= Archive.METRIC_CHUNK_TYPE:
            self.chunk.metrics.config = self._config
            def make_point(doc, tags, measurement):
                ts = doc.get(self.encoder.key_to_name(measurement.timestamp())) or lookup(doc, measurement.timestamp())
                ts = doc.get(self.encoder.key_to_name((u'serverStatus', u'start', ))) or \
                     lookup(doc, (u'serverStatus', u'start', )) if ts is None else ts
                ts = doc.get(self.encoder.key_to_name((u'start', ))) or lookup(doc, (u'start', )) if ts is None else ts

                return OrderedDict([(u'measurement', measurement.name),
                                    (u'time', writer.to_timestamp(ts)),
                                    (u'tags', tags),
                                    (u'fields', writer.translate(measurement.name, doc)),
                                    ])

            self.logger.debug('chunk')
            metrics = self.chunk.metrics
            self.logger.info("chunk contains {}".format(metrics.description))

            self.progress_context(ts=self.chunk.to_progress(20))
            self.logger.debug("done")

            rate = self.configuration.sample

            measurement = self.chunk.measurement(Archive.REFERENCE_SAMPLE_NAME)

            tags = self.chunk.tags(self.configuration, metrics.doc)

            points = [make_point(metrics.doc, tags, measurement)]
            writer.write(points, batch=bs)
            self.progress(points=len(points))
            points = []
            for measurement, pt in metrics.idecode(ftdc=True, measurements=self.chunk.measurements(),
                                                   pipeline=self.translate, rate=rate):

                points.append(make_point(pt, tags, measurement))
                if len(points) == bs:
                    writer.write(points, batch=bs)
                    self.progress(points=len(points))
                    del points[:]
            if points:
                writer.write(points, batch=bs)
                self.progress(points=len(points))
            self.logger.debug("done")

        return self.chunk.bson_len

    def __call__(self):
        """ implementation for callable class instance """
        self.logger.debug("Task starting %s", self.chunk.identifier)
        btwn = check_between(self.chunk, self._config, nxt=self._nxt)
        if btwn:
            l = self.write(self.writer, bs=self.batch)
            status = "Task completed {}".format(self.chunk.identifier)
            self.logger.debug(status)
        else:
            l = self.chunk.bson_len
        self.progress(size=l)
        return l

    @property
    def batch(self):
        """ get the batch size """
        if hasattr(self, '_batch'):
            return getattr(self, '_batch')
        b = self.configuration.batch
        setattr(self, '_batch', int(b))
        return int(b)

    # noinspection PyBroadException
    @property
    def tz(self):
        """ get the timezone """
        if hasattr(self, '_tz'):
            return getattr(self, '_tz')
        tz = self.configuration.tz
        if isinstance(tz, (list, tuple)):
            tz = tz[0]
        try:
            tz = timezone(tz)
        except:
            tz = None
        setattr(self, '_batch', tz)
        return tz

    # noinspection PyBroadException
    @property
    def date(self):
        """ get the date """
        if hasattr(self, '_date'):
            return getattr(self, '_date')
        date = self.configuration.date
        if isinstance(date, (list, tuple)):
            date = " ".join(date)
        try:
            import parsedatetime
            cal = parsedatetime.Calendar()
            date, _ = cal.parseDT(datetimeString=date, tzinfo=self.tz)
        except:
            self.logger.error("error", exc_info=1)
            date, _ = cal.parseDT(datetimeString=date, tzinfo=self.tz)
        setattr(self, '_date', date)
        return date

    @property
    def project(self):
        """ get the project """
        if hasattr(self, '_project'):
            return getattr(self, '_project')
        project = self.configuration.project
        setattr(self, '_project', project)
        return project

    @property
    def hostname(self):
        """ get the hostname """
        if hasattr(self, '_hostname'):
            return getattr(self, '_hostname')
        hostname = self.configuration.hostname
        setattr(self, '_hostname', hostname)
        return hostname

    def __str__(self):
        """ get the string representation """
        return '{}'.format(self.chunk)

    def translate(self, measurement_name, values, out=None, memo=None):
        """run the pipeline for this task

        :Parameters:
          - `measurement_name`: the measurement name
          - `values`: a dict of values
          - `out`: where the output goes
          - `memo`: a dict to use to pass data aroudn
        """

        run_pipeline(self.pipeline, measurement_name, values, out=out, memo=memo)

    @property
    def pipeline(self):
        """ get the pipeline for the task """
        return self._pipeline

    @pipeline.setter
    def pipeline(self, val):
        self._pipeline = val