from mseries.tasks.writer_task import WriterTask
