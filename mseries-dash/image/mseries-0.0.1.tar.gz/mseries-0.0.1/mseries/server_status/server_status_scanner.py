"""
Provides functions to read FTDC data from either an FTDC file or from
a file containing serverStatus JSON documents, one per line. Each
reader takes a filename argument and returns a generator that yields a
sequence of chunks. Each chunk is a map from tuples keys to lists, where
the tuple key represents a path through a JSON document from root to leaf,
and the list is a list of values for that path.
"""

import json
import time
from collections import OrderedDict
from mseries.scanner.scanner import Scanner, seq, Redo
from mseries.utils import is_float, is_int


class ServerStatusScanner(Scanner):
    # maybe TokAssign or sep would be better as it could also be a =
    TokJsStarting = next(seq)
    TokJsKey = next(seq)
    TokJsObject = next(seq)
    TokJsObjectId = next(seq)
    TokJsISODate = next(seq)
    TokJsTimestamp = next(seq)
    TokJsBool = next(seq)
    TokJsNumberLong = next(seq)
    TokJsInt = next(seq)
    TokJsFloat = next(seq)
    TokJsEnd = next(seq)
    TokJsEndArray = next(seq)
    TokJsComma = next(seq)
    TokJsValue = next(seq)
    TokJsStringValue = next(seq)
    TokJsArray = next(seq)
    TokJsNumeric = next(seq)

    TokStrings = {
        TokJsStarting: "Starting",
        TokJsKey: "Key",
        TokJsObject: "Object",
        TokJsObjectId: "ObjectId",
        TokJsISODate: "ISODate",
        TokJsTimestamp: "Timestamp",
        TokJsBool: "Bool",
        TokJsNumberLong: "NumberLong",
        TokJsInt: "Int",
        TokJsFloat: "Float",
        TokJsEnd: "End Object",
        TokJsEndArray: "End Array",
        TokJsComma: "Comma",
        TokJsValue: "Value",
        TokJsStringValue: "StringValue",
        TokJsArray: "Array",
        TokJsNumeric: "Numeric",
    }
    TokStrings.update(Scanner.TokStrings)

    ScanJsStarting = 1 << TokJsStarting
    ScanJsKey = 1 << TokJsKey
    ScanJsObject = 1 << TokJsObject
    ScanJsEnd = 1 << TokJsEnd
    ScanJsValue = 1 << TokJsValue
    ScanJsStringValue = 1 << TokJsStringValue
    ScanJsArray = 1 << TokJsArray
    ScanJsNumeric = 1 << TokJsNumeric

    ModeStrings = {
        ScanJsStarting: "JsStarting",
        ScanJsKey: "JsKey",
        ScanJsObject: "JsObject",
        ScanJsValue: "JsValue",
        ScanJsStringValue: "JsStringValue",
        ScanJsArray: "JsArray",
        ScanJsNumeric: "JsNumeric",
    }
    ModeStrings.update(Scanner.ModeStrings)

    GoTokens = Scanner.GoTokens | ScanJsObject
    ScanStarting = Scanner.ScanStarting | ScanJsObject

    def __init__(self, filename, encoding='utf-8', sz=16381):
        Scanner.__init__(self, filename, encoding=encoding, sz=sz, name=__name__)
        self._context = u''  # context of '[' or '{' for array or doc
        self._hungry = True  # consume whitespace as possible

    def to_json(self, full=False):
        doc = OrderedDict([
            ('srcBuf', self._src_buf.replace("\n", " ") if full else len(self._src_buf)),
            ('context', self._context),
            ('srcPos', self.src_pos),
            ('srcEnd', self._src_end),
            ('tokPos', self.tok_pos),
            ('tokEnd', self.tok_end),
            ('srcBufOffset', self._src_buf_offset),
            ('mode', self.mode_to_string(self.mode)),
            ('line', self.line),
            ('lineBuf', self.line_buf),
        ])
        return json.dumps(doc, indent=3)

    def is_valid(self):
        tok = self.scan()
        return tok == Scanner.TokAttribute

    def tr(self, ch):
        if ch == u'\n':
            return u'\\n'
        if ch == u'\r':
            return u'\\r'
        if ch == u'\t':
            return u'\\t'
        return ch

    # obj is this in the context of an object or an array
    def scan(self, limit=None, error=None):
        terror, self.error = error, self.error
        ch = self.peek()
        redo = 0
        l = self._limit
        try:
            self._limit = limit

            while True:
                try:
                    self.tok_pos = -1
                    self.line = 0
                    if self._hungry:

                        while ch in self._whitespace:
                            if ch == self.EOF:
                                self.logger.info("token %s(%s)", self.token_to_string(self.TokEOF),
                                                 self.tr(self.ch))
                                self.logger.info("mode %s", self.mode_to_string(self.mode))
                                return self.TokEOF
                                # start collecting token text
                            ch = self.next()
                    else:
                        if ch == u'\n':
                            self.line_buf = u''

                            # start collecting token text
                            ch = self.next()
                            if ch == self.EOF:
                                self.logger.info("token %s(%s)", self.token_to_string(self.TokEOF), self.tr(self.ch))
                                self.logger.info("mode %s", self.mode_to_string(self.mode))
                                return self.TokEOF

                            self.line = self._line
                            # self.mode = self.ScanStarting
                            self.logger.info("token %s(%s)", self.token_to_string(self.TokEOL), self.tr(self.ch))
                            self.logger.info("mode %s ", self.mode_to_string(self.mode))
                            return self.TokEOL

                        if self._column > 1:
                            ch = self.skip_whitespace(ch, m=self.NoGoWhitespace)

                    # start collecting token text
                    self.tok_buf = u''
                    self.tok_pos = self.src_pos - self._last_char_len

                    # set token position
                    # (this is a slightly optimized version of the code in Pos())
                    self.offset = self._src_buf_offset + self.tok_pos
                    if self._column > 0:
                        # common case: last character was not a '\n'
                        self.line = self._line
                        self.column = self._column
                    else:
                        # last character was a '\n'
                        # (we cannot be at the beginning of the source
                        # since we have called next() at least once)
                        self.line = self._line - 1
                        self.column = self._last_line_len

                    # determine token value
                    tok = self.TokIgnore
                    if ch == u'{':
                        self._context += ch
                        tok, ch = self.scan_start_object(ch)
                    # <---
                    elif ch == u'"' or ch == u'\'':
                        if self.mode & self.ScanJsKey != 0:
                            tok, ch = self.scan_key(ch)
                        elif self.mode & (self.ScanJsValue | self.ScanJsStringValue | self.ScanJsKey) != 0:
                            tok, ch = self.scan_value(ch)
                            if self._context and self._context[-1] == u'[':
                                self.mode ^= self.ScanJsKey
                        ch = self.next()

                    # <---
                    elif ch == u'}':
                        assert self._context[-1] == u'{'
                        self._context = self._context[:-1]
                        if self.mode & (self.ScanJsKey | self.ScanJsArray | self.ScanJsValue | self.ScanJsNumeric) != 0:
                            tok, ch = self.scan_end_object(ch)
                        else:
                            ch = self.next()
                            tok = self.TokIgnore  # JsIgnore

                    elif ch == u'[':
                        self._context += ch
                        if self.mode & self.ScanJsValue != 0:
                            tok, ch = self.scan_start_array(ch)
                        else:
                            ch = self.next()
                            tok = self.TokIgnore  # JsIgnore

                    elif ch == u']':
                        assert self._context[-1] == u'['
                        self._context = self._context[:-1]
                        if self.mode & (self.ScanJsKey | self.ScanJsArray | self.ScanJsValue | self.ScanJsNumeric) != 0:
                            tok, ch = self.scan_end_array(ch)
                        else:
                            ch = self.next()
                            tok = self.TokIgnore  # JsIgnore
                    elif ch == u',':
                        if self.mode & (self.ScanJsKey | self.ScanJsArray | self.ScanJsValue | self.ScanJsNumeric) != 0:
                            ch = self.next()
                            tok = self.TokJsComma  # JsIgnore
                        else:
                            ch = self.next()
                            tok = self.TokIgnore  # JsIgnore
                    elif self.is_ident(ch, 0):
                        # if (ch == u'C' or ch == u'S') and self.Mode & (self.ScanStart | self.ScanCurrent) != 0:
                        if self.mode & self.ScanAttribute != 0:
                            tok, ch = self.scan_attribute(ch)
                        elif self.mode & self.ScanValue != 0:
                            tok, ch = self.scan_attr_value(ch)
                        elif self.mode & self.ScanJsValue != 0:
                            tok, ch = self.scan_value(ch)
                            if self._context and self._context[-1] == u'[':
                                self.mode ^= self.ScanJsKey
                        elif self.mode & self.ScanEOL != 0:
                            tok, ch = self.scan_to_EOL(ch)
                        else:
                            ch = self.next()
                    elif ch == u':' and self.mode & self.ScanAttributeSeparator != 0:
                        tok, ch = self.TokAttributeSeparator, self.next()
                        self.mode ^= self.ScanAttributeSeparator
                        if self.mode == 0:
                            self.mode = self.ScanValue
                    elif self.is_decimal(ch):
                        # hmm come back to this
                        if self.mode & self.ScanJsValue != 0:
                            tok, ch = self.scan_value(ch)
                            if self._context and self._context[-1] == u'[':
                                self.mode ^= self.ScanJsKey
                        elif self.mode & self.ScanValue != 0:
                            tok, ch = self.scan_attr_value(ch)
                        else:
                            ch = self.next()
                    else:
                        if ch == self.EOF:
                            tok = self.TokEOF
                        elif ch == u'\n':
                            tok = self.TokEOL
                        else:
                            ch = self.next()
                    # end of token text
                    self.tok_end = self.src_pos - self._last_char_len
                    if tok == self.TokEOL:
                        self.mode = self.ScanStarting

                    self.ch = ch
                    # self.logger.info("current token %s, next char='%s'", self.token_to_string(tok), self.tr(self.ch))
                    # self.logger.info("mode %s ", self.mode_to_string(self.mode))
                    return tok

                except Redo as e:
                    if redo > 10:
                        raise e
                    self.logger.debug("Redo start", exc_info=1)
                    self._line -= 1
                    redo += 1
                    if self.tok_pos > 0:
                        d = self.src_pos - self.tok_end
                        self.src_pos = self.tok_end
                        self._column -= d
                        ch = self.next()
        finally:
            self._limit = l
            self.error = terror

    def scan_identifier(self, ch):
        # read character after '`'
        self.logger.debug("scan_times %s", ch)
        ch = self._scan_identifier()
        if ch == self.TokAttributeSeparator:
            self.mode = self.ScanAttributeSeparator
            return self.TokAttribute, ch
        else:
            self.mode = self.ScanEOL
            return self.TokIgnore, ch

    def scan_start_object(self, ch):
        self.logger.info("scan_start_object %s", ch)
        ch = self.next()
        self.mode = self.ScanJsKey
        return self.TokJsObject, ch

    def scan_end_object(self, ch):
        self.logger.debug("scan_end_object %s", ch)
        # read character after '`'
        ch = self.scan_identifier(ch)
        self.mode = self.ScanJsValue | self.ScanJsArray | self.ScanJsNumeric | self.ScanJsKey
        return self.TokJsEnd, ch

    def scan_start_array(self, ch):
        self.logger.debug("scan_end_object %s", ch)
        # read character after '`'
        # ch = self.scan_identifier(ch)
        ch = self.next()
        self.mode = self.ScanJsArray | self.ScanJsObject | self.ScanJsValue
        return self.TokJsArray, ch

    def scan_end_array(self, ch):
        self.logger.debug("scan_end_object %s", ch)
        # read character after '`'
        ch = self.scan_identifier(ch)
        self.mode = self.ScanJsValue | self.ScanJsArray | self.ScanJsNumeric | self.ScanJsObject | self.ScanJsKey
        return self.TokJsEndArray, ch

    def scan_attribute(self, ch):
        self.logger.debug("scan_attribute %s", ch)
        # read character after '`'
        self.logger.info("scan_attribute %s", ch)
        while ch != u':':
            tok, ch = self.scan_identifier(ch)
            self.logger.info("scan_attribute %s", ch)
        self.mode = self.ScanAttributeSeparator
        return self.TokAttribute, ch

    def scan_attr_value(self, ch):
        self.mode = self.ScanAttribute | self.ScanJsObject | self.ScanJsArray
        return self.TokValue, self._scan_value(ch)

    def scan_key(self, ch):
        # read character after '`'
        if ch == u'"' or ch == u'\'':
            stop = ch
            ch = self.next()
            # while ch != stop and ch == self.EOF:
            while ch != stop:
                ch = self.next()

            # ch = self.next()

            self.mode = self.ScanJsValue | self.ScanJsStringValue | self.ScanJsArray | self.ScanJsObject | \
                        self.ScanAttributeSeparator
            return self.TokJsKey, ch

        tok = self.TokJsIgnore
        self.mode = self.ScanJsKey | self.ScanJsValue | self.ScanJsStringValue | self.ScanJsArray | self.ScanJsObject
        return tok, ch

    def scan_value(self, ch):
        # read character after '`'
        # tok = self.TokJsValue
        mode = self.ScanJsKey | self.ScanJsValue | self.ScanJsStringValue | self.ScanJsArray | self.ScanJsObject
        if ch == u'"' or ch == u'\'':
            stop = ch
            ch = self.next()
            # while ch != stop and ch == self.EOF:
            while ch != stop:
                ch = self.next()

            # ch = self.next()

            self.mode = mode
            return self.TokJsStringValue, ch

        ch = self.scan_identifier(ch)
        t = self._text().rstrip(u" ,(}\n")
        self.logger.info("scan_value '%s'", t)
        if t == u"true" or t == u"false":
            tok = self.TokJsBool
            self.mode = mode
            return tok, ch

        if t == u"Timestamp":
            while ch != ')':
                ch = self.next()
            ch = self.next()

            tok = self.TokJsTimestamp
            self.mode = mode
            return tok, ch
        elif t == u"NumberLong":
            while ch != ')':
                ch = self.next()
            ch = self.next()

            tok = self.TokJsNumberLong
            self.mode = mode
            return tok, ch
        elif t == u"ISODate":
            while ch != ')':
                ch = self.next()
            ch = self.next()

            tok = self.TokJsISODate
            self.mode = mode
            return tok, ch
        elif t == u"ObjectId":
            while ch != ')':
                ch = self.next()
            ch = self.next()

            tok = self.TokJsObjectId
            self.mode = mode
            return tok, ch

        if is_int(t) is not None:
            tok = self.TokJsInt
        elif is_int(t, 16) is not None:
            tok = self.TokJsInt
        elif is_float(t) is not None:
            tok = self.TokJsFloat
        else:
            tok = self.TokJsStringValue

        self.mode = mode
        return tok, ch

    def scan_attribute_or_heading(self, ch):
        self.logger.debug("scan_attribute_or_heading %s", ch)
        # read character after '`'
        while ch != u':':
            ch = self._scan_identifier()

        if ch == u':':
            self.mode = self.ScanAttributeSeparator
            return self.TokAttribute, ch

        self.mode = self.ScanEOL | self.ScanStarting
        return self.TokIgnore, ch

    # def scan_attribute(self, ch):
    #     self.logger.debug("scan_attribute_or_heading %s", ch)
    #     # read character after '`'
    #     while ch != u':':
    #         ch = self._scan_identifier()
    #
    #     if ch == u':':
    #         self.mode = self.ScanAttributeSeparator
    #         return self.TokAttribute, ch
    #
    #     self.mode = self.ScanEOL | self.ScanStarting
    #     return self.TokIgnore, ch

    # def scan_heading(self, ch):
    #     def is_header_ident_rune(c, i):
    #         return c == '_' or c == '|' or c == '-' or c.isalpha() or c.isdigit() and i > 0
    #
    #     self.logger.debug("scan_heading %s", ch)
    #
    #     ch = self._scan_identifier(m=is_header_ident_rune)
    #     identifier = self._text().rstrip(u" :=(;.\n")
    #     peek = self.peek(offs=1)
    #     self.mode = self.ScanHeading
    #     if identifier == u'time':
    #         pass
    #     if peek == u'%':
    #         # grab the % in the token
    #         self.next()
    #         ch = self.next()
    #
    #     return self.TokHeading, ch

    # def scan_metrics(self, ch):
    #     def is_metrics_ident_rune(c, i):
    #         return c == u'*' or c == u'%' or c == u':' or c == u'.' or c == u'|' or c == u'-' or c.isalpha() or \
    #                c.isdigit() and i > 0
    #
    #     self.logger.debug("scan_metrics %s", ch)
    #
    #     ch = self._scan_identifier(m=is_metrics_ident_rune)
    #     self.mode = self.ScanMetrics
    #     if ch == u'\n':
    #         self.mode = self.ScanStarting
    #         return self.TokEOL, ch
    #     else:
    #         return self.TokMetrics, ch

    def timestamp(self):
        v = self.token()
        return time.strptime(v, '%Y%m%dT%H%M%S')
