"""
Provides functions to read FTDC data from either an FTDC file or from
a file containing serverStatus JSON documents, one per line. Each
reader takes a filename argument and returns a generator that yields a
sequence of chunks. Each chunk is a map from tuples keys to lists, where
the tuple key represents a path through a JSON document from root to leaf,
and the list is a list of values for that path.
"""
from mseries.types import BSON
from mseries.archive import Archive
from mseries.server_status.server_status_scanner import ServerStatusScanner

from datetime import datetime
import humanfriendly
import os
import mseries.tools


class ServerStatusMetric:
    def __init__(self):
        self._current = None
        self._start = None
        self._values = None
        self._attributes = None
        self._connecting_to = None
        self._start_timestamp = None
        self._version = None
        self._local_time= None

    def valid(self):
        return self._current or self._attributes is not None

    def tags(self, args, points, **kwargs):
        # self.logger.debug("%s %s", args, points)
        tags = {}
        tags.update(kwargs)
        return tags

    def measurements(self):
        return [('server_status', '')]

    def idecode(self, *args, **kwargs):
        for a in self._attributes:
            yield a

    def category(self):
        return 1

    def identifier(self):
        return self._local_time

    @property
    def attributes(self):
        if self._attributes is None:
            self._attributes = []
        return self._attributes

    @property
    def timestamp(self):
        return self._start_timestamp

    @property
    def nmetrics(self):
        if self._attributes is None:
            return 0
        return len(self._attributes[0])

    @property
    def nsamples(self):
        if self._attributes is None:
            return 0
        return len(self._attributes)

    def add_metrics(self, metric):
        if self._local_time is None:
            if isinstance(metric, dict):
                self._local_time = metric.get(u'localTime', None) or metric.get((u'localTime',), None)
        self.attributes.append(metric)
        return metric

    def set(self, name, value):
        if name == u'MongoDB shell version':
            self._version = value
        elif name == u'connecting to':
            self._connecting_to = value
        elif name == u'Start Time':
            self._start = self.parse_timestamp(value)

    @classmethod
    def parse_timestamp(cls, v, fmt="%Y%m%dT%H%M%S"):
        return datetime.strptime(v, fmt)

    @classmethod
    def set_metric(cls, attributes, name, value):
        if name in [u'insert', u'query', u'update', u'delete', u'getmore']:
            replicated = value[0] == u'*'
            if replicated:
                name += u'_repl'
                value = value[1:]
            attributes.append((name, int(value),))
        elif name == u'command %' or name == u'command %':
            local, replicated = value.split('|')
            attributes.append((u'command', int(local),))
            attributes.append((u'command_repl', int(replicated),))
        elif u'|' in name:
            first, last = name.split('|')
            readers, writers = value.split('|')
            attributes.append((first, int(readers),))
            attributes.append((last, int(writers),))
        elif name == u'used' or name[-1] == u'%':
            name = name.rstrip(u' %')
            attributes.append((name, float(value)))
        elif name in [u'flushes']:
            attributes.append((name, int(value)))
        elif name in [u'vsize', u'res', u'netIn', u'netOut']:
            try:
                attributes.append((name, humanfriendly.parse_size(value, binary=True)))
            except humanfriendly.InvalidSize:
                attributes.append((name, value))
        elif name in [u'set', u'repl', u'conn']:
            attributes.append((name, value))
        else:
            attributes.append((name, value))


class ServerStatusArchiveMemo(object):
    def __init__(self, archive):
        self._filename = archive.filename

    def from_memo(self):
        return ServerStatusArchive(self._filename)

    @property
    def identifier(self):
        return self._filename

    @property
    def filename(self):
        return self._filename

    @property
    def category(self):
        return 1


class ServerStatusArchive(Archive):
    CT_HEADER = 'Current Time : '
    ST_HEADER = 'Start Time : '
    INSERT = 'insert '

    def __init__(self, fn):
        Archive.__init__(self, name=__name__)
        self._filename = fn
        self._scanner = None
        self._valid = None
        self._category = 1
        self._start_timestamp = None
        self._end_timestamp = None
        self._stats = None

    @property
    def memo(self):
        return ServerStatusArchiveMemo(self)

    def from_memo(self):
        return self

    def __enter__(self):
        return self

    def __exit__(self, tt, value, traceback):
        self.scanner.close()
        self._scanner = None

    def _type(self, tt, value, traceback):
        self.logger.debug("_type %s %s %s", tt, value, traceback)
        self.scanner.close()
        self._scanner = None

    def is_valid(self):
        if self._valid is None:
            err = None
            pos = None

            def on_error(e, p):
                global err
                global pos
                err = e
                pos = p

            try:
                with self as archive:
                    scanner = archive.scanner
                    tok = scanner.scan(limit=1024, error=on_error)
                    self.logger.info("token %s", scanner.token_to_string(tok))
                    archive._valid = (tok in [scanner.TokAttribute, scanner.TokJsObject])
            except:
                self.logger.debug("valid", exc_info=1)
                self._valid = False
        return self._valid

    @property
    def scanner(self):
        if self._scanner is None:
            self._scanner = ServerStatusScanner(self._filename)
        return self._scanner

    def from_memo(self):
        return self

    @property
    def identifier(self):
        if self.metrics:
            return self.metrics.timestamp
        return 0

    def to_progress(self, l):
        if self.metrics:
            return self.metrics.timestamp[0:l - 1]
        fn = self.filename
        if len(self.filename) < l:
            fn = os.path.basename(fn)
        return fn[0:l - 1]

    @property
    def filename(self):
        return self._filename

    @property
    def category(self):
        return self._category

    @property
    def timestamp(self):
        return self.start_timestamp

    @property
    def start_timestamp(self):
        return self._start_timestamp

    def close(self):
        if self._scanner is not None:
            self._scanner.close()
            self._scanner = None

    def add(self, metric):
        self.metrics.append(metric)

    # scan object scans from '{' to matching '}', it is up to the
    # caller to scan the next token and determine if it is a ',', '}' or ']'
    # the consume object assumes that we are at the actual opening '{' for this
    # object
    @classmethod
    def _consume_object(cls, scanner, tok):
        assert tok == scanner.TokJsObject

        js = BSON()
        tok = None
        while tok != scanner.TokJsEnd:
            tok = cls._consume_whitespace(scanner, scanner.scan())

            if tok == scanner.TokEOF:
                scanner.logger.warn("unexpected EOF")
                break

            # empty doc is ok
            if tok == scanner.TokJsEnd:
                scanner.logger.warn("unexpected '}' assuming dangling ,")
                break

            key, value = cls._consume_key_value(scanner, tok)
            js[key] = value
            scanner.logger.debug("js['%s']=%s", key, value)

            tok = cls._consume_whitespace(scanner, scanner.scan())

            # done
            if tok == scanner.TokJsEnd:
                scanner.logger.debug("consume object completed")
                break

            # get the next k, v pair
            if tok == scanner.TokJsComma:
                scanner.logger.debug("consume object next")
                continue

            # error
            if tok == scanner.TokEOF or tok == scanner.TokJsEnd:
                scanner.logger.warn("consume object error")
                break

        return js, tok

    # consume array assumes that we are at the starting '['
    @classmethod
    def _consume_array(cls, scanner, tok):

        assert tok == scanner.TokJsArray
        js = []
        tok = None
        while tok != scanner.TokJsEnd:
            tok = cls._consume_whitespace(scanner, scanner.scan())

            if tok == scanner.TokEOF:
                scanner.logger.warn("unexpected EOF")
                break

            # done
            if tok == scanner.TokJsEndArray:  # assume dangling ','
                scanner.logger.debug("unexpected end array")
                break
            expected = [scanner.TokJsObject, scanner.TokJsStringValue, scanner.TokJsValue, scanner.TokJsInt,
                        scanner.TokJsNumberLong, scanner.TokJsObjectId, scanner.TokJsTimestamp, scanner.TokJsISODate]
            if tok not in expected:
                scanner.logger.info("unexpected token %s\n%s", scanner.token_to_string(tok), scanner.to_json())
            assert tok in expected
            js.append(cls._consume_value(scanner, tok))
            tok = cls._consume_whitespace(scanner, scanner.scan())

            # done
            if tok == scanner.TokJsEndArray:
                scanner.logger.debug("consume array completed")
                break

            # get the next value
            if tok == scanner.TokJsComma:
                scanner.logger.debug("consume object next")
                continue

            # error
            if tok == scanner.TokEOF:
                scanner.logger.warn("consume object error")
                break

        return js, tok

    # the key is the current token
    @classmethod
    def _consume_key_value(cls, scanner, tok):
        assert tok == scanner.TokJsKey
        key = scanner.string_token()
        scanner.logger.info("key '%s'", key)

        tok = scanner.scan()
        assert tok == scanner.TokAttributeSeparator

        tok = scanner.scan()
        v = cls._consume_value(scanner, tok)
        scanner.logger.info("js['%s']=%s", key, v)
        return key, v

    @classmethod
    def _consume_value(cls, scanner, tok):
        cls._consume_whitespace(scanner, tok)
        value = scanner.string_token()
        scanner.logger.info("scan_value value=%s", value)

        if tok == scanner.TokJsStringValue:
            value = scanner.string_token()
        elif tok == scanner.TokJsISODate:
            value = scanner.date_token()
        elif tok == scanner.TokJsBool:
            value = scanner.bool_token()
        elif tok == scanner.TokJsArray:
            value, tok = cls._consume_array(scanner, tok)
        elif tok == scanner.TokJsObject:
            value, tok = cls._consume_object(scanner, tok)
        elif tok == scanner.TokJsNumeric:
            value = scanner.numeric_token()
        elif tok == scanner.TokJsNumberLong:
            value = scanner.number_long_token()
        elif tok == scanner.TokJsInt:
            value = scanner.int_token()
        elif tok == scanner.TokJsFloat:
            value = scanner.float_token()
        elif tok == scanner.TokJsObjectId:
            value = scanner.object_id_token()
        elif tok == scanner.TokJsTimestamp:
            value = scanner.timestamp_token()
        else:
            value = scanner.token()

        return value

    @classmethod
    def _consume_whitespace(cls, scanner, tok):
        while tok in [scanner.TokEOL, scanner.TokEOF, scanner.TokIgnore]:
            tok = scanner.scan()
        scanner.logger.debug("current token %s", scanner.token_to_string(tok))
        return tok

    def iscan(self, flat=False, singular=False):
        scanner = self.scanner

        tok = None
        while tok != scanner.TokEOF:
            tok = scanner.scan()
            if tok == scanner.TokAttribute:
                self.logger.debug('Attribute Token')
                name = scanner.token()
                self.logger.debug('Attribute Token name %s', name)
                assert scanner.TokAttributeSeparator == scanner.scan()
                assert scanner.TokValue == scanner.scan()
                value = scanner.token()
                self.logger.debug('Attribute Token value %s', value)
            elif tok == scanner.TokJsObject:
                self.logger.debug('JsObject')
                js, tok = self._consume_object(scanner, tok)
                if flat:
                    yield mseries.utils.flatten(js, {}, singular=singular)
                else:
                    yield js
                self.logger.debug('JsObject %s', js)
            elif tok == scanner.TokJsArray:
                self.logger.debug('JsArray')
                js, tok = self._consume_array(scanner, tok)
                yield js
                self.logger.debug('JsObject %s', js)
            elif tok == scanner.TokEOF:
                self.logger.debug('EOF')
            else:
                self.logger.debug('ignoring token')
        self.logger.info('done')


    @property
    def metrics(self):
        return self.scan()

    def scan(self, flat=False):
        if self._stats is None:
            current = ServerStatusMetric()
            for ss in self.iscan(flat=flat, singular=True):
                current.add_metrics(ss)
            self._stats = [current]
        return self._stats

Archive.add(ServerStatusArchive)
