import sys
PY3K = sys.version_info >= (3, 0)

EOS = '\0'
if PY3K:
    EOS = EOS.encode("ascii")
