"""Lazy attribute reader
"""
from mseries.utils.logger import Logger
from mseries.types import BSON, Reader
import os


def av_factory(buf, at, fn=None):
    """attribute value factory method, read the type and then create
    an AttrValue wrapper instance

    :Parameters:
      - `buf`: the buffer containing the data
      - `at`: the location to read from
      - `fn`: an identifier for debugging more than anything else

    """
    bson_type, _ = Reader.byte(buf, at)
    if bson_type == int(Reader.T_DOC):
        return DocAttrValue(buf, at, fn=fn)
    elif bson_type == int(Reader.T_ARRAY):
        return ArrayAttrValue(buf, at, fn=fn)
    else:
        return AttrValue(buf, at, fn=fn)


class AttrValue(Logger):
    """ a Lazy bson reader """

    def __init__(self, buf, at, fn=None):
        """create a lazy bson value

        :Parameters:
          - `buf`: the buffer containing the data
          - `at`: the location to read from
          - `fn`: an identifier for debugging more than anything else

        """
        Logger.__init__(self, name=__name__)
        self._buf = buf
        self._fn = os.path.basename(fn)
        self._at = at
        self._start = at
        self._bson_type, self._at = Reader.byte(self._buf, self._at)
        self._name = ''
        if self._bson_type != int(Reader.T_EOO):
            self._name, self._at = Reader.cstring(self._buf, self._at)
        self._size = (self._at - self._start) + self.bson_len(self._at)
        self._value = None

    def bson_len(self, at=None):
        """get the length of this bson type

        :Parameters:
          - `at`: if at is None use the location for this instance

        """
        reader = Reader.find(self._bson_type)
        if reader is not None:
            if at is None:
                at = self.at
            return reader.size(self._buf, at)
        else:
            raise Exception('unknown type %d(%x) at %d(%x)' % (self._bson_type, self._bson_type, self.at, at))

    def ignore(self, ftdc):
        """should  this type be ignored
        TODO: don't think this is actually used now

        :Parameters:
          - `ftdc`: don't ignore is not ftdc

        """
        if not ftdc:
            return False
        if self._bson_type == Reader.T_STRING:
            return True
        return False

    @property
    def name(self):
        """ get the av name """
        return self._name

    @property
    def at(self):
        """ get the av location """
        return self._at

    @at.setter
    def at(self, at):
        self._at = at

    @property
    def value(self):
        """ read the value if it hasn't already been """
        if self._value is None:
            try:
                self._value = self._read()
            except Exception as e:
                self.logger.error('exception', exc_info=1)
                raise e
        return self._value

    @property
    def size(self):
        """ read the av size """
        return self._size

    @property
    def bson_type(self):
        """ read the bson type """
        return self._bson_type

    def _read(self):
        """ read the value in the buffer """
        if self._bson_type == int(Reader.T_DOC):

            doc_len, at = Reader.int32(self._buf, self._at)
            self.logger.debug("_read %s:0x%08X len %08x size  %08x ", self._fn, self._at, doc_len, self._size)

            value = BSON()
            doc_end = at + doc_len
            while at < doc_end:
                av = av_factory(self._buf, at, fn=self._fn)
                at += av.size
                if av.bson_type == int(Reader.T_EOO):
                    break
                value[av.name] = av

            return value
        elif self._bson_type == int(Reader.T_ARRAY):
            return ArrayAttrValue(self._buf, self._at, fn=self._fn)
        else:
            self.logger.debug("_read %s:0x%08X size  %08x ", self._fn, self._at, self._size)
            doc_end = self._start + self._size
            at = self.at
            value = None
            while at < doc_end:
                reader = Reader.find(self.bson_type)
                if reader is not None:
                    value, at = reader.read(self._buf, at)
                else:
                    raise Exception('unknown type %d(%x) at %d(%x)' % (self.bson_type, self.bson_type, at, at))
            return value

    def __repr__(self):
        """ string representation of this instance """
        return "AttrValue  {}={}".format(self.name, self.value)


class DocAttrValue(AttrValue):
    """ A wrapper for a lazy document."""

    def __init__(self, buf, at, fn=None):
        """create a lazy document attribute

        :Parameters:
          - `buf`: the buffer to read
          - `at`: the location to read from
          - `fn`: debugging identifier

        """
        self._doc = None
        AttrValue.__init__(self, buf, at, fn=fn)

    @property
    def doc(self):
        """ read the document from the stream

        :rtype: dict
        """
        if self._doc is None:
            self._doc = self._read()
        return self._doc

    def _read(self):
        """ read the document from the stream """
        doc_len, at = Reader.int32(self._buf, self._at)
        self.logger.debug("{_read:'%s:0x%08X', len:%08x, size:%08x}", self._fn, self._at, doc_len, self._size)

        value = BSON()
        doc_end = at + doc_len
        while at < doc_end:
            av = av_factory(self._buf, at, fn=self._fn)
            at += av.size
            if av.bson_type == int(Reader.T_EOO):
                break
            value[av.name] = av

        return value

    def __setitem__(self, key, item):
        """dict set method

        :Parameters:
          - `key`: the dict key
          - `item`: the value

        """
        self.doc[key] = item

    def __getitem__(self, key):
        """dict get method, it will unwrap an AttrValue

        :Parameters:
          - `key`: the dict key

        """
        v = self.doc[key]
        if isinstance(v, AttrValue):
            v = v.value
            self.doc[key] = v
        return self.doc[key]

    def __repr__(self):
        """get a string representation of this document"""
        return repr(self.doc)

    def __len__(self):
        """ get the document length """
        return len(self.doc)

    def __delitem__(self, key):
        """ delete the document key
        TODO: this should probably not be allowed
        """
        del self.doc[key]

    def clear(self):
        """ clear the document
        TODO: this should probably not be allowed
        """
        return self.doc.clear()

    def copy(self):
        """ get a dict copy of the document
        TODO: this should probably not be allowed
        """
        return self.doc.copy()

    def has_key(self, k):
        """ is the key in this document """
        return k in self.doc

    def update(self, *args, **kwargs):
        """ update this document
        TODO: this should probably not be allowed
        """
        return self.doc.update(*args, **kwargs)

    def keys(self):
        """ get the keys for the doc """
        return self.doc.keys()

    def values(self):
        """ get the values for the doc """
        return self.doc.values()

    def items(self):
        """ get the items for the doc """
        _items = []
        for i, v in self.doc.items():
            if isinstance(v, AttrValue):
                v = v.value
            _items.append((i, v))
        return _items

    def pop(self, *args):
        """ pop document
        TODO: this should probably not be allowed
        """
        v = self.doc.pop(*args)
        if isinstance(v, AttrValue):
            v = v.value
        return v

    def __contains__(self, item):
        """ is the item in the doc """
        return item in self.doc

    def __iter__(self):
        """ is the item in the doc """
        return iter(self.doc)


class ArrayAttrValue(DocAttrValue):
    """ AttrValue class for an array. This unwraps the index keys from the document. """

    def __init__(self, buf, at, fn=None):
        """create a lazy array attribute

        :Parameters:
          - `buf`: the buffer to read
          - `at`: the location to read from
          - `fn`: debugging identifier

        """
        DocAttrValue.__init__(self, buf, at, fn=fn)

    def _read(self):
        """ read the array """
        value = DocAttrValue._read(self)
        return value.values()
