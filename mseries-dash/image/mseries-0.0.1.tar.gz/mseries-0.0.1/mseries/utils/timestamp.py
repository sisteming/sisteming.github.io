from time import time


def to_timestamp(point, fmt="%Y-%m-%dT%H:%M:%S"):
    """ convert value to timestamp
    :Parameters:
      - `point`: the value to convert
      - `fmt`: the date format defaults to *%Y-%m-%dT%H:%M:%S*
    """
    t = point
    if isinstance(point, dict):
        if u'time' in point:
            t = point.pop(u'time')
        elif u'timestamp' in point:
            t = point.pop(u'timestamp')
        elif u'date' in point:
            t = point.pop(u'date')
        else:
            t = point.items()[0][-1]
    if isinstance(t, (str, unicode)):
        return t
    elif isinstance(t, int):
        return "{}.{:03}Z".format(time.strftime(fmt, time.gmtime(t / 1000)), t % 1000)
    elif t is not None:
        return "{}.{:03}Z".format(t.strftime(fmt), int(t.microsecond) % 1000)
    else:
        return ""
