from mseries.utils import Logger
import re

# the default pattern to use when stripping a name to generate a key
# it default to not word characters
PATTERN = re.compile('\W+')
""" default pattern to remove is \W+ """


class NameEncoder(Logger):
    """ an encoder for names """

    def __init__(self, cfg=None,  name=__name__, ):
        """create a name encoder

        :Parameters:
          - `cfg`: the configuration (which contains the pattern)

        """
        Logger.__init__(self, name=name)
        self._pattern = re.compile(cfg.pattern)

    def key_to_name(self, key):
        """convert key to name by joining portions of the tuple with '_' and replacing pattern with '_'

        :Parameters:
          - `cfg`: the configuration (which contains the pattern)

        """
        k = self._pattern.sub('_', "_".join(key))
        return k

    def strip_key(self, key):
        """ strip key """
        k = self._pattern.sub('_', key)
        return k
