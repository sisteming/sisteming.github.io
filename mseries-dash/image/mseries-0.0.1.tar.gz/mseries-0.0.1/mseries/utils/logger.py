import logging


class Lazy(object):
    def __init__(self, func):
        self.func = func

    def __str__(self):
        return self.func()


class Logger(object):
    """ Logger wrapper class """

    CRITICAL = logging.CRITICAL
    """ critical log level """

    FATAL = logging.FATAL
    """ fatal log level """

    ERROR = logging.ERROR
    """ error log level """

    WARNING = logging.WARNING
    """ warning log level """

    WARN = logging.WARN
    """ warn log level """

    INFO = logging.INFO
    """ info log level """

    DEBUG = logging.DEBUG
    """ debug log level """

    NOTSET = logging.NOTSET
    """ no log level """

    def __init__(self, opts=None, name=__name__):
        """create a logger mixin / base class

        :Parameters:
          - `opts`: the options
          - `name`: the log name defaults to current __name__

        """
        self._logger = None
        self._name = name
        _ = opts

    @property
    def logger(self):
        """ get the logger property """
        if self._logger is None:
            self._logger = Logger.getLogger(self._name)
        return self._logger

    # noinspection PyPep8Naming
    @staticmethod
    def getLogger(name=None):
        """ get a logger property for name

        :Parameters:
          - `name`: the log name defaults to current __name__
        """
        return logging.getLogger(name)
