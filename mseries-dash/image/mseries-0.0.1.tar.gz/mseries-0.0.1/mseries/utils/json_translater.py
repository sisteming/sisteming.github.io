from mseries.utils import Logger
import datetime
import calendar


class JsonTranslater(Logger):
    """ translate json types """

    @classmethod
    def translate(cls, obj):
        """ translate the object into something that can be shown in json """
        if isinstance(obj, datetime.datetime):
            if obj.utcoffset() is not None:
                obj = obj - obj.utcoffset()
            millis = int(calendar.timegm(obj.timetuple()) * 1000 +
                         int(obj.microsecond) / 1000)
            return millis
        return obj
