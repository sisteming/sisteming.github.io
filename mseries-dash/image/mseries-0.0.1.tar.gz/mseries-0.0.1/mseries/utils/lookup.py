from mseries.utils.types import is_int
from functools import reduce


# reduce lookup tuple call
# TODO test arrays
def lookup(doc, name, d=None):
    """lookup name in doc (assuming name is a tuple)

    :Parameters:
      - `doc`: the document
      - `name`: the name
      - `d`: return this value if nothing set

    """
    r = None
    try:
        r = reduce(lambda d, n: d[n] if d is not None else None, name, doc)
    except KeyError:
        try:
            r = reduce(lambda d, n: d[(int(n) if is_int(n) else n)] if d is not None else None, name, doc)
        except (ValueError, TypeError, KeyError):
            pass
    return r if r else d


def update(doc, names, value):
    """update doc based on name tuple

    :Parameters:
      - `doc`: the document
      - `name`: the tuple of names
      - `value`: the value to set

    """
    r = doc
    if len(names) != 1:
        for name in names[0:-1]:
            if isinstance(r, (tuple, list)):
                name = int(name)
                r = r[name]
                continue
            if name in r:
                r = r[name]
    r[names[-1]] = value
