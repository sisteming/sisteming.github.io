import struct
from collections import OrderedDict
from mseries.utils import Logger
from mseries.types import DocReader
from mseries.utils import NameEncoder

try:
    import mseries.native
    UNPACK = mseries.native.rle.unpack
except (ImportError, AttributeError):
    UNPACK = None


class RLEncoder(Logger):
    """ Decode a Run Length Encoded block"""

    def __init__(self, buf, at, cfg, ndeltas=None, metrics=None):
        """create an RLE instance

        :Parameters:
          - `buf`: the buffer containing the array
          - `at`: the location to read from
          - `cfg`: the configuration
          - `ndeltas`: the number of deltas
          - `metrics`: the reference sample (this is used as the base of
          the applied deltas)

        """
        Logger.__init__(self, name=__name__)
        self._buf = buf
        self._at = at
        self.ndeltas = ndeltas
        self.nmetrics = metrics
        self._names = None
        self._tuples = None
        self._cfg = cfg
        if self.nmetrics:
            ne = NameEncoder(self._cfg)
            self._names = []
            self._others = OrderedDict()
            ftdc = []
            tuples = []
            values = []

            total = 0
            for k, v in self.nmetrics.items():
                # value = int(metric_values[0])
                try:
                    values.append(int(v))
                    ftdc.append(ne.key_to_name(k))
                    tuples.append(k)
                    total += 1
                except (TypeError, ValueError):
                    self.logger.debug("%s '%s'", k, v)
                    self._others[ne.key_to_name(k)] = v
            self._names = ftdc
            self._incrementables = tuples
            self._packed = struct.Struct("<{}q".format(len(values))).pack(*values)

    @property
    def names(self):
        """ get the metrics names

        :rtype: list
        """
        return self._names

    @property
    def incrementables(self):
        """ get the incrementable names

        :rtype: list
        """
        return self._incrementables

    @property
    def at(self):
        """ get the location of the deltas in the buffer """
        return self._at

    # rows, return the values by row or by document
    # default is by document (essentially transpose the data
    # from the streamed format)
    def xunpack(self, decode=UNPACK, transpose=True, rate=1):
        """unpack the deltas

        :Parameters:
          - `decode`: the decoder method defaults to the native unpack
          - `transpose`: either return by row (each document, the default) oor by column
          of properties
          - `rate`: the sample rate, default to 1 or 100% of the data. 10 would be 1 in 10 or 10%.
        """
        if decode is None:
            yield None

        at = self._at
        self.logger.debug("all at %d", at)
        ndocs = self.ndeltas
        nmetrics = len(self._names)

        s, self._at = decode(self._buf, self._at, ndocs, nmetrics, self._packed, transpose, rate)
        if s:
            # the following seems about 10 to 20% faster (due to less copies)
            # look at just returning a memory view directly from the glue layer
            s = memoryview(s) if s else None
            if transpose:
                fmt = "<{}q".format(nmetrics)
                doc = struct.Struct(fmt)
                if rate == -1:
                    docs = 1
                else:
                    docs = (ndocs / rate)
                for i in range(docs):
                    values = doc.unpack_from(s, offset=i * nmetrics * 8)
                    yield self._names, values, self._others
            else:
                # TODO : as yet untested
                fmt = "<{}q".format(ndocs)
                doc = struct.Struct(fmt)
                for i in range(nmetrics / rate):
                    values = doc.unpack_from(s, offset=i * ndocs * 8)
                    yield values

    # unpacks ftdc packed ints
    @staticmethod
    def unpack(data, at):
        """ old unpack, this returns a single delta at a time and the new location

        :Parameters:
          - `data`: the  data to unpack
          - `at`: either return by row (each document, the default) oor by column
          of properties
        """
        res = 0
        shift = 0
        while True:
            b, at = DocReader.byte(data, at)
            res |= (b & 0x7F) << shift
            # at += 1
            if not (b & 0x80):
                if res > 0x7fffffffffffffff:  # negative 64-bit value
                    res = int(res - 0x10000000000000000)
                return res, at
            shift += 7

    # TODO something like this but working ;)
    def decode(self, data, first_only=False, ftdc=False):
        """ old decode this only returns by column

        :Parameters:
          - `data`: the  data to unpack
          - `first_only`: get the first value
          - `ftdc`: ftdc data or all data
        """
        i = 0
        incrementable = set()
        values = []
        for k, v in self.metrics.items():
            try:
                values.append(int(v))
                i += 1
                incrementable.add(k)
            except (TypeError, ValueError, ):
                pass

        # only want first value in every chunk?
        if first_only:
            return self.metrics

        # unpack, run-length, delta, transpose the metrics
        nzeroes = 0
        for i, value in enumerate(values):
            metric_values = [value] * self.ndeltas

            if ftdc and isinstance(value, float):
                value = int(value)
                metric_values[-1] = value

            for _ in xrange(self.ndeltas):
                if nzeroes:
                    delta = 0
                    nzeroes -= 1
                else:
                    delta, at = RLEncoder.unpack(data, at)
                    if delta == 0:
                        nzeroes, at = RLEncoder.unpack(data, at)
                value += delta
                metric_values.append(value)

        return None
