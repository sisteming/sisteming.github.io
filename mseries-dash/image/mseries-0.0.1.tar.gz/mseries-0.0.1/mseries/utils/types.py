def is_int(s, base=10):
    """ check if this is an int

    :Parameters:
      - `s`: the string
      - `base`: the number base, defaults to *10*

    :Returns:

      # value or None (so 0 needs to be handled ;)
    """
    try:
        return int(s, base)
    except (ValueError, TypeError):
        return None


def is_float(s):
    """ check if this is a float

    :Parameters:
      - `s`: the string

    :Returns:

      # value or None (so 0.0 needs to be handled ;)
    """
    try:
        return float(s)
    except ValueError:
        return None


# added type float and int to ensure 0 and 0.0 are not false
# TODO check if s == 0 would be better
def is_numeric(s):
    """ check if this is numeric

    :Parameters:
      - `s`: the string

    """
    return type(s) != str and (type(s) == float or type(s) == int or is_int(s) or is_float(s))
