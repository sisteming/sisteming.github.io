from datetime import datetime
import mseries.types
from mseries.utils import JsonTranslater


def flatten(doc, out, measurements=None):
    """flatten the document

    :Parameters:
      - `doc`: the document to flatten
      - `out`: the dict to store the flattened doc in
      - `measurements`: a dict to store interesting fields in. None implies ignore interesting fields

    """
    measurements = measurements if measurements is not None else {}
    return _flatten(doc, out, measurements=measurements)


# traverse the reference document and extract map from metrics keys to values
def _flatten(doc, out, n=(), measurements=None):
    """flatten the document

    :Parameters:
      - `doc`: the document to flatten
      - `out`: the dict to store the flattened doc in
      - `n`: a tuple of the current scope
      - `measurements`: a dict to store interesting fields in. None implies ignore interesting fields

    """
    for k, v in doc.items():
        nn = n + (k,)
        if isinstance(v, dict):
            if measurements is not None and len(nn) == 1:
                measurements[nn] = (len(out), )
            _flatten(v, out, nn, measurements=measurements)
            if measurements is not None and len(nn) == 1:
                measurements[nn] += (len(out), )
        elif isinstance(v, mseries.types.Timestamp):
            value = v
            out[nn + ("t",)] = value["t"]
            out[nn + ("i",)] = value["i"]
        elif isinstance(v, list):
            for i, value in enumerate(v):
                if isinstance(value, mseries.types.BSON):
                    if measurements is not None:
                        if i == 0:
                            measurements[nn] = ()
                        measurements[nn] += (len(out), )
                    _flatten(value, out, nn + (str(i),), measurements=measurements)
                else:
                    out[nn + (str(i),)] = value
        else:
            if isinstance(v, str):
                out[nn] = v
            elif isinstance(v, mseries.types.ObjectId):
                out[nn] = v
            elif isinstance(v, datetime):
                if measurements is not None:
                    measurements[nn] = (v, len(out),)
                out[nn] = JsonTranslater.translate(v)
            else:
                out[nn] = v
    return out
