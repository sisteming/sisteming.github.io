from time import time, strftime, gmtime
import calendar
from datetime import datetime, MAXYEAR, MINYEAR


def to_timestamp(point, fmt="%Y-%m-%dT%H:%M:%S"):
    """ convert value to timestamp
    :Parameters:
      - `point`: the value to convert
      - `fmt`: the date format defaults to *%Y-%m-%dT%H:%M:%S*
    """
    t = point
    if isinstance(point, dict):
        if u'time' in point:
            t = point.pop(u'time')
        elif u'timestamp' in point:
            t = point.pop(u'timestamp')
        elif u'date' in point:
            t = point.pop(u'date')
        else:
            t = point.items()[0][-1]
    if isinstance(t, (str, unicode)):
        return t
    elif isinstance(t, int):
        return from_millis(t, fmt=fmt)
    elif t is not None:
        return "{}.{:03}Z".format(t.strftime(fmt), int(t.microsecond) % 1000)
    else:
        return ""


def from_millis(millis, fmt="%Y-%m-%dT%H:%M:%S"):
    """ convert value to timestamp
    :Parameters:
      - `point`: the value to convert
      - `fmt`: the date format defaults to *%Y-%m-%dT%H:%M:%S*
    """
    return "{}.{:03}Z".format(strftime(fmt, gmtime(millis / 1000)), millis % 1000)


def to_millis(dt):
    return int(calendar.timegm(dt.timetuple()) * 1000 + int(dt.microsecond) / 1000)


def between(times, start, end):
    """
    find all values in times between start and end. all times are returned if
    start and end are None

    :param times: a tuple of millis
    :param start: time or min epoch time
    :param end: time or max epoch time
    :return: tuple of matching times
    """
    if start is None and end is None:
        return times
    frm = to_millis(start or datetime(MINYEAR, 12, 30, tzinfo=None))
    to = to_millis(end or datetime(MAXYEAR, 12, 30, tzinfo=None))

    return tuple(filter(lambda x: ((x >= frm) & (x < to)), times))


def check_between(chunk, cfg, nxt=None):
    """
    determine if the chunk contents are between cfg start and end. if start and end are both
    None, then assume between is true

    :param chunk: the current chunk (to be checked)
    :param nxt: the next chunk identifier in millis, this is used to do a quick between bound check
    :param cfg: the configuration
    :return: a list of timestamps that are between the start / end times
    """
    chunk.config = cfg
    start, end = cfg.start, cfg.end
    if nxt:
        # nxt.config = cfg
        #
        c = to_millis(chunk.identifier)
        # n = to_millis(nxt.identifier)
        n = nxt
        # must be in order or nxt is probably from a different archive, so this
        # test would be invalid
        if c < n:
            if not between((n, c, ), start, end):
                return None
    timestamps = sorted(chunk.timestamps)
    return between(timestamps, start, end)


