"""
Provides functions to read FTDC data from either an FTDC file or from
a file containing serverStatus JSON documents, one per line. Each
reader takes a filename argument and returns a generator that yields a
sequence of chunks. Each chunk is a map from tuples keys to lists, where
the tuple key represents a path through a JSON document from root to leaf,
and the list is a list of values for that path.
"""

import codecs
from itertools import count
from mseries.utils import Logger
from collections import namedtuple
import os
import dateutil.parser
from mseries.types import ObjectId, Timestamp, NumberLong, BSON

seq = count()
Position = namedtuple(u'Position', [u'Filename', u'Offset', u'Line', u'Column'])


class Redo(Exception):
    pass


class Token(int):

    def __new__(cls, i, base=10, name='no name'):
        return super(Token , cls).__new__(cls, str(i), base=base)

    def __init__(self, i, base=10, name='no name'):
        super(Token, self).__init__()
        self._name= name

    def __repr__(self):
        return "{}({})".format(self._name, self)


class Scanner(Logger):
    TokStart = Token(next(seq), name='Start')
    TokAttribute = Token(next(seq), name='Attribute')
    TokCurrent = Token(next(seq), name='Current')
    TokAttributeSeparator = Token(next(seq), name='AttributeSeparator')
    TokValue = Token(next(seq), name='Value')

    TokEOL = Token(next(seq), name='EOL')
    TokIgnore = Token(next(seq), name='Ignore')
    TokEOF = Token(next(seq), name='EOF')

    TokStrings = {
        TokAttribute: "Attribute",
        TokStart: "Start",
        TokCurrent: "Current",
        TokAttributeSeparator: "Separator",
        TokValue: "Value",

        TokEOL: "EOL",
        TokIgnore: "Ignore",
        TokEOF: "EOF",
    }

    ScanStart = 1 << TokStart
    ScanAttribute = 1 << TokAttribute
    ScanAttributeSeparator = 1 << TokAttributeSeparator
    ScanValue = 1 << TokValue
    ScanEOL = 1 << TokEOL

    ModeStrings = {
        ScanStart: "ScanStart",
        ScanAttribute: "ScanAttribute",
        ScanAttributeSeparator: "ScanAttributeSeparator",
        ScanValue: "ScanValue",
        ScanEOL: "ScanEOL",
    }

    GoTokens = ScanStart | ScanAttribute  # | ScanHeading | ScanMetrics
    ScanStarting = ScanStart | ScanAttribute  # | ScanHeading | ScanMetrics

    GoWhitespace = [u'\n', u'\r', u'\t', u' ']
    NulGoWhitespace = [u'\0', u'\n', u'\r', u'\t', u' ']
    NoGoWhitespace = [u'\t', u' ']
    UNINITIALIZED = -2
    CHAR_SIZE = 1
    EOF = ''

    @classmethod
    def mode_to_string(cls, mode):
        s = []
        i = 0
        while mode > 0:
            p = (1 << i)
            if mode & 0x00000001 and p in cls.ModeStrings:
                s.append(cls.ModeStrings[p])
            mode = (mode >> 1)
            i += 1

        if len(s):
            return "{}".format(" | ".join(s))
        else:
            return "(b{:b}".format(mode)

    @classmethod
    def token_to_string(cls, token):
        s = []
        if token and token in cls.TokStrings:
            return cls.TokStrings[token]
        return "({:08X})".format(token)

    def __init__(self, filename, encoding='utf-8', sz=16381, name=__name__):
        Logger.__init__(self, name=name)
        self.filename = filename
        self.encoding = encoding
        self.src = codecs.open(self.filename, encoding=encoding)
        self.src_size = os.path.getsize(self.filename)

        self.guard = 0

        # initialize source buffer
        # (the first call to next() will fill it by calling src.Read)
        self.src_buf_size = sz
        self.src_buf = u''
        self.src_pos = 0
        self.src_end = 0
        self._src_buf_offset = 0

        self._current_line = 0
        self._line = 1

        self._line_buf = u''
        self._column = 0
        self._last_line_len = 0
        self._last_char_len = 1

        # initialize token text buffer
        # (required for first call to next()).
        self.tok_buf = None
        self.tok_pos = -1
        self.tok_end = None

        # initialize one character look-ahead
        self.ch = self.UNINITIALIZED  # no char read yet, not EOF

        # initialize public fields
        self.error = None
        self.error_count = 0
        self.mode = self.ScanStarting
        self.whitespace = self.GoWhitespace

        self.position = None
        self.offset = None
        self.column = None

        self._limit = None

    def line(self):
        if self._line_buf:
            return self._line_buf.rstrip("\n\r")
        return self._line_buf

    def close(self):
        # TODO come back to this
        pass

    def string_token(self):
        return self.token().rstrip("\"'").lstrip("\"'")

    def date_token(self):
        value = self.token().rstrip("\"'").lstrip("\"'")
        if value[2] != u'/':
            datestring = value[9:-2]
        else:
            datestring = value
        return dateutil.parser.parse(datestring)

    def bool_token(self):
        return self.token().rstrip("\"'").lower() == 'true'

    def numeric_token(self):
        return int(self.token())

    def number_long_token(self):
        return NumberLong(self.token()[11:-1].rstrip('\"').lstrip('\"'))

    def object_id_token(self):
        return ObjectId(self.token()[9:-1].rstrip('\"').lstrip('\"'))

    def timestamp_token(self):
        t, i = self.token()[10:-1].split(',')
        return Timestamp([('t', int(t)), ('i', int(i)), ])

    def oplog_token(self):
        _,ts, _, h = self.token().rstrip('}').lstrip('{').split(" ")
        t, i = ts.split(':')
        return BSON([('ts', Timestamp([('t', int(t)), ('i', int(i)), ])), ('h', int(h))])

    def int_token(self):
        return int(self.token())

    def float_token(self):
        return float(self.token())

    def token(self):
        if self.tok_pos < 0:
            # no token text
            return u''

        if self.tok_end < 0:
            self.tok_end = self.tok_pos
        if len(self.tok_buf) == 0:
            # common case: the entire token text is still in srcBuf
            return self.src_buf[self.tok_pos:self.tok_end]

        # part of the token text was saved in tokBuf: save the rest in
        # tokBuf as well and return its content
        self.tok_buf +=  self.src_buf[self.tok_pos:self.tok_end]
        self.tok_pos = self.tok_end  # ensure idempotency of TokenText() call
        return self.tok_buf

    def scan(self):
        return self.scan_to_EOL(self.next())

    def at_eof(self, offs=0):
        eof = (self.src_pos + self._src_buf_offset + offs) >= self.src_size
        if eof or self._limit is None:
            return eof
        limited = (self._src_buf_offset + offs) >= self._limit
        return limited

        # next reads and returns the next Unicode character. It is designed such

    # that only a minimal amount of work needs to be done in the common ASCII
    # case (one test to check for both ASCII and end-of-buffer, and one test
    # to check for newlines).
    def next(self):
        width = self.CHAR_SIZE
        self.fill()

        # at least one byte
        if self.at_eof():
            return self.EOF
        try:
            ch = self.src_buf[self.src_pos]
        except IndexError as e:
            if self.at_eof(self.src_pos) or self.error_count > 0:
                return self.EOF
            raise e

        self._line_buf += ch

        # advance
        self.src_pos += width
        self._last_char_len = width
        self._column += 1

        if ch == 0:
            # for compatibility with other tools
            self.on_error("illegal character NUL")
        elif ch == u'\n':
            self._line += 1
            self._last_line_len = self._column
            self._column = 0
        self.logger.debug("read {}".format(ch))
        return ch

    # next reads and returns the next Unicode character. It is designed such
    # that only a minimal amount of work needs to be done in the common ASCII
    # case (one test to check for both ASCII and end-of-buffer, and one test
    # to check for newlines).
    def fill(self):
        if len(self.src_buf) == 0 or self.src_pos >= len(self.src_buf):
            if self.src.tell() == self.src_size:
                return
            while self.src_pos + self.CHAR_SIZE > self.src_end:
                # not enough bytes: read some more, but first
                # remove read data
                if self.tok_pos >= 0:
                    self.tok_buf += self.src_buf[self.tok_pos:]
                    self.src_buf = self.src_buf[self.tok_pos:]
                    self._src_buf_offset += self.tok_pos
                    self.src_pos -= self.tok_pos
                    self.src_end -= self.tok_pos
                    self.tok_pos = 0
                    self.tok_buf = u""
                else:
                    self.src_buf = u""
                    self._src_buf_offset += self.src_pos
                    self.src_end = 0
                    self.src_pos = 0

                # read more bytes
                # (an io.Reader must return io.EOF when it reaches
                # the end of what it is reading - simply returning
                # n == 0 will make this loop retry forever; but the
                # error is in the reader implementation in that case)
                # noinspection PyBroadException
                try:
                    n = self.src.read(self.src_buf_size)
                    if n == '':
                        self.logger.info("read EOF")
                        raise self.EOF
                    self.src_buf += n
                    self.src_end = self.src_pos + len(n)
                except:
                    self.logger.debug("unexpected exception", exc_info=1)
                    self.on_error("EOF")
                    n = self.EOF

                if n == self.EOF:  # EOF
                    if self.src_end == 0:
                        if self._last_char_len > 0:
                            # previous character was not EOF
                            self._column += 1

                        self._last_char_len = 0
                        return self.EOF

                    # If err == EOF, we won't be getting more
                    # bytes; break to avoid infinite loop. If
                    # err is something else, we don't know if
                    # we can get more bytes; thus also break.
                    break

    # Peek returns the next Unicode character in the source without advancing
    # the scanner. It returns EOF if the scanner's position is at the last
    # character of the source.
    def peek(self, offs=0):
        if self.ch == self.UNINITIALIZED:
            # this code is only run for the very first character
            self.ch = self.next()
            if self.ch in self.whitespace or self.ch == u'\0':
                self.ch = self.skip_whitespace(self.ch, m=self.NulGoWhitespace)

        self.fill()
        if self.at_eof(offs=offs):
            return self.EOF
        return self.src_buf[self.src_pos + offs - 1]

    # Peek returns the next Unicode character in the source without advancing
    # the scanner. It returns EOF if the scanner's position is at the last
    # character of the source.
    def peek_to(self, f):
        return self.src_buf.find(f, start=self.src_pos - 1, end=self.src_end)

    def peek_to_rune(self, c):
        p = self.src_pos # -1
        while True:
            if p == self.src_end or self.src_buf[p] == c:
                break
            p += 1

        return self.src_buf[self.src_pos - 1:p], p == self.src_end

    def pos(self):
        if self._column > 0:
            # common case: last character was not a '\n'
            line = self._line
            column = self._column
        elif self._last_line_len > 0:
            # last character was a '\n'
            line = self._line - 1
            column = self._last_line_len
        else:
            # at the beginning of the source
            line = 1
            column = 1
        self.position = Position(Filename=self.filename,
                                 Offset=self._src_buf_offset + self.src_pos - self._last_char_len,
                                 Line=line, Column=column)
        return self.position

    def on_error(self, msg):

        pos = self.position
        if pos is None:
            pos = self.pos()

        self.error_count += 1
        if self.error is not None:
            self.error(msg, pos)
            return

        self.logger.warn("on error: {}: {} ->{}".format(self.__class__.__name__, pos, msg), exc_info=1)

    @staticmethod
    def is_decimal(ch):
        return ch == '.' or ch.isdigit()

    @staticmethod
    def is_value(ch, i, m=None):
        if m is not None:
            return m(ch, i)
        # TODO check ':' in this case
        return ch == '.' or ch == ':' or ch == '_' or ch == '-' or ch == '/' or ch.isalpha() or ch.isdigit() and i > 0

    @staticmethod
    def is_ident(ch, i, m=None):
        # if self.IsIdentRune is not None:
        #     return self.IsIdentRune(ch, i)
        if m is not None:
            return m(ch, i)
        return ch == '_' or ch == '-' or ch.isalpha() or ch.isdigit() and i > 0

    def _scan_value(self, ch):
        # we know the zero'th rune is OK; start scanning at the next one (also it could be a *)
        self.logger.debug("scan value %s", ch)
        ch = self.next()
        i = 1
        while self.is_value(ch, i):
            i += 1
            ch = self.next()
        return ch

    def _scan_identifier(self, m=None):
        # we know the zero'th rune is OK; start scanning at the next one
        ch = self.next()
        i = 1
        while self.is_ident(ch, i, m=m):
            ch = self.next()
            i += 1
        return ch

    # 4294967295 max long == 10 digits so default n to 12 ;)
    def scan_digits(self, ch, n=12, base=10):
        while n > 0 and int(ch, base) < base:
            ch = self.next()
            n -= 1

        if n > 0:
            self.on_error("illegal char escape")

        return ch

    def skip_whitespace(self, ch, m=None):
        if m is None or len(m) == 0:
            m=self.whitespace
        # skip white space
        while ch in m:
            ch = self.next()
        return ch

    def _text(self):
        return self.src_buf[self.tok_pos:self.src_pos]

    def _scan_to(self, ch, *chars):
        #  read character after '`'
        while ch not in chars:
            ch = self.next()
        return ch

    def scan_to_EOL(self, ch):
        ch = self._scan_to(ch, u'\n')
        self.mode = self.ScanStarting
        value = self._text()
        self.logger.info('scan_to_EOL %s', value)
        return self.TokEOL, ch
