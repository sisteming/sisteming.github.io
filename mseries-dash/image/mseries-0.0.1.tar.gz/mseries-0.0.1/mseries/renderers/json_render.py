from collections import OrderedDict
import json
from mseries.renderers.renderer import Renderer
from mseries.utils import JsonTranslater


class JsonRenderer(Renderer):

    def __init__(self, opts=None):
        Renderer.__init__(self, opts)

    @staticmethod
    def get_values(points, pos, matcher=None):
        values = OrderedDict()
        for key in points:
            if matcher is None or matcher(key):
                doc = values
                for k in key[:-1]:
                    if k not in doc:
                        doc[k] = OrderedDict()
                    doc = doc[k]

                doc[key[-1]] = points[key][pos]
        return values

    def doc(self, chunk, pb=None, ftdc=False, typed=False):
        doc = []
        ts = chunk['_id']
        if pb:
            pb.update(ts=ts)

        if chunk['type'] == 0:
            self.logger.debug('meta')
            if pb:
                pb.update(points=1)
            doc = chunk['doc']
            self.logger.info("meta done")
        else:
            # # Todo come back to this
            # raise 'error'
            from mseries.ftdc import FtdcMetrics
            metrics = FtdcMetrics(chunk['data'])
            self.logger.info("chunk contains {} samples for {} metrics".format(metrics.nsamples, metrics.nmetrics))

            points = metrics.decode()
            matcher = None
            if points:
                for pos in range(0, metrics.nsamples):
                    values = self.get_values(points, pos, matcher=matcher)
                    doc.append(values)
                    if pb:
                        pb.update(points=1)
                self.logger.info("chunk done")

        return json.dumps(doc, indent=3, default=JsonTranslater.translate)
