from mseries.utils import Logger


class Renderer(Logger):
    def __init__(self, opts=None):
        Logger.__init__(self, name=__name__)
        self._opts = opts

    @property
    def opts(self):
        return self._opts

    def doc(self, points):
        raise NotImplementedError("Please Implement this method")
