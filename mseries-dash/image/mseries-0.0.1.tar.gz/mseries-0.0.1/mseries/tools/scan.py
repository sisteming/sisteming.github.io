"""
Command Line::

 usage:
    mseries scan [options...] [--] [<file>...]
    mseries [options...] [--] [<file>...]

 options:
   -c <name=value>
   --start=<time>    find from `start` time (or all)
   --end=<time>      find to `end` time (or all). A <from> and <to> is all between.
   -h, --help
   -k, --keys
   -v, --verbose
   -t, --timestamps

"""
from __future__ import print_function
from os.path import basename
from docopt import docopt, DocoptExit
from mseries.tools import *
from mseries.archive import Archive
from mseries.utils import check_between, to_millis, from_millis, to_timestamp

logger = None


def do_list(args):
    """
    :type args: dict
    """

    cfg = configuration(args)
    verbosity= args['--verbose']
    for name in list_files(args['<file>']):
        # actually pairs of chunks
        chunks = list(read_file(name, Archive.all()))
        l = len(chunks)
        print('{} contains {} chunk{}'.format(name, len(chunks), '' if l == 1 else 's'))
        for i, chunk in enumerate(chunks):
            if i + 1 < len(chunks):
                chunks[i + 1].config = cfg
                nxt = to_millis(chunks[i + 1].identifier)
            else:
                nxt = None

            btwn = check_between(chunk, cfg, nxt=nxt)
            if btwn:
                if chunk.category == Archive.METADATA_TYPE:
                    print("\t{} metadata".format(chunk.timestamp))
                else:
                    samples = len(btwn)
                    print("\t{}".format(chunk.timestamp), end="")
                    if verbosity > 0:
                        if verbosity == 1:
                            print("({0:6.2f})".format((btwn[-1] - btwn[0]) / 1000.0), end="")
                        else:
                            print(" => {}".format(to_timestamp(btwn[-1])), end="")
                    print(", {:3} samples ".format(samples), end="")
                    if verbosity > 1:
                        print("({0:5.2f} s/s)".format((btwn[-1] - btwn[0]) / (len(btwn) * 1000.0)), end="")
                    print(", {:3} properties ".format(chunk.metrics.nmetrics), end="")
                    if verbosity > 2:
                        filename = chunk.filename
                        if verbosity == 3:
                            filename=basename(filename)
                        print("{}".format(filename), end="")
                    print()
                    if args['--keys']:
                        for k in chunk.metrics.keys():
                            print("\t\t{} ".format(".".join(k) if isinstance(k, (list, tuple)) else k))
                    if args['--timestamps']:
                        for millis in btwn:
                            print("\t\t{}  : {}".format(from_millis(millis), chunk.filename))


def scan(argv=None):
    arguments = docopt(__doc__, version='mseries scan version 0.0', argv=argv)
    global logger
    logger = init_logging(arguments)
    try:
        do_list(arguments)

    except DocoptExit as e:
        print(e.usage)


if __name__ == '__main__':
    scan()
