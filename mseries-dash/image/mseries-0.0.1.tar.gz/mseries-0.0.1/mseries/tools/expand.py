"""
usage:
    mseries expand [options...] [--] [<file>...]
    mseries [options...] [--] [<file>...]

options:
   --no-progressbar
   --no-metadata        dump meta data [default: False]
   --no-metrics         dump metrics data [default: False]
   -c <name=value>
   --uri=URI         the default endpoint
   --after=<time>    find matches after time
   -h, --help

"""

from mseries.tools.utils import *
from docopt import docopt, DocoptExit
from mseries.tools.utils import list_files, read_file
from mseries.renderers.json_render import JsonRenderer
from mseries.archive import Archive


def do_list(args, makepbar):
    """
    :type args: dict of processed command line args
    :param makepbar: progress bar factory, assumes not None
    """

    for name in list_files(args['<file>']):
        renderer = JsonRenderer(args)
        pb = makepbar(name)
        chunks = list(read_file(name, Archive.all()))
        for chunk in pb(chunks):
            if chunk.type_str == 'metadata' and args['--no-metadata']:
                continue
            if chunk.type_str == 'metrics' and args['--no-metrics']:
                continue
            print(renderer.doc(chunk, pb=pb))


def expand(argv=None):
    arguments = docopt(__doc__, version='mseries expand version 0.0', argv=argv)
    init_logging(arguments)
    if '--no-progressbar' not in arguments or not arguments['--no-progressbar']:
        fn = make_pbar
    else:
        fn = make_dummy
    try:
        do_list(arguments, makepbar=fn)
    except DocoptExit as e:
        print(e.usage)


if __name__ == '__main__':
    expand()
