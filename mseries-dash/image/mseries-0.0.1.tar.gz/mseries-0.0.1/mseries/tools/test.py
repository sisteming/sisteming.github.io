"""
usage:
    mseries test [options...] [--] [<file>...]
    mseries [options...] [--] [<file>...]

options:
   --no-progressbar
   --no-metadata        dump meta data [default: False]
   --no-metrics         dump metrics data [default: False]
   -c <name=value>
   --uri=URI         the default endpoint
   --after=<time>    find matches after time
   -h, --help

"""
from docopt import docopt, DocoptExit
from mseries.tools.utils import list_files
# from mseries.tools.utils import *
# from mseries.server_status import ServerStatusArchive
# from mseries.backup_agent import BackupAgentArchive
from collections import namedtuple
logger = None


Time = namedtuple(u'Time', [u'filename', u'line', u'time', u'name'])


def do_test(args, makepbar):
    """
    :type args: dict of processed command line args
    :param makepbar: progress bar factory, assumes not None
    """
    global logger
    for name in list_files(args['<file>']):
        archive = BackupAgentArchive(name)
        valid = None
        if not archive.is_valid():
            archive = ServerStatusArchive(name)
        else:
            valid = True
        if not valid and archive.is_valid():
            valid = True
        if valid:
            with archive as scanner:
                for metrics in scanner.scan():
                    if metrics.valid():
                        print('{} has {} samples with {} metrics'.format(metrics._id(), len(metrics.attributes), len(metrics.attributes[0] if len(metrics.attributes) else 0)))
        else:
            print('not a server status')


def test(argv=None):
    global logger
    arguments = docopt(__doc__, version='mseries expand version 0.0', argv=argv)
    logger = init_logging(arguments)
    if '--no-progressbar' not in arguments or not arguments['--no-progressbar']:
        fn = make_pbar
    else:
        fn = make_dummy
    try:
        do_test(arguments, makepbar=fn)
    except DocoptExit as e:
        print(e.usage)


if __name__ == '__main__':
    test()
