"""
Command Line::

 usage:
    mseries write [options...] [--] [<file>...]
    mseries [options...] [--] [<file>...]

 options:
   --no-progressbar
   -c <name=value>
   --pool=<processes>     the number of processes in the pool, defaults to all
   --project=<project>    the project name [default: mseries]
   --pipeline=<pipeline>  a pipeline [default: lag duration time  latency]
   --uri=URI              the default endpoint
   --collection=<col>     the collection name[default: points].
   --batch=<size>         the batch size to use[default: 50].
   --tz=<tz>              the tz to use [default: UTC].
   --sample=<sample>      the sample ratio, ie. 1 in <sample> [default: 1].
   --date=<date>          the time to start from if the not stored in the date [default: midnight last night].
   --start=<time>         find from `start` time (or all)
   --end=<time>           find to `end` time (or all). A <from> and <to> is all between.
   --pattern=<PATTERN>    the pattern to use transforming names, no value will default to \W+ unless
                          the writer overrides it
   -h, --help

"""
from docopt import docopt, DocoptExit
import mseries
from mseries.tools.utils import *
from mseries.archive import Archive
from mseries.writers import WriterFactory
from mseries.tools import init_logging
from mseries.pipelines import PipelineFactory
from multiprocessing import Process, JoinableQueue, Queue, Manager
from mseries.utils import Logger
from mseries.tasks import WriterTask
import threading


class ProcessPBar:
    def __init__(self, q):
        self.q = q

    def __call__(self, i):
        return i

    def update(self, *args, **kwargs):
        self.q.put({'name': 'update', 'args': args, 'kwargs': kwargs})

    def finish(self, *args, **kwargs):
        pass


class Consumer(Process, Logger):
    def __init__(self, task_queue, result_queue, progress, args, cfg, name=None):
        Process.__init__(self, name=name)
        Logger.__init__(self, name=__name__)
        self.task_queue = task_queue
        self._cfg = cfg
        self.result_queue = result_queue
        self.writer = WriterFactory.create(cfg.uri, cfg)
        self.pipeline = PipelineFactory.create(cfg.pipeline, args, cfg)
        self.pb = progress

    def run(self):
        while True:
            next_task = self.task_queue.get()
            if next_task is None:
                # Poison pill means shutdown
                self.logger.debug('%s: Exiting', self.name)
                self.task_queue.task_done()
                break
            answer = self.process(next_task)
            self.task_queue.task_done()
            self.result_queue.put({"result": answer})
        return

    def process(self, next_task):
        # noinspection PyBroadException
        try:
            if next_task:
                next_task.configuration = self._cfg
                next_task.pb = self.pb
                next_task.writer = self.writer
                next_task.pipeline = self.pipeline
                return next_task()
            else:
                return None
        except:
            self.logger.warn("process error", exc_info=1)
            pass

    # duck type queue
    def put_nowait(self, obj):
        self.process(obj)

    def close(self):
        pass

    def join(self, timeout=None):
        pass

logger = None


def do_list(args, makepbar=None):
    """
    :type args: dict of processed command line args
    :param makepbar: progress bar factory, assumes not None
    """
    global logger
    cfg = configuration(args)

    # Start consumers
    num_consumers = cfg.pool

    for name in list_files(args['<file>']):

        size = os.stat(name).st_size
        pb = makepbar(name, maxval=size)

        tasks = JoinableQueue()
        results = Queue()
        manager = Manager()
        t = None
        lock = threading.Lock()

        if num_consumers == 1:

            class InlineProgress(object):
                def __init__(self):
                    self._size = 0
                    self._points = 0

                def update(self, *args, **kwargs):
                    if 'size' in kwargs:
                        self._size += kwargs['size']
                        del kwargs['size']
                        kwargs['value'] = self._size
                    if 'points' in kwargs:
                        self._points += kwargs['points']
                    kwargs['points'] = self._points
                    # pb.update(*args, **kwargs)
                    pb.update(*args, **kwargs)

            progress = InlineProgress()
            consumers = [Consumer(tasks, results, progress, args, cfg, name="process-{}".format(i))
                         for i in range(num_consumers)]
            tasks = consumers[0]

        else:
            progress = manager.Queue()
            logger.debug('Creating %d consumers', num_consumers)
            consumers = [Consumer(tasks, results, ProcessPBar(progress), args, cfg, name="process-{}".format(i))
                         for i in range(num_consumers)]

            pb.start(size)

            def worker():
                """thread worker function"""
                points = 0
                value = 0
                logger.debug('progress')
                while True:
                    p = progress.get()
                    if p is None:
                        break
                    if 'points' in p['kwargs']:
                        points += p['kwargs']['points']
                    if 'size' in p['kwargs']:
                        value += p['kwargs']['size']
                        p['kwargs']['value'] = value
                        del p['kwargs']['size']
                        if not p['args']:
                            p['args'] = {}
                    p['kwargs']['points'] = points
                    pb.update(*p['args'], **p['kwargs'])
                return

            t = threading.Thread(target=worker)
            t.start()

        chunks = list(read_file(name, Archive.all()))
        for i, chunk in enumerate(chunks):
            # a bit annoying to put the chunk on the list to eval but ....
            if i+1 < len(chunks):
                chunks[i+1].config = cfg
                nxt = to_millis(chunks[i+1].identifier)
            else:
                nxt = None
            chunk.configuration = cfg
            memo = chunk.memo
            tasks.put_nowait(WriterTask(memo, progress, nxt=nxt))

        for w in consumers:
            w.start()

        # Add a poison pill for each consumer
        for i in range(num_consumers):
            tasks.put_nowait(None)

        if num_consumers == 1:
            size = 0

        try:
            pos = size
            # Start printing results
            while pos:
                result = results.get()
                try:
                    if result:
                        logger.debug('Result: %r', result)
                        if 'result' in result and result['result']:
                            pos -= result['result']
                        pb.update(size - pos, *result)
                except:
                    logger.error("Unexpected exception", exc_info=1)
        except:
            logger.error("Unexpected exception", exc_info=1)
            tasks.close()

        if t:
            progress.put(None)
            t.join()
        with lock:
            pb.finish()

        # Wait for all of the tasks to finish
        tasks.join()


def write(argv=None):
    arguments = docopt(__doc__, version='mseries expand version {}'.format(mseries.__version__), argv=argv)
    global logger
    logger = init_logging(arguments)
    if '--no-progressbar' not in arguments or not arguments['--no-progressbar']:
        fn = make_pbar
    else:
        fn = make_dummy
    try:
        do_list(arguments, makepbar=fn)
    except DocoptExit as e:
        logger.error("exception", exc_info=1)
        print(e.usage)


if __name__ == '__main__':
    write()
