import os
import site
import logging
import locale
from collections import namedtuple
from multiprocessing import cpu_count
from pytz import timezone, UnknownTimeZoneError
from logging.config import fileConfig
# noinspection PyPackageRequirements
from progressbar import ProgressBar, Bar, Percentage, Counter, UnknownLength, ETA, DynamicMessage
from datetime import datetime
import dateparser
import dateutil.parser
from itertools import tee, izip

locale.setlocale(locale.LC_ALL, '')


def list_files(flist):
    for fn in flist:
        if os.path.isdir(fn):
            for f in sorted(os.listdir(fn)):
                yield os.path.join(fn, f)
        else:
            yield fn


# archives=[MongoStatArchive, BackupAgentArchive, FtdcArchive]):
def read_file(fn, archives):
    archive = next(archive(fn) for archive in archives if archive(fn).is_valid())
    if archive.is_valid():
        for c in archive.read():
            yield c
        #
        # yield archive


class DummyPBar:
    def __init__(self):
        pass

    def __call__(self, i):
        return i

    def update(self, *args, **kwargs):
        pass

    def finish(self, *args, **kwargs):
        pass


# noinspection PyUnusedLocal
def make_dummy(*args, **kwargs):
    return DummyPBar()


class DynamicTsMessage(DynamicMessage):
    """Displays a custom variable."""

    def __init__(self, name):
        """Creates a DynamicMessage associated with the given name."""
        DynamicMessage.__init__(self, name)
        if not isinstance(name, str):
            raise TypeError('DynamicMessage(): argument must be a string')
        if len(name.split()) > 1:
            raise ValueError(
                'DynamicMessage(): argument must be single word')

        self.name = name

    def __call__(self, progress, data):
        val = data['dynamic_messages'][self.name]
        if val:
            return ' {}'.format(val)
        else:
            return ' ' + (19 * '-')


class DynamicIntMessage(DynamicMessage):
    """Displays a custom variable."""

    def __init__(self, name):
        """Creates a DynamicMessage associated with the given name."""
        DynamicMessage.__init__(self, name)
        if not isinstance(name, str):
            raise TypeError('DynamicMessage(): argument must be a string')
        if len(name.split()) > 1:
            raise ValueError(
                'DynamicMessage(): argument must be single word')

        self.name = name

    def __call__(self, progress, data):
        val = data['dynamic_messages'][self.name]
        if val:
            return '{:10n}'.format(val)
        else:
            return '{:10}'.format('points')


def make_pbar(title, maxval=100):
    title = "{:28}".format(os.path.basename(title)[0:27])
    eta = ETA(format_not_started='ETA:  --:--:--',
              format_finished='Time: %(elapsed)s',
              format='ETA:  %(eta)s',
              format_zero='ETA:  0:00:00')
    dm = DynamicTsMessage('ts')
    points = DynamicIntMessage('points')
    if maxval is None or maxval <= 0:
        pbar = ProgressBar(widgets=[" | ", title, " | ", eta, Bar(), " | ", Counter(), " of {}".format(maxval), " | ",
                                    dm, " | ", points, " |"],
                           maxval=UnknownLength).start()
    else:
        # pbar = ProgressBar(widgets=["| ", title, " | ", eta, " | ", Percentage(), Bar(right='| ', left=' |'),
        pbar = ProgressBar(widgets=["| ", title, " | ", eta, " | ", Percentage(), Bar(right='| ', left=' |'),
                                    dm, " | ", points, " |"], maxval=maxval).start()
    return pbar


DEFAULTS = {'filename': '/tmp/mseries.log',
            # 'level': 'INFO',
            'level': 'DEBUG',
            'format': "%(asctime)s %(levelname)s %(filename)s:%(lineno)d %(message)s"}


def run_once(f):
    def wrapper(*args, **kwargs):
        if not wrapper.has_run:
            wrapper.has_run = True
            wrapper.rv = f(*args, **kwargs)
            return wrapper.rv
        else:
            return wrapper.rv

    wrapper.has_run = False
    return wrapper


@run_once
def init_logging(args):
    kwargs = {}
    for kv in args['-c']:
        if kv.startswith('logging.'):
            key, value = kv.split('=')
            kwargs[key[len('logging.'):]] = value
    kwargs.update(DEFAULTS)
    # noinspection PyBroadException
    try:
        paths = ['~/logging.ini', './config/logging.ini']
        paths.extend([os.path.join(p, 'config', 'logging.ini') for p in site.PREFIXES])
        for cfg in paths:
            if os.path.isfile(cfg):
                logging.config.fileConfig(cfg)
                break
    except:
        pass
    return logging.getLogger()


def int_value(dictionary, name, default=0):
    return int(str_value(dictionary, name, default=str(default)))


def str_value(dictionary, name, default=''):
    if name in dictionary:
        v = dictionary[name]
        if v and isinstance(v, (list, tuple)):
            v = v[0]
        else:
            v = default
    else:
        v = default
    return v


def tz(_tz):
    try:
        _tz = timezone(_tz)
    except UnknownTimeZoneError:
        _tz = None
    return _tz


# noinspection PyUnresolvedReferences
def date(dt, zone=None):
    if isinstance(dt, (datetime)):
        return dt
    if isinstance(dt, (list, tuple)):
        dt = " ".join(dt)
    try:
        # let's assume it is a date first
        dt = dateutil.parser.parse(dt, tzinfos=[zone] if zone else zone)
        dt = dt.replace(tzinfo=None)
    except (ValueError, OverflowError):
        init_logging().warn("error", exc_info=1)
        dt = dateparser.parse(dt)
    return dt

PATTERN = '(\W+|\.)+'


def configuration(args):
    items = filter(lambda kv: kv[0].startswith('--') and kv[0] != '--' and '-' not in kv[0][2:], args.items())

    cfg = dict(map(lambda kv: (kv[0][2:], kv[1]), items))

    cfg['batch'] = int_value(cfg, 'batch')
    cfg['sample'] = int_value(cfg, 'sample')
    cfg['pool'] = int_value(cfg, 'pool', default=cpu_count())
    cfg['collection'] = str_value(cfg, 'collection')
    cfg['uri'] = str_value(cfg, 'uri') or os.environ.get('MSERIES_URI') or 'mongodb://localhost/mseries'
    cfg['project'] = str_value(cfg, 'project')
    cfg['tz'] = tz(str_value(cfg, 'tz'))
    cfg['date'] = date(str_value(cfg, 'date'), cfg['tz'])
    # noinspection PyTypeChecker
    pattern = str_value(cfg, 'pattern', default=None)
    if pattern is None:
        pattern = PATTERN
        # TODO hard coding this here is not great but come back later
        if not cfg['uri'].startswith('mongodb'):
            pattern = '[^0-9a-zA-Z_\.]+'
    cfg['pattern'] = pattern or PATTERN
    cfg['files'] = args['<file>']
    cfg['start'] = str_value(cfg, 'start', None)
    if cfg['start']:
        cfg['start'] = date(cfg['start'], cfg['tz'])
    cfg['end'] = str_value(cfg, 'end', None)
    if cfg['end']:
        cfg['end'] = date(cfg['end'], cfg['tz'])

    if cfg['start'] and cfg['end'] and cfg['start'] > cfg['end']:
        cfg['start'], cfg['end'] = cfg['end'], cfg['start']

    _ConfigurationBase = namedtuple('Configuration', set(cfg.keys() + ['files']))

    class Configuration(_ConfigurationBase):
        __slots__ = ()
        pass
    return Configuration(**cfg)
    # return Configuration(**dict((k, v) for k, v in cfg.iteritems() if v is not None))


EPOCH = datetime.utcfromtimestamp(0)


def to_millis(timestamp):
    if timestamp is None:
        timestamp = datetime.utcnow()
    return (timestamp - EPOCH).total_seconds() * 1000


# http://stackoverflow.com/questions/5764782/iterate-through-pairs-of-items-in-a-python-list
def pairwise(iterable):
    """s -> (s0,s1), (s1,s2), (s2, s3), ..."""
    a, b = tee(iterable)
    next(b, None)
    return izip(a, b)
