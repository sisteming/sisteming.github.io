#!/usr/bin/env python

"""
Command Line::

 Usage:
   mseries <command> [options...] [--] [<file>...]

 Commands:
   write      write the contents to the uri
   scan       scan the contents of the archives
   help       the help
 Options:
   -c <name=value>
   --uri=URI             the default endpoint
   --project=<project>  the project name [default: mseries]
   --after=<time>        find matches after time
   -h, --help
   -k, --keys
   -v, --verbose
   --version
   --pool=<processes>     the number of processes in the pool, defaults to all
   --no-progressbar
   --pattern=<PATTERN>    the pattern to use transforming names, no value will default to \W+ unless
                          the writer overrides it
   --no-metadata          dump meta data [default: False]
   --no-metrics           dump metrics data [default: False]
   --pretty
   --collection=<col>     the collection name[default: points].
   --batch=<size>         the batch size to use[default: 50].
   --tz=<tz>              the tz to use [default: UTC].
   --date=<date>          the time to start from if the not stored in the date [default: midnight last night].
   --start=<date>         the time to start from if the not stored in the date [default: midnight last night].
   --end=<date>           the time to start from if the not stored in the date [default: midnight last night].
   --sample=<sample>      the sample ratio, ie. 1 in <sample> [default: 1].
   -t, --timestamps       dump the timestamps
 See 'mseries help <command>' for more information on a specific command.
"""
from docopt import docopt, printable_usage, DocoptExit
import mseries
from mseries.tools import *


def main(argv=None):
    arguments = docopt(__doc__, version='mseries version {}'.format(mseries.__version__), argv=argv)

    logger = init_logging(arguments)
    try:
        command = scan
        if arguments['<command>'] == 'help':
            print(printable_usage(__doc__))
            exit(0)
        # elif arguments['<command>'] == 'import':
        #     from writer import main as command
        elif arguments['<command>'] == 'expand':
            command = expand
        elif arguments['<command>'] == 'write':
            command = write
        elif arguments['<command>'] == 'help':
            print(printable_usage(__doc__))
            exit(0)
        # elif '<command>' not in arguments or arguments['<command>'] == 'scan':
        #     from scanner import main as command
        else:
            command = scan

        command()

    except DocoptExit as e:
        logger.error("exception", exc_info=1)
        print(e.usage)


if __name__ == '__main__':
    main()