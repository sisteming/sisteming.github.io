"""
Provides functions to read FTDC data from either an FTDC file or from
a file containing serverStatus JSON documents, one per line. Each
reader takes a filename argument and returns a generator that yields a
sequence of chunks. Each chunk is a map from tuples keys to lists, where
the tuple key represents a path through a JSON document from root to leaf,
and the list is a list of values for that path.
"""
from collections import OrderedDict

from mseries.archive import AllMatcher
from mseries.backup_agent.backup_agent_scanner import BackupAgentScanner
from mseries.utils import Logger, JsonTranslater
from datetime import datetime
import calendar
from mseries.tools.utils import configuration
from mseries.types import BSON
from mseries.archive import Archive
from mseries.utils import is_int, to_timestamp, flatten
import humanfriendly
import os
import json


class BackupAgentMetric:
    def __init__(self):
        self._current = None
        self._start = None
        self._values = None
        self._attributes = None
        self._connected_to = None
        self._start_timestamp = None
        self._measurements = None

    def valid(self):
        return self._current or self._attributes is not None

    def static_tags(self, args, point, **kwargs):
        return OrderedDict(filter(lambda kv: kv[1] is not None, kwargs.items()))

    def dynamic_tags(self, args, point, **kwargs):
        return None

    def measurements(self):
        if self._measurements is None:
            self._measurements = [AllMatcher(u'BackupAgents')]
        return self._measurements

    def idecode(self, *args, **kwargs):
        for a in self._attributes:
            yield a

    def category(self):
        return 1

    def identifier(self):
        return self._start_timestamp

    @property
    def attributes(self):
        if self._attributes is None:
            self._attributes = []
        return self._attributes

    @property
    def timestamp(self):
        return self._start_timestamp

    @property
    def nmetrics(self):
        if self._attributes is None:
            return 0
        return len(self._attributes[0])

    @property
    def nsamples(self):
        if self._attributes is None:
            return 0
        return len(self._attributes)

    def add_metrics(self, metrics):
        metric = []
        for k, v in metrics.items() if isinstance(metrics, dict) else metrics:
            self.set_metric(metric, k, v)
            if self._start_timestamp is None and ".".join(k) in [u'time', u'date']:
                self._start_timestamp = datetime.utcfromtimestamp(v / 1000.0)
        self.attributes.append(metric)
        return metric

    def set(self, name, value):
        if name == u'Current Time':
            self._current = self.parse_timestamp(value)
        elif name == u'Start Time':
            self._start = self.parse_timestamp(value)
        elif name == u'connected to':
            self._connected_to = value

    @classmethod
    def parse_timestamp(cls, v, fmt="%Y%m%dT%H%M%S"):
        return datetime.strptime(v, fmt)

    @classmethod
    def set_metric(cls, attributes, name, value):
        if name in [u'insert', u'query', u'update', u'delete', u'getmore']:
            replicated = value[0] == u'*'
            if replicated:
                name += u'_repl'
                value = value[1:]
            attributes.append((name, int(value),))
        elif name == u'command %' or name == u'command %':
            local, replicated = value.split('|')
            attributes.append((u'command', int(local),))
            attributes.append((u'command_repl', int(replicated),))
        elif u'|' in name:
            first, last = name.split('|')
            readers, writers = value.split('|')
            attributes.append((first, int(readers),))
            attributes.append((last, int(writers),))
        elif name == u'used' or name[-1] == u'%':
            name = name.rstrip(u' %')
            attributes.append((name, float(value)))
        elif name in [u'flushes']:
            attributes.append((name, int(value)))
        elif name in [u'vsize', u'res', u'netIn', u'netOut']:
            try:
                attributes.append((name, humanfriendly.parse_size(value, binary=True)))
            except humanfriendly.InvalidSize:
                attributes.append((name, value))
        elif name in [u'set', u'repl', u'conn']:
            attributes.append((name, value))
        else:
            attributes.append((name, value))



class BackupAgentArchiveMemo(object):
    def __init__(self, archive):
        self._filename = archive.filename
        self._configuration = archive.configuration._asdict()

    def from_memo(self):
        archive= BackupAgentArchive(self._filename)
        archive.configuration = configuration(self._configuration)
        return archive

    @property
    def identifier(self):
        return self._filename

    @property
    def filename(self):
        return self._filename

    @property
    def category(self):
        return 1


class BackupAgentArchive(Archive):
    CT_HEADER = 'Current Time : '
    ST_HEADER = 'Start Time : '
    INSERT = 'insert '

    def __init__(self, fn):
        # Logger.__init__(self, name=__name__)
        Archive.__init__(self, name=__name__)
        self._filename = fn
        self._scanner = None
        self._valid = None
        self._category = 1
        self._start_timestamp = None
        self._end_timestamp = None
        self._stats = None

    @property
    def memo(self):
        return BackupAgentArchiveMemo(self)

    def from_memo(self):
        return self

    def __enter__(self):
        return self

    def __exit__(self, tt, value, traceback):
        self.scanner.close()
        self._scanner = None

    def _type(self, tt, value, traceback):
        self.logger.debug("_type %s %s %s", tt, value, traceback)
        self.scanner.close()
        self._scanner = None

    def is_valid(self):
        if self._valid is None:
            err = None
            pos = None

            def on_error(e, p):
                global err
                global pos
                err = e
                pos = p

            try:
                with self as archive:
                    scanner = archive.scanner
                    tok = scanner.scan(limit=1024, error=on_error)
                    archive._valid = (tok == self.scanner.TokStartBracket)
            except:
                self.logger.warn("valid", exc_info=1)
                self._valid = False
        return self._valid

    @property
    def scanner(self):
        if self._scanner is None:
            self._scanner = BackupAgentScanner(self._filename)
        return self._scanner

    def from_memo(self):
        return self

    @property
    def _id(self):
        if self.metrics:
            return self.metrics.timestamp
        return 0

    def to_progress(self, l):
        if self.metrics:
            return to_timestamp(self.metrics.timestamp)[0:l - 1]
        fn = self.filename
        if len(self.filename) < l:
            fn = os.path.basename(fn)
        return fn[0:l - 1]

    @property
    def filename(self):
        return self._filename

    @property
    def category(self):
        return self._category

    @property
    def timestamp(self):
        return self.start_timestamp

    @property
    def start_timestamp(self):
        return self._start_timestamp

    def close(self):
        if self._scanner is not None:
            self._scanner.close()
            self._scanner = None

    def add(self, metric):
        self.metrics.append(metric)

    @classmethod
    def _consume_whitespace(cls, scanner, tok):
        return cls._consume_until(scanner, tok, scanner.TokEOL, scanner.TokEOF, scanner.TokIgnore)

    @classmethod
    def _consume_to_eol(cls, scanner, tok):
        tok = cls._consume_to(scanner, tok, scanner.TokEOL, scanner.TokEOF)
        t = scanner.token()
        scanner.logger.info(t)
        return tok

    @classmethod
    def _consume_to(cls, scanner, tok, *tokens):
        scanner.logger.info("_consume_to_tokens: current token %s", str(tok))
        while tok not in tokens and tok != scanner.TokEOF:
            tok = scanner.scan()
            scanner.logger.info("_consume_to_tokens: current token %s", scanner.line())
        scanner.logger.debug("_consume_to_tokens: current token %s", scanner.token_to_string(tok))
        return tok

    @classmethod
    def _consume_until(cls, scanner, tok, *tokens):
        while tok in tokens:
            tok = scanner.scan()
        scanner.logger.debug("_consume_until_tokens: current token %s", scanner.token_to_string(tok))
        return tok

    @classmethod
    def _consume_timestamp(cls, scanner, tok):
        assert scanner.TokStartBracket == tok
        assert scanner.TokDate == scanner.scan()
        dt = scanner.date_token()
        assert scanner.TokEndBracket == scanner.scan()

        cls._consume_whitespace(scanner, tok)
        scanner.logger.debug('date %s', dt)
        return int(calendar.timegm(dt.timetuple()) * 1000 + int(dt.microsecond) / 1000)

    @classmethod
    def _consume_identifier(cls, scanner, tok):

        assert scanner.TokStartBracket == tok
        assert scanner.TokId == scanner.scan()
        ident = scanner.token()
        assert scanner.TokEndBracket == scanner.scan()

        scanner.logger.debug('ident %s', ident)
        parts = ident.split('.')
        level = parts.pop()
        if len(parts) > 2 and parts[0] == u"agent" and parts[1] == u"oplog":
            i = parts.pop()
        else:
            i = None
        return ".".join(parts), i, level,

    @classmethod
    def _consume_src_file(cls, scanner, tok):

        assert scanner.TokStartBracket == tok
        assert scanner.TokSrcFile == scanner.scan()
        src = scanner.token()
        assert scanner.TokEndBracket == scanner.scan()

        return src

    # the key is the current token
    @classmethod
    def _consume_key_value(cls, scanner, tok):
        assert tok == scanner.TokAttribute
        key = scanner.string_token()
        scanner.logger.info("key '%s'", key)

        tok = scanner.scan()
        assert tok == scanner.TokAttributeSeparator

        tok = scanner.scan()
        v = cls._consume_value(scanner, tok)
        t = is_int(v)
        if t is not None:
            v = t
        scanner.logger.info("js['%s']=%s", key, v)
        return key, v

    @classmethod
    def _consume_value(cls, scanner, tok):
        cls._consume_whitespace(scanner, tok)
        value = scanner.string_token()
        scanner.logger.info("scan_value value=%s", value)
        return value

    @classmethod
    def _consume_js_slice(cls, scanner, tok):
        tok = cls._consume_whitespace(scanner, tok)
        finished = (tok == scanner.TokFinishedPushingSlices)

        js = BSON([(u'finished', finished), (u'message', scanner.token())])
        assert scanner.TokJsSlice == scanner.scan()
        js[u'start'] = scanner.oplog_token()

        assert scanner.TokJsSliceTo == scanner.scan()
        assert scanner.TokJsSlice == scanner.scan()
        js[u'end'] = scanner.oplog_token()

        return js

    def iscan(self, flat=True, singular=True):
        scanner = self.scanner

        tok = scanner.scan()
        while tok != scanner.TokEOF:
            js = BSON()
            while tok == scanner.TokEOL:
                tok = scanner.scan()
            if scanner.TokEOF == tok:
                break
            p = scanner.pos()
            js[u'timestamp'] = self._consume_timestamp(scanner, tok)
            js[u'logger'], js[u'id'] , js[u'level'] = self._consume_identifier(scanner, scanner.scan())
            js[u'thread'] = self._consume_src_file(scanner, scanner.scan())

            tok = scanner.scan()
            line = scanner.line()
            js[u'line'] = line
            if tok in [scanner.TokFinishedPushingSlices, scanner.TokPushingSlices]:

                js[u'slice'] = self._consume_js_slice(scanner, tok)

                tok = scanner.scan()
                while tok == scanner.TokAttribute:
                    key, value = self._consume_key_value(scanner, tok)
                    # grab the line in case we are finished
                    js[u'line'] = scanner.line()
                    if key is not None:
                        key = "".join(key.split())
                        js[u'slice'][key] = value
                    else:
                        break
                    tok = scanner.scan()
                    if tok in [scanner.TokAttributeTerminator, scanner.TokEOL]:
                        break

                if tok != scanner.TokEOL:
                    tok = self._consume_to(scanner, scanner.scan(), scanner.TokDuration)
                    value = scanner.token()
                    if value.endswith('ms'):
                        js[u'duration'] = int(value[:-2])
                    js[u'line'] = scanner.line()
            elif tok != scanner.TokEOL:
                tok = self._consume_to_eol(scanner, tok)
                js[u'line'] = scanner.line()

            tok = self._consume_to_eol(scanner, tok)
            js[u'pos'] = {'filename': p.Filename, 'line': p.Line, 'offset': p.Offset, 'column': p.Column}
            v = js
            self.logger.info(json.dumps(v, indent=3, default=JsonTranslater.translate))

            v = flatten(js, BSON(), singular=singular) if flat else js
            yield v
            if scanner.TokEOF == tok:
                break
            assert scanner.TokEOL == tok  # scanner.scan()
        self.logger.info('done')

    @property
    def metrics(self):
        return self.scan()

    def scan(self, flat=True):
        if self._stats is None:
            current = BackupAgentMetric()
            for ss in self.iscan(flat=flat, singular=True):
                current.add_metrics(ss)
            self._stats = current
        return self._stats

Archive.add(BackupAgentArchive)
