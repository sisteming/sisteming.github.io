"""
Provides functions to read FTDC data from either an FTDC file or from
a file containing serverStatus JSON documents, one per line. Each
reader takes a filename argument and returns a generator that yields a
sequence of chunks. Each chunk is a map from tuples keys to lists, where
the tuple key represents a path through a JSON document from root to leaf,
and the list is a list of values for that path.
"""

from collections import OrderedDict
import json
import dateutil.parser
from mseries.scanner.scanner import Scanner, seq, Redo, Token


class BackupAgentScanner(Scanner):
    # maybe TokAssign or sep would be better as it could also be a =
    TokStartBracket = Token(next(seq), name='StartBracket')
    TokEndBracket = Token(next(seq), name='EndBracket')
    TokDate = Token(next(seq), name='Date')
    TokTime = Token(next(seq), name='Time')
    TokId = Token(next(seq), name='Id')
    TokSrcFile = Token(next(seq), name='SrcFile')
    TokPayload = Token(next(seq), name='Payload')
    TokJsSlice = Token(next(seq), name='JsSlice')
    TokJsSliceTo = Token(next(seq), name='JsSliceTo')
    TokCompressed = Token(next(seq), name='Compressed')
    TokSlices = Token(next(seq), name='Slices')
    TokPushingSlices = Token(next(seq), name='PushingSlices')
    TokFinishedPushingSlices = Token(next(seq), name='FinishedPushingSlices')
    TokDuration = Token(next(seq), name='Duration')
    TokAttributeTerminator = Token(next(seq), name='AttributeTerminator')

    ScanStartBracket = 1 << TokStartBracket
    ScanEndBracket = 1 << TokEndBracket
    ScanDate = 1 << TokDate
    ScanTime = 1 << TokTime
    ScanId = 1 << TokId
    ScanSrcFile = 1 << TokSrcFile
    ScanPayload = 1 << TokPayload
    ScanJsSlice = 1 << TokJsSlice
    ScanJsSliceTo = 1 << TokJsSliceTo
    ScanCompressed = 1 << TokCompressed
    ScanSlices = 1 << TokSlices
    ScanPushingSlices = 1 << TokPushingSlices
    ScanFinishedPushingSlices = 1 << TokFinishedPushingSlices
    ScanDuration = 1 << TokDuration
    ScanAttributeTerminator = 1 << TokAttributeTerminator

    ModeStrings = {
        ScanStartBracket: "start [",
        ScanEndBracket: "end ]",
        ScanDate: "Date",
        ScanTime: "time",
        ScanId: "id",
        ScanSrcFile: "src file",
        ScanPayload: "Payload",
        ScanJsSlice: "Slice",
        ScanJsSliceTo: "Slice To",
        ScanCompressed: "Compressed slices",
        ScanPushingSlices: "Pushing Slices",
        ScanFinishedPushingSlices: "Finished Pushing Slices",
        ScanDuration: "Duration",
        ScanAttributeTerminator: "Attribute Terminator",

    }
    ModeStrings.update(Scanner.ModeStrings)

    GoTokens = Scanner.GoTokens | Scanner.ScanStart
    ScanStarting = Scanner.ScanStarting

    def __init__(self, filename, encoding='utf-8', sz=16381):
        Scanner.__init__(self, filename, encoding=encoding, sz=sz, name=__name__)

    def to_json(self):
        doc = OrderedDict([
            ('srcBuf', len(self._src_buf)),
            ('srcPos', self.src_pos),
            ('srcEnd', self._src_end),
            ('tokPos', self.tok_pos),
            ('tokEnd', self.tok_end),
            ('srcBufOffset', self._src_buf_offset),
            ('mode', self.mode_to_string(self.mode)),
            ('line', self._current_line),
            ('lineBuf', self._line_buf),
        ])
        return json.dumps(doc, indent=3)

    def is_valid(self):
        tok = self.scan(limit=2048)
        return tok == self.TokStartBracket

    def scan(self, limit=None, error=None, flat=False):
        terror, self.error = error, self.error
        ch = self.peek()
        redo = 0
        l = self._limit
        try:
            self._limit = limit

            while True:
                try:
                    self.tok_pos = -1
                    self._current_line = 0
                    if ch == u'\n':
                        self._line_buf = u''

                        # start collecting token text
                        ch = self.next()
                        if ch == self.EOF:
                            return self.TokEOF

                        self._current_line = self._line
                        self.mode = self.ScanStarting
                        return self.TokEOL

                    if self._column > 1:
                        ch = self.skip_whitespace(ch, m=self.NoGoWhitespace)

                    # start collecting token text
                    self.tok_buf = u''
                    self.tok_pos = self.src_pos - self._last_char_len

                    # set token position
                    # (this is a slightly optimized version of the code in Pos())
                    self.offset = self._src_buf_offset + self.tok_pos
                    if self._column > 0:
                        # common case: last character was not a '\n'
                        self._current_line = self._line
                        self.column = self._column
                    else:
                        # last character was a '\n'
                        # (we cannot be at the beginning of the source
                        # since we have called next() at least once)
                        self._current_line = self._line - 1
                        self.column = self._last_line_len

                    # determine token value
                    tok = ch
                    if ch == u'[':
                        if self.mode & self.ScanStarting != 0:
                            ch = self.next()
                            self.mode = self.ScanDate
                            tok = self.TokStartBracket
                        elif self.mode & self.ScanId != 0:
                            ch = self.next()
                            self.mode = self.ScanId
                            tok = self.TokStartBracket
                        elif self.mode & self.ScanSrcFile != 0:
                            ch = self.next()
                            self.mode = self.ScanSrcFile
                            tok = self.TokStartBracket
                        else:
                            ch = self.next()
                    elif ch == u']':
                        if self.mode & self.ScanDate != 0:
                            ch = self.next()
                            self.mode = self.ScanStartBracket | self.ScanId
                            tok = self.TokEndBracket
                        elif self.mode & self.ScanId != 0:
                            ch = self.next()
                            self.mode = self.ScanStartBracket | self.ScanSrcFile
                            tok = self.TokEndBracket
                        elif self.mode & self.ScanSrcFile != 0:
                            ch = self.next()
                            self.mode = self.ScanPayload
                            tok = self.TokEndBracket
                        else:
                            ch = self.next()
                    elif self.is_decimal(ch):
                        if self.mode & self.ScanDate != 0:
                            tok, ch = self.scan_date_time(ch)
                            self.mode = self.ScanStartBracket | self.ScanDate
                        elif self.mode & self.ScanPayload != 0:
                            tok, ch = self.scan_payload(ch)
                            # self.mode = self.ScanStarting
                        elif self.mode & self.ScanValue != 0:
                            tok, ch = self.scan_value(ch)
                        elif self.mode & self.ScanDuration != 0:
                            tok, ch = self.scan_value(ch)
                            tok = self.TokDuration
                        elif self.mode & (self.ScanAttribute | self.ScanJsSlice) != 0:
                            ch = self.next()
                            tok = self.TokAttributeTerminator
                            self.mode = self.ScanAttribute | self.ScanJsSlice | self.ScanDuration
                        else:
                            ch = self.next()
                    elif self.is_ident(ch, 0):
                        if self.mode & self.ScanId != 0:
                            tok, ch = self.scan_id(ch)
                            self.mode = self.ScanStartBracket | self.ScanId
                        elif self.mode & self.ScanSrcFile != 0:
                            tok, ch = self.scan_src_file(ch)
                            self.mode = self.ScanSrcFile
                        elif self.mode & self.ScanPayload != 0:
                            tok, ch = self.scan_payload(ch)
                        elif self.mode & self.ScanJsSlice != 0:
                            if ch == u'-':
                                ch = self.next()
                                if ch == u'>':
                                    ch = self.next()
                                    tok = self.TokJsSliceTo
                                self.mode = self.ScanJsSlice
                            else:
                                tok, ch = self.scan_payload_attr(ch)
                        elif self.mode & self.ScanEOL != 0:
                            tok, ch = self.scan_to_EOL(ch)
                            self.mode = self.ScanStarting
                        else:
                            ch = self.next()
                    elif ch == u'-':
                        if self.mode & self.ScanJsSliceTo != 0:
                            ch = self.next()
                            if ch == u'>':
                                ch = self.next()
                                tok = self.TokJsSliceTo
                            self.mode = self.ScanJsSlice
                        else:
                            ch = self.next()
                    elif ch == u'{':
                        if self.mode & self.ScanJsSlice != 0:
                            tok, ch = self.scan_payload_attr(ch)
                        else:
                            ch = self.next()
                    elif ch == u':':
                        if self.mode & self.ScanJsSlice != 0:
                            ch = self.next()
                            tok = self.TokAttributeSeparator
                            self.mode = self.ScanValue
                        else:
                            ch = self.next()
                    else:
                        if ch == self.EOF:
                            tok = self.TokEOF
                        elif ch == u'\n':
                            tok = self.TokEOL
                        else:
                            ch = self.next()

                    self.tok_end = self.src_pos - self._last_char_len
                    if tok == self.TokEOL:
                        self.mode = self.ScanStarting

                    self.ch = ch
                    # self.logger.info("current token %s, next char='%s'", self.token_to_string(tok), self.tr(self.ch))
                    self.logger.info("mode %s ", self.mode_to_string(self.mode))
                    return tok

                except Redo as e:
                    if redo > 10:
                        raise e
                    self.logger.debug("Redo start", exc_info=1)
                    self._line -= 1
                    redo += 1
                    if self.tok_pos > 0:
                        d = self.src_pos - self.tok_end
                        self.src_pos = self.tok_end
                        self._column -= d
                        ch = self.next()
        finally:
            self._limit = l
            self.error = terror

    def date_token(self):
        dt = self.token()
        return dateutil.parser.parse(dt)

    def scan_id(self, ch):
        self.logger.debug("scan_id %s", ch)
        while ch != u']':
            ch = self.next()

        return self.TokId, ch

    def scan_payload(self, ch):
        self.logger.debug("scan_payload %s", ch)
        # remove warning but check later
        tok = self.TokIgnore
        if self.is_ident(ch, 0):
            ch = self._scan_identifier()
            value = self._text().rstrip(u" :=(;.")
            if value in [u'Finished', u'Pushing']:
                # ch = self._scan_to_matching(ch, u'.')
                ch = self._scan_to(ch, u'.')
                assert ch == u'.'
                # TODO use terminator
                ch = self.next()
                self.mode = self.ScanJsSlice
                if value == u'Finished':
                    tok = self.TokFinishedPushingSlices
                elif value == u'Pushing':
                    tok = self.TokPushingSlices
                else:
                    self.scan_to_EOL(ch)
                    tok = self.TokValue
                    tok = self.TokEOL
                    self.mode = self.ScanStarting
            else:
                self.scan_to_EOL(ch)
                tok = self.TokEOL
                self.mode = self.ScanStarting
        elif self.is_decimal(ch):
            while ch.isdigit():
                ch = self.next()

            p = self.peek(offs=1)
            if p == u'd':
                tok = self.TokCompressed
                self.mode = self.ScanEOL # self.ScanCompressed
            elif p == u's':
                tok = self.TokSlices
                self.mode = self.ScanEOL
            else:
                self.scan_to_EOL(ch)
                tok = self.TokEOL
                self.mode = self.ScanStarting
        else:
            self.scan_to_EOL(ch)
            tok = self.TokEOL
            self.mode = self.ScanStarting

        return tok, ch

    def scan_payload_attr(self, ch):
        self.logger.debug("scan_payload %s", ch)
        # {ts: 1436865674:1 h: 0} -> {ts: 1436865734:5 h: 0} Num slices: 1 Num docs: 111. Request Time 38ms
        tok = self.TokJsSlice
        if ch == u'{':
            ch = self._scan_to(ch, u'}')
            # should be ' '
            self.logger.debug("scan_payload %s", ch)
            ch = self.next()
            self.mode = self.ScanJsSlice
        elif self.is_ident(ch, 0):
            ch = self._scan_identifier()
            value = self._text().rstrip(u" ")
            if value == u'Num':
                ch = self._scan_to(ch, u':')
                tok = self.TokAttribute
            elif value == u'Request':
                ch = self.next()
                self.logger.debug("scan_payload skip %s", ch)
                ch = self._scan_identifier()
                self.mode = self.ScanDuration
                tok = self.TokAttribute
            else:
                self.scan_to_EOL(ch)
                self.mode = self.ScanStarting
        else:
            self.scan_to_EOL(ch)
            self.mode = self.ScanStarting
        return tok, ch

    def scan_value(self, ch):
        self.logger.debug("scan_value %s", ch)
        # {ts: 1436865674:1 h: 0} -> {ts: 1436865734:5 h: 0} Num slices: 1 Num docs: 111. Request Time 38ms
        ch = self._scan_identifier()
        tok = self.TokValue
        self.mode = self.ScanAttribute | self.ScanJsSlice
        return tok, ch

    def scan_src_file(self, ch):
        self.logger.debug("scan_src %s", ch)
        while ch != u']':
            ch = self.next()

        return self.TokSrcFile, ch

    def scan_date_time(self, ch):
        self.logger.debug("scan_date_time %s", ch)
        ch = self.scan_digits(ch, 4)
        assert ch == u'/'

        ch = self.scan_digits(self.next(), 2)
        assert ch == u'/'

        ch = self.scan_digits(self.next(), 2)
        assert ch == u' '

        ch = self.scan_digits(self.next(), 2)
        assert ch == u':'

        ch = self.scan_digits(self.next(), 2)
        assert ch == u':'

        ch = self.scan_digits(self.next(), 2)
        assert ch == u']'

        return self.TokDate, ch
