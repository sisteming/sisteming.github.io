"""
Provides functions to read FTDC data from either an FTDC file or from
a file containing serverStatus JSON documents, one per line. Each
reader takes a filename argument and returns a generator that yields a
sequence of chunks. Each chunk is a map from tuples keys to lists, where
the tuple key represents a path through a JSON document from root to leaf,
and the list is a list of values for that path.
"""
from mseries.archive import AllMatcher
from mseries.mongo_stat.mongo_stat_scanner import MongoStatScanner
from mseries.tools.utils import to_millis
from mseries.archive import Archive
from mseries.types import BSON
from datetime import datetime
import humanfriendly
import os
from collections import OrderedDict
from itertools import izip
import itertools
from mseries.tools.utils import configuration


class MongoStatMetric:
    def __init__(self, date=datetime.utcnow()):
        self._current = None
        self._start = None
        self._values = None
        self._attributes = None
        self._connected_to = None
        self._start_timestamp = None
        self._measurements = None
        self._date = date

    # @property
    # def date(self, date):
    #     self._date = date.copy()

    def static_tags(self, args, point, **kwargs):
        return OrderedDict(filter(lambda kv: kv[1] is not None, kwargs.items()))

    def dynamic_tags(self, point, **kwargs):
        return None

    def measurements(self):
        if self._measurements  is None:
            self._measurements = [AllMatcher(u'mongostats')]
        return self._measurements

    def valid(self):
        return self._current or self._attributes is not None

    def idecode(self, first_only=False, ftdc=False, measurements=None, pipeline=None):
        proto = BSON(self._attributes[0])
        # for a in self._attributes:
        #     yield a

        if measurements:
            points = BSON()
            for m in measurements:
                p = points.get(m.name, [])
                points[m.name] = p
                for k in proto.keys():
                    if m.match_kv(k):
                        points[m.name].append(k)
            for m in measurements:
                keys = points[m.name]
                values = [self.metrics[k] for k in keys]
                names = ['_'.join(v) for v in keys]
                for values in izip(*values):
                    values = zip(names, values)
                    values = pipeline(m.name, values)
                    yield m, values
        else:
            yield None, self.metrics

        # for a in self._attributes:
        #     yield a

    def category(self):
        return 1

    def identifier(self):
        if self._start is not None:
            return self._start
        else:
            return self._attributes[0][-1][-1]

    @property
    def attributes(self):
        if self._attributes is None:
            self._attributes = []
        return self._attributes

    @property
    def timestamp(self):
        return self._start_timestamp

    @property
    def nmetrics(self):
        if self._attributes is None:
            return 0
        return len(self._attributes[0])

    @property
    def nsamples(self):
        if self._attributes is None:
            return 0
        return len(self._attributes)

    def add_metrics(self, i):
        metric = []
        for k, v in i:
            self.set_metric(metric, k, v)
            if k == u'time':
                self._start_timestamp = datetime.strptime(v, '%H:%M:%S').replace(year=self._date.year, month=self._date.month, day=self._date.day)
        self.attributes.append(metric)
        return metric

    def set(self, name, value):
        if name == u'Current Time':
            self._current = self.parse_timestamp(value)
        elif name == u'Start Time':
            self._start = self.parse_timestamp(value)
        elif name == u'connected to':
            self._connected_to = value

    @classmethod
    def parse_timestamp(cls, v, fmt="%Y%m%dT%H%M%S"):
        return datetime.strptime(v, fmt)

    @classmethod
    def set_metric(cls, attributes, name, value):
        if name in [u'insert', u'query', u'update', u'delete', u'getmore']:
            replicated = value[0] == u'*'
            if replicated:
                name += u'_repl'
                value = value[1:]
            attributes.append((name, int(value),))
        elif name == u'command %' or name == u'command %':
            local, replicated = value.split('|')
            attributes.append((u'command', int(local),))
            attributes.append((u'command_repl', int(replicated),))
        elif u'|' in name:
            first, last = name.split('|')
            readers, writers = value.split('|')
            attributes.append((first, int(readers),))
            attributes.append((last, int(writers),))
        elif name == u'used' or name[-1] == u'%':
            name = name.rstrip(u' %')
            attributes.append((name, float(value)))
        elif name in [u'flushes']:
            attributes.append((name, int(value)))
        elif name in [u'vsize', u'res', u'netIn', u'netOut']:
            try:
                attributes.append((name, humanfriendly.parse_size(value, binary=True)))
            except humanfriendly.InvalidSize:
                attributes.append((name, value))
        elif name in [u'set', u'repl', u'conn']:
            attributes.append((name, value))
        else:
            attributes.append((name, value))


class MongoStatArchiveMemo(object):
    def __init__(self, archive):
        self._filename = archive.filename
        self._configuration = archive.configuration._asdict()

    def from_memo(self):
        archive = MongoStatArchive(self._filename)
        archive.configuration = configuration(self._configuration)
        return archive

    @property
    def identifer(self):
        return self._filename

    @property
    def filename(self):
        return self._filename

    @property
    def category(self):
        return 1


class MongoStatArchive(Archive):

    CT_HEADER = 'Current Time : '
    ST_HEADER = 'Start Time : '
    INSERT = 'insert '

    def __init__(self, fn):
        Archive.__init__(self, name=__name__)
        self._filename = fn
        self._scanner = None
        self._valid = None
        self._category = 1
        self._start_timestamp = None
        self._end_timestamp = None

    @property
    def memo(self):
        return MongoStatArchiveMemo(self)

    def from_memo(self):
        return self

    def __enter__(self):
        return self

    def __exit__(self, tt, value, traceback):
        self.scanner.close()
        self._scanner = None

    def _type(self, tt, value, traceback):
        self.logger.debug("_type %s %s %s", tt, value, traceback)
        self.scanner.close()
        self._scanner = None

    def is_valid(self):
        if self._valid is None:
            err = None
            pos = None

            def on_error(e, p):
                global err
                global pos
                err = e
                pos = p
            try:
                with self as archive:
                    scanner = archive.scanner
                    tok = scanner.scan(limit=1024, error=on_error)
                    archive._valid = (tok == scanner.TokAttribute)
            except:
                self.logger.warn("valid", exc_info=1)
                self._valid = False
        return self._valid

    @property
    def scanner(self):
        if self._scanner is None:
            self._scanner = MongoStatScanner(self._filename)
        return self._scanner

    def from_memo(self):
        return self

    @property
    def identifier(self):
        if self.metrics and self.metrics.timestamp:
            return self.metrics.timestamp
        return self.filename

    def to_progress(self, l):
        # try:
        #     if self.metrics:
        #         return self.metrics.timestamp[0:l-1]
        # except:
        #     pass
        fn = self.filename
        if len(self.filename) < l:
            fn = os.path.basename(fn)
        return fn[0:l-1]

    @property
    def filename(self):
        return self._filename

    @property
    def category(self):
        return self._category

    @property
    def description(self):
        return "Mongostat data; {} bytes".format(os.stat(self.filename).st_size)

    @property
    def timestamp(self):
        return self.start_timestamp

    @property
    def start_timestamp(self):
        return self._start_timestamp

    def close(self):
        if self._scanner is not None:
            self._scanner .close()
            self._scanner = None

    def add(self, metric):
        self.metrics.append(metric)

    @classmethod
    def transform(cls, names, values):
        for name, value in itertools.izip(names, values):
            if name in [u'insert', u'query', u'update', u'delete', u'getmore']:
                replicated = value[0] == u'*'
                if replicated:
                    name += u'_repl'
                    value = value[1:]
                yield (name, int(value))
            elif name == u'command %' or name == u'command %' or name == u'command':
                local, replicated = value.split('|')
                yield (u'command', int(local))
                yield (u'command_repl', int(replicated))
            elif u'|' in name:
                first, last = name.split('|')
                readers, writers = value.split('|')
                yield (first, int(readers))
                yield (last, int(writers))
            elif name == u'used' or name[-1] == u'%':
                name = name.rstrip(u' %')
                yield (name, float(value))
            elif name in [u'flushes']:
                yield (name, int(value))
            elif name in [u'vsize', u'res', u'netIn', u'netOut', u'mapped']:
                try:
                    yield (name, humanfriendly.parse_size(value, binary=True))
                except humanfriendly.InvalidSize:
                    yield (name, value)
            elif name in [u'set', u'repl', u'conn']:
                yield (name, value)
            else:
                yield (name, value)

    def iscan(self):
        headings = []
        tok = None

        while tok != self.scanner.TokEOF:
            tok = self.scanner.scan()
            if tok == self.scanner.TokAttribute:
                self.logger.debug('Attribute Token')
                name = self.scanner.token()
                assert self.scanner.TokAttributeSeparator == self.scanner.scan()
                assert self.scanner.TokValue == self.scanner.scan()
                value = self.scanner.token()
                # current.set(name, value)
            elif tok == self.scanner.TokHeading:
                del headings[:]
                while tok == self.scanner.TokHeading:
                    self.logger.debug('Heading Token')
                    value = self.scanner.token()
                    if value == u'locked':
                        start = value
                        assert self.scanner.TokHeading == self.scanner.scan()
                        value = self.scanner.token()

                        if value == u'db':
                            value = start + value
                        else:
                            headings.append(value)

                    if value == u'idx':
                        start = value
                        assert self.scanner.TokHeading == self.scanner.scan()
                        value = self.scanner.token()

                        if value == u'miss %':
                            value = start + value
                        else:
                            headings.append(value)

                    headings.append(value)
                    if value == u'conn':
                        pass
                    tok = self.scanner.scan()

                assert tok == self.scanner.TokEOL
                tok = self.scanner.scan()
                metrics = []
                while tok == self.scanner.TokMetrics:
                    self.logger.debug('Metrics Token')
                    value = self.scanner.token()
                    metrics.append(value)
                    tok = self.scanner.scan()

                assert len(headings) > 0
                assert len(headings) == len(metrics)

                yield list(self.transform(headings, metrics))

            elif tok == self.scanner.TokMetrics:
                metrics = []
                while tok == self.scanner.TokMetrics:
                    self.logger.debug('Metrics Token')
                    value = self.scanner.token()
                    if value[0] == '*':
                        value = value[1:]

                    metrics.append(value)
                    tok = self.scanner.scan()

                assert len(headings) > 0
                assert len(headings) == len(metrics)
                yield list(self.transform(headings, metrics))

            elif tok == self.scanner.TokEOF:
                self.logger.debug('EOF')
            else:
                self.logger.debug('ignoring token')

    @property
    def metrics(self):
        return self#.scan()
        # return self.scan()

    @property
    def nmetrics(self):
        return 0

    @property
    def nsamples(self):
        return 0

    # def scan(self):
    #     if self._stats is None:
    #         current = MongoStatMetric()
    #         for m in self.iscan():
    #             current.add_metrics(m)
    #         self._stats = current
    #     return self._stats

    def to_datetime(self, ts, date):
        return datetime.strptime(ts, '%H:%M:%S').replace(year=date.year, \
                                                         month=date.month, \
                                                         day=date.day)

    def idecode(self, first_only=False, ftdc=False, measurements=None, pipeline=None, memo={}):
        for values in self.iscan():
            values = OrderedDict(values)
            values = pipeline(measurements[0].name, values, memo)
            values.timestamp = to_millis(values.timestamp)
            values.tags = self.dynamic_tags(values)

            yield measurements[0], values

    # noinspection PyMethodMayBeStatic
    def measurements(self):
        return MongoStatMetric().measurements()

    def static_tags(self, *args, **kwargs):
        return MongoStatMetric().static_tags(*args, **kwargs)

    def dynamic_tags(self, *args, **kwargs):
        return MongoStatMetric().dynamic_tags(*args, **kwargs)

    @classmethod
    def to_timestamp(cls, point, fmt="%Y-%m-%dT%H:%M:%S"):
        t = point[-1][-1]
        return t
        # return "{}.{:03}Z".format(time.strftime(fmt, time.gmtime(t / 1000)), t % 1000)

Archive.add(MongoStatArchive)
