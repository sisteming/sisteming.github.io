"""
Provides functions to read FTDC data from either an FTDC file or from
a file containing serverStatus JSON documents, one per line. Each
reader takes a filename argument and returns a generator that yields a
sequence of chunks. Each chunk is a map from tuples keys to lists, where
the tuple key represents a path through a JSON document from root to leaf,
and the list is a list of values for that path.
"""

from collections import OrderedDict
import json
import time
from mseries.scanner.scanner import Scanner, seq, Redo


class MongoStatScanner(Scanner):
    # maybe TokAssign or sep would be better as it could also be a =
    TokHeading = next(seq)
    TokMetrics = next(seq)

    ScanHeading = 1 << TokHeading
    ScanMetrics = 1 << TokMetrics

    ModeStrings = {ScanHeading: "ScanHeading",
                  ScanMetrics: "ScanMetrics"}
    ModeStrings.update(Scanner.ModeStrings)

    GoTokens = Scanner.GoTokens | ScanHeading | ScanMetrics
    ScanStarting = Scanner.ScanStarting | ScanHeading | ScanMetrics

    def __init__(self, filename, encoding='utf-8', sz=16381):
        Scanner.__init__(self, filename, encoding=encoding, sz=sz, name=__name__)

    def to_json(self):
        doc = OrderedDict([
            # ('srcBuf', self.srcBuf.replace("\n", " ")),
            # ('mmmPos', "{}".format("^" * self.srcPos)),
            ('srcBuf', len(self._src_buf)),
            ('srcPos', self.src_pos),
            ('srcEnd', self._src_end),
            ('tokPos', self.tok_pos),
            ('tokEnd', self.tok_end),
            ('srcBufOffset', self._src_buf_offset),
            ('mode', self.mode_to_string(self.mode)),
            ('line', self.line),
            ('lineBuf', self.line_buf),
        ])
        return json.dumps(doc, indent=3)

    def is_valid(self):
        tok = self.scan()
        return tok == Scanner.TokAttribute

    def scan(self, limit=None, error=None):
        terror, self.error = error, self.error
        ch = self.peek()
        redo = 0
        l = self._limit
        try:
            self._limit = limit

            while True:
                try:
                    self.tok_pos = -1
                    self.line = 0
                    if ch == u'\n':
                        self.line_buf = u''

                        # start collecting token text
                        ch = self.next()
                        if ch == self.EOF:
                            return self.TokEOF

                        self.line = self._line
                        self.mode = self.ScanStarting
                        return self.TokEOL

                    if self._column > 1:
                        ch = self.skip_whitespace(ch, m=self.NoGoWhitespace)

                    # start collecting token text
                    self.tok_buf = u''
                    self.tok_pos = self.src_pos - self._last_char_len

                    # set token position
                    # (this is a slightly optimized version of the code in Pos())
                    self.offset = self._src_buf_offset + self.tok_pos
                    if self._column > 0:
                        # common case: last character was not a '\n'
                        self.line = self._line
                        self.column = self._column
                    else:
                        # last character was a '\n'
                        # (we cannot be at the beginning of the source
                        # since we have called next() at least once)
                        self.line = self._line - 1
                        self.column = self._last_line_len

                    # determine token value
                    tok = ch
                    if self.is_ident(ch, 0):
                        # if (ch == u'C' or ch == u'S') and self.Mode & (self.ScanStart | self.ScanCurrent) != 0:
                        if self.mode == self.ScanHeading:
                            tok, ch = self.scan_heading(ch)
                        elif self.mode & (self.ScanAttribute| self.ScanHeading) != 0:
                            tok, ch = self.scan_attribute_or_heading(ch)
                        elif self.mode & self.ScanMetrics != 0:
                            tok, ch = self.scan_metrics(ch)
                        elif self.mode & self.ScanEOL != 0:
                            tok, ch = self.scan_to_EOL(ch)
                        else:
                            ch = self.next()
                    elif ch == u':' and self.mode & self.ScanAttributeSeparator != 0:
                        tok, ch = self.TokAttributeSeparator, self.next()
                        self.mode = self.ScanValue
                    elif self.is_decimal(ch) or ch == u'*':
                        if self.mode & self.ScanValue != 0 and ch != u'*':
                            tok, ch = self.scan_value(ch)
                        elif self.mode & self.ScanMetrics != 0:
                            tok, ch = self.scan_metrics(ch)
                        else:
                            ch = self.next()
                    elif ch == u' ':
                        if self.mode == self.ScanHeading:
                            # tok, ch = self.scan_heading(ch)
                            assert 'here'
                        if self.mode & self.ScanMetrics != 0:
                            ch = self.skip_whitespace(ch, m=self.NoGoWhitespace)
                            self.tok_pos = self.src_pos - self._last_char_len

                            if ch == u'\n':
                                tok = self.TokEOL
                                self.mode = self.ScanStarting
                            else:
                                tok, ch = self.scan_metrics(ch)

                        else:
                            ch = self.next()
                    else:
                        if ch == self.EOF:
                            tok = self.TokEOF
                        elif ch == u'\n':
                            tok = self.TokEOL
                        else:
                            ch = self.next()
                    # end of token text
                    self.tok_end = self.src_pos - self._last_char_len
                    if tok == self.TokEOL:
                        self.mode = self.ScanStarting

                    self.ch = ch
                    return tok

                except Redo as e:
                    if redo > 10:
                        raise e
                    self.logger.debug("Redo start", exc_info=1)
                    self._line -= 1
                    redo += 1
                    if self.tok_pos > 0:
                        d = self.src_pos - self.tok_end
                        self.src_pos = self.tok_end
                        self._column -= d
                        ch = self.next()
        finally:
            self._limit = l
            self.error = terror

    def scan_identifier(self, ch):
        # read character after '`'
        self.logger.debug("scan_times %s", ch)
        ch = self._scan_identifier()
        if ch == self.TokAttributeSeparator:
            self.mode = self.ScanAttributeSeparator
            return self.TokAttribute, ch
        else:
            self.mode = self.ScanEOL
            return self.TokIgnore, ch

    def scan_attribute(self, ch):
        if ch == u'S' or ch == u'C':
            return self.scan_attribute(ch)
        elif ch == u'c':
            return self.scan_attribute(ch)
        else:
            return self.scan_heading(ch)

    def scan_value(self, ch):
        self.mode = self.ScanAttribute | self.ScanHeading | self.ScanMetrics
        return self.TokValue, self._scan_value(ch)

    def scan_attribute_or_heading(self, ch):
        # TODO check this, probably only need to check if it is blank
        if ch != u'S' and ch != u'C' and ch != u'c':
            return self.scan_heading(ch)

        # read character after '`'
        ch = self._scan_identifier()
        if ch == u' ':
            ch = self._scan_identifier()
            identifier = self._text().rstrip(u" :=(;.")
            if identifier in [u"Start Time", u"Current Time", u"connected to"] and (ch == u' ' or ch == u':'):
                self.mode = self.ScanAttributeSeparator
                return self.TokAttribute, ch

        self.mode = self.ScanEOL | self.ScanStarting
        return self.TokIgnore, ch

    def scan_heading(self, ch):
        def is_header_ident_rune(c, i):
            return c == '_' or c == '|' or c == '-' or c.isalpha() or c.isdigit() and i > 0

        self.logger.debug("scan_heading %s", ch)

        ch = self._scan_identifier(m=is_header_ident_rune)
        identifier = self._text().rstrip(u" :=(;.\n")
        peek = self.peek(offs=1)
        self.mode = self.ScanHeading
        if identifier == u'time':
            pass
        if peek == u'%':
            # grab the % in the token
            self.next()
            ch = self.next()

        return self.TokHeading, ch

    def scan_metrics(self, ch):
        def is_metrics_ident_rune(c, i):
            return c == u'*' or c == u'%' or c == u':' or c == u'.' or c == u'|' or c == u'-' or c.isalpha() or c.isdigit() and i > 0

        self.logger.debug("scan_metrics %s", ch)

        ch = self._scan_identifier(m=is_metrics_ident_rune)
        self.mode = self.ScanMetrics
        if ch == u'\n':
            self.mode = self.ScanStarting
            return self.TokEOL, ch
        else:
            return self.TokMetrics, ch

    def timestamp(self):
        v = self.token()
        return time.strptime(v, '%Y%m%dT%H%M%S')
