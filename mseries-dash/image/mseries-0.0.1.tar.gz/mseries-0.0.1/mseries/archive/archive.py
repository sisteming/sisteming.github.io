"""
Base class functionality for Matcher.
Base class for Archive formats and discovery of the type.
"""

from mseries.utils import Logger
from collections import OrderedDict


class AbstractMatcher:
    def __init__(self, name):
        self._name = name

    @property
    def name(self):
        return self._name

    @property
    def point(self):
        return True

    def match_point(self, obj):
        return None

    def match_value(self):
        return None


class AllMatcher(AbstractMatcher):
    def __init__(self, name):
        AbstractMatcher.__init__(self, name)

    def match(self, point):
        return OrderedDict(point)

    def match_kv(self, *args, **kwargs):
        return True


class PointMatcher(AbstractMatcher):
    def __init__(self, name, value, key=u'type'):
        AbstractMatcher.__init__(self, name)
        self._key = key
        self._value = value

    def match(self, point):
        values = None
        if self._key in point and point[self._key] == self._value:
            values = point.copy()
            del values[self._key]
        return values


class ValueMatcher(AbstractMatcher):
    def __init__(self, name, key=None):
        AbstractMatcher.__init__(self, name)
        if key is None:
            self._key = name

    def attr(self, k):
        if isinstance(k, (list, tuple)):
            attr = "_".join(k)
        else:
            attr = k
        return attr

    def match(self, points):
        values = OrderedDict()
        if isinstance(points, (list, tuple)):
            i = points
        else:
            i = points.items()

        for k, v in i:
            attr = self.attr(k)
            if attr.startswith(self._key):
                values[attr] = v
        return values

    def match_kv(self, k, v):
        attr = self.attr(k)
        if attr.startswith(self._key):
            return True
        return None


class Archive(Logger):
    LOOKUP = [] # OrderedDict()

    METADATA_TYPE = 0
    """This is the metadata category """

    METRIC_CHUNK_TYPE = 1
    """This is the chunk category """

    METADATA_NAME = u'Metadata'
    """This is the metadata category name"""

    REFERENCE_SAMPLE_NAME = u'ReferenceSample'
    """This is the reference sample category name """

    SERVER_STATUS_NAME = u'serverStatus'
    """This is the server status category name """

    @property
    def configuration(self):
        return getattr(self, '_configuration')

    @configuration.setter
    def configuration(self, configuration):
        setattr(self, '_configuration', configuration)

    @classmethod
    def add(cls, reader):
        """add the reader instance by type and int type"""
        Archive.LOOKUP.append(reader)

    @classmethod
    def all(cls):
        return Archive.LOOKUP

    def __init__(self, name=__name__):
        Logger.__init__(self, name=name)

    def read(self):
        return [self]