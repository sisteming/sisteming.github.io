from mseries.writers import Writer


class NullWriter(Writer):
    """ Essentially write to /dev/null """

    def __init__(self, cfg=None):
        """ null writer ctor

        :Parameters:
          - `cfg`: the configuration
        """
        Writer.__init__(self, cfg, name=__name__)

    def write(self, *args, **kwargs):
        """ write nothing """
        self.logger.debug("write args=%r, kwargs=%r", args, kwargs)
        pass
