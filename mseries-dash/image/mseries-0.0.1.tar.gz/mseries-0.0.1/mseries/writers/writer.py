from mseries.utils import Logger
import os
import threading
from mseries.utils import NameEncoder
from mseries.utils import flatten, is_numeric
import time
import dateutil.parser


class Writer(Logger):
    """ base class for writer """

    def __init__(self, cfg=None,  name=__name__):
        """ writer ctor

        :Parameters:
          - `cfg`: the configuration
        """
        Logger.__init__(self, name=name)
        self._cfg = cfg
        self._uri = None
        self._project = None
        self._pipeline = None
        self._pb = None
        self._pb_context = {}
        self._hostname = None
        self.lock = threading.Lock()
        self._postprocessor = None
        self._ne = NameEncoder(self._cfg)

    def translate(self, measurement_name, values):
        """ translate the values dict

        :Parameters:
          - `measurement_name`: the name of the measurement
          - `values`: the point
        """
        return dict([(self._ne.key_to_name(k), int(v) if is_numeric(v) else v, ) for k, v in flatten(values, {}).items()])

    @property
    def config(self):
        """ the configuration """
        return self._cfg

    @property
    def uri(self):
        """ get the uri

        :Returns:

            # the uri from the configuration or the *MSERIES_URI* env var or
        defaults to *mongodb://localhost/mseries*
        """
        # come back to check this
        if self.config and self.config.uri:
            self._uri = self.config.uri or os.environ.get('MSERIES_URI')
        return self._uri or 'mongodb://localhost/mseries'

    # noinspection PyMethodMayBeStatic
    def to_timestamp(self, t, fmt="%Y-%m-%dT%H:%M:%S"):
        """ convert t to datetime

        :Parameters:
          - `t`: the time
          - `fmt`: the date format,, defaults to *%Y-%m-%dT%H:%M:%S*
        """
        try:
            date1 = "{}.{:03}Z".format(time.strftime(fmt, time.gmtime(t / 1000)), int(t % 1000))
            date = dateutil.parser.parse(date1)
            return date
        except (ValueError, TypeError):
            return t

    def write(self, *args, **kwargs):
        """ write points """
        raise NotImplementedError("Please Implement this method")