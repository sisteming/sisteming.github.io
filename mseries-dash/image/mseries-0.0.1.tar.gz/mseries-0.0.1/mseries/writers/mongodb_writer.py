from mseries.utils import NameEncoder
from mseries.writers import Writer, urlparse
from pymongo import MongoClient
from pymongo.errors import ConnectionFailure, OperationFailure, InvalidDocument


class MongodbWriter(Writer):
    """ A mongodb writer instance """

    def __init__(self, opts=None):
        """ mongodb writer ctor

        :Parameters:
          - `cfg`: the configuration
        """
        Writer.__init__(self, opts, name=__name__)
        self._client = None
        self._db = None
        self._collection = None
        self._name_encoder = NameEncoder(opts)

    @property
    def client(self):
        """ get the client instance """
        if self._client is None:
            self._client = MongoClient(self.uri)
        return self._client

    @property
    def db(self):
        """ get the db from the uri or *mseries* """
        if self._db is None:
            uri = urlparse(self.uri)
            database = uri.path[1:]
            if not database:
                database = "mseries"

            self._db = self.client[database]
        return self._db

    @property
    def collection(self):
        """ get the collection from the configuration """
        if self._collection is None:
            self._collection = self.db[self.config.collection]
        return self._collection

    def retryable(self, exception):
        """Return True if we should retry (in this case when it's an IOError), False otherwise"""
        self.logger.warn("Unexpected exception at '%s'", self.uri, exc_info=exception)

        retryable = isinstance(exception, (ConnectionFailure, OperationFailure))
        if retryable:
            self.logger.info("Retrying...")
        return retryable

    def write(self, points, batch=50, tags=None):
        """ writer point to mongodb.
        TODO: Tags and batch not used, come back to this.

        :Parameters:
          - `points`: a list of points
          - `batch`: the influx batch size (defaults to 50)
          - `tags`: the tags to include
        """
        try:
            self.collection.insert_many(points, ordered=False)
        except InvalidDocument:
            pass
        self.logger.info("wrote %d points", len(points))

    # maybe pull other version into writer and call
    # when not serverInfo, so that they types are the
    # same (if that is meaningful)
    def translate(self, measurement_name, values):
        """ translate the points so that the attribute names are correct

        :Parameters:
          - `measurement_name`: the name of this set of points
          - `values`: a dict of points
        """
        if measurement_name not in [u'serverInfo', u'Metadata', u'ReferenceSample']:
            return [{'name': k, 'value': v} for k, v in values.items()]
        elif measurement_name == u'ReferenceSample':
            values = values.copy()
            if u'local.oplog.rs.stats' in values:
                values[self._ne.strip_key(u'local.oplog.rs.stats')] = values.pop(u'local.oplog.rs.stats')
            return values
        else:
            return values
