# noinspection PyPackageRequirements
from influxdb import InfluxDBClient
from retrying import retry

from mseries.utils.name_encoder import NameEncoder
from mseries.writers import Writer, urlparse
from requests.exceptions import RequestException
from influxdb.exceptions import InfluxDBClientError
from requests.exceptions import SSLError


class InfluxdbWriter(Writer):
    """ Influxdb writer class """

    def __init__(self, cfg=None):
        """ Influxdb writer ctor

        :Parameters:
          - `cfg`: the configuration
        """
        Writer.__init__(self, cfg, name=__name__)
        self._client = None
        self._db = None
        self._collection = None
        self._database = None
        self._tags = {}
        self._name_encoder = NameEncoder(cfg)

    @property
    def database(self):
        """  get the database name from the uri or *mseries* """
        if self._database is None:
            uri = urlparse(self.uri)
            database = uri.path[1:]
            if not database:
                database = "mseries"
            self._database = database

        return self._database

    @property
    def client(self):
        """ get the influxdb client instance  """
        if self._client is None:
            self._client = InfluxDBClient.from_DSN(self.uri)
        return self._client

    def retryable(self, exception):
        """Return True if we should retry (in this case when it's an IOError), False otherwise"""
        self.logger.warn("Unexpected exception at '%s'", self.uri, exc_info=exception)

        if isinstance(exception, KeyboardInterrupt):
            self.logger.info("retryable...KeyboardInterrupt")
            return False

        retryable = isinstance(exception, (RequestException, InfluxDBClientError, SSLError))  # , InfluxDBServerError))
        if retryable:
            self.logger.info("Retrying...")
        return retryable

    @retry(stop_max_attempt_number=5, wait_exponential_multiplier=1000, wait_exponential_max=120000,
           retry_on_exception=retryable)
    def write(self, points, batch=50, tags=None):
        """ writer point to influx. If the database does not exist, it will be created.

        :Parameters:
          - `points`: a list of points
          - `batch`: the influx batch size (defaults to 50)
          - `tags`: the tags to include
        """
        try:
            self.client.write_points(points, batch_size=batch, tags=tags)
        except InfluxDBClientError as e:
            if 'database not found' in e.content:
                self.client.create_database(self.database)
                self.client.write_points(points, batch_size=batch, tags=tags)
            else:
                self.logger.error("unexpected exception", exc_info=1)
                raise e
        except:
            self.logger.error("unexpected exception", exc_info=1)
            raise
