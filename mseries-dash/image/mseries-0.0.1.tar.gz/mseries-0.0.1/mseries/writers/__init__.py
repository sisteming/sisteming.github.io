import importlib
import os
try:
    from urllib.parse import urlparse, parse_qs
except ImportError:
    from urlparse import urlparse, parse_qs
from mseries.writers.writer import Writer


class WriterFactory(object):
    """ Writer factory class """

    @staticmethod
    def get_class(uri):
        """ get the class for the uri

        :Parameters:
          - `uri`: writer uri, generally will use the schema to try to create a class instance
        """
        m = __name__.split('.')
        scheme = uri.scheme.split('+')[-1]
        m.append("{}_writer".format(scheme))
        m = '.'.join(m)
        clazz = scheme.title() + "Writer"
        return getattr(importlib.import_module(m), clazz)

    @staticmethod
    def create(uri, cfg=None):
        """ create a writer instance for the uri

        :Parameters:
          - `uri`: writer uri, generally will use the schema to try to create a class instance
          - `cfg`: the configuration
        """
        if uri and (isinstance(uri, list) or isinstance(uri, tuple)):
            uri = uri[0]
        if not uri:
            uri = os.environ.get('MSERIES_URI')
        if not uri:
            uri = 'mongodb://localhost'
        u = urlparse(uri)
        clazz = WriterFactory.get_class(u)
        return clazz(cfg)

    @staticmethod
    def parse_uri(uri):
        """ parse the uri

        :Parameters:
          - `uri`: writer uri, generally will use the schema to try to create a class instance
        """
        return urlparse(uri)

    @staticmethod
    def parse_qs(uri):
        """ parse the uri query string

        :Parameters:
          - `uri`: writer uri, generally will use the schema to try to create a class instance
        """
        return parse_qs(uri)
