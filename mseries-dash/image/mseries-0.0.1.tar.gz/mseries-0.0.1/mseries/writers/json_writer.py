from mseries.writers import Writer
from collections import OrderedDict
import json


class JsonWriter(Writer):
    """ write json data to stdout. This has not been tested lately"""

    def __init__(self, cfg=None):
        """ json writer ctor

        :Parameters:
          - `cfg`: the configuration
        """
        Writer.__init__(self, cfg, name=__name__)

    @property
    def indent(self):
        """ get the indent level """
        if self.cfg.pretty:
            return 2
        else:
            return None

    def write(self, points, **kwargs):
        """ write the points. A big issue here would be related to the size of the output *AND*
        locking accessing the output stream.

        :Parameters:
          - `points`: the points to write
        """
        self.logger.info("{} points".format(len(points)))

        if points:
            for pos in range(0, len(points.itervalues().next())):
                data = OrderedDict()
                for key in points:
                    current = data
                    parts, attr = key[0:-1], key[-1]
                    for part in parts:
                        if part not in current:
                            current[part] = OrderedDict()
                        current = current[part]
                    current[attr] = points[key][pos]
                json_data = json.dumps(data, indent=self.indent)
                print(json_data)
            self.logger.info("Wrote {} points".format(len(points)))
        else:
            self.logger.info("empty points ".format(self.__class__))
