"""
Provides functions to read FTDC data from either an FTDC file or from
a file containing serverStatus JSON documents, one per line. Each
reader takes a filename argument and returns a generator that yields a
sequence of chunks. Each chunk is a map from tuples keys to lists, where
the tuple key represents a path through a JSON document from root to leaf,
and the list is a list of values for that path.
"""

from mseries.io_stat.io_stat_scanner import IoStatScanner
from datetime import datetime
from mseries.types import BSON
from mseries.archive import Archive, PointMatcher
from mseries.utils import to_timestamp
import humanfriendly
import os


# class Matcher:
#     def __init__(self, name, value, key=u'type'):
#         self._name = name
#         self._key = key
#         self._value = value
#
#     @property
#     def name(self):
#         return self._name
#
#     @property
#     def point(self):
#         return True
#
#     def match_point(self, obj):
#         if self._key in obj and obj[self._key] == self._value:
#             del obj[self._key]
#             return obj
#         else:
#             return None
#
#     def match_value(self):
#         return True
#
#
class IoStatMetric:
    def __init__(self):
        self._current = None
        self._start = None
        self._values = None
        self._attributes = None
        self._connected_to = None
        self._start_timestamp = None
        self._header = None
        self._measurements = None

    def valid(self):
        return self._current or self._attributes is not None

    def static_tags(self, args, **kwargs):
        _ = args
        _ = kwargs
        if self._header:
            tags = self._header.copy()
        else:
            tags = None
        # tags.update(kwargs)
        # return tags
        return tags

    def dynamic_tags(self, args, point, **kwargs):
        _ = args
        if u'device' in point:
            tags = {u'device': point.pop(u'device', None)}
            tags.update(kwargs)
        else:
            tags = None
        return tags

    def measurements(self):
        if self._measurements  is None:
            self._measurements = [PointMatcher(u'iostat_device', u'device', key=u'type'), PointMatcher(u'iostat_cpu', u'cpu', key=u'type')]
        return self._measurements

    def idecode(self, *args, **kwargs):
        for a in self._attributes:
            yield BSON(a)

    def category(self):
        return 1

    def identifier(self):
        return self._start_timestamp

    @property
    def attributes(self):
        if self._attributes is None:
            self._attributes = []
        return self._attributes

    @property
    def timestamp(self):
        return self._start_timestamp

    @property
    def nmetrics(self):
        if self._attributes is None:
            return 0
        return len(self._attributes[0])

    @property
    def nsamples(self):
        if self._attributes is None:
            return 0
        return len(self._attributes)

    def val_to_key(self, key):
        if isinstance(key, (list, tuple)):
            return  ".".join(key)
        return key

    def add_metrics(self, metrics):
        metric = []
        if self._header is None and u'OS' in metrics:
            self._header = metrics
            return

        for k, v in metrics.items() if isinstance(metrics, dict) else metrics:
            self.set_metric(metric, k, v)
            if self._start_timestamp is None and self.val_to_key(k) in [u'time', u'date']:
                self._start_timestamp = v
                if isinstance(self._start_timestamp, float):
                    self._start_timestamp = datetime.utcfromtimestamp(v / 1000.0)
        self.attributes.append(metric)
        return metric

    def set(self, name, value):
        if name == u'Current Time':
            self._current = self.parse_timestamp(value)
        elif name == u'Start Time':
            self._start = self.parse_timestamp(value)
        elif name == u'connected to':
            self._connected_to = value

    @classmethod
    def parse_timestamp(cls, v, fmt="%Y%m%dT%H%M%S"):
        return datetime.strptime(v, fmt)

    @classmethod
    def set_metric(cls, attributes, name, value):
        if name in [u'insert', u'query', u'update', u'delete', u'getmore']:
            replicated = value[0] == u'*'
            if replicated:
                name += u'_repl'
                value = value[1:]
            attributes.append((name, int(value),))
        elif name == u'command %' or name == u'command %':
            local, replicated = value.split('|')
            attributes.append((u'command', int(local),))
            attributes.append((u'command_repl', int(replicated),))
        elif u'|' in name:
            first, last = name.split('|')
            readers, writers = value.split('|')
            attributes.append((first, int(readers),))
            attributes.append((last, int(writers),))
        elif name == u'used' or name[-1] == u'%':
            name = name.rstrip(u' %')
            attributes.append((name, float(value)))
        elif name in [u'flushes']:
            attributes.append((name, int(value)))
        elif name in [u'vsize', u'res', u'netIn', u'netOut']:
            try:
                attributes.append((name, humanfriendly.parse_size(value, binary=True)))
            except humanfriendly.InvalidSize:
                attributes.append((name, value))
        elif name in [u'set', u'repl', u'conn']:
            attributes.append((name, value))
        else:
            attributes.append((name, value))


class IoStatArchiveMemo(object):
    def __init__(self, archive):
        self._filename = archive.filename

    def from_memo(self):
        return IoStatArchive(self._filename)

    @property
    def identifer(self):
        return self._filename

    @property
    def filename(self):
        return self._filename

    @property
    def category(self):
        return 1


class IoStatArchive(Archive):
    CT_HEADER = 'Current Time : '
    ST_HEADER = 'Start Time : '
    INSERT = 'insert '

    def __init__(self, fn):
        Archive.__init__(self, name=__name__)
        self._filename = fn
        self._scanner = None
        self._valid = None
        self._category = 1
        self._start_timestamp = None
        self._end_timestamp = None
        self._stats = None

    @property
    def memo(self):
        return IoStatArchiveMemo(self)

    def from_memo(self):
        return self

    def __enter__(self):
        return self

    def __exit__(self, tt, value, traceback):
        self.scanner.close()
        self._scanner = None

    def _type(self, tt, value, traceback):
        self.logger.debug("_type %s %s %s", tt, value, traceback)
        self.scanner.close()
        self._scanner = None

    def is_valid(self):
        if self._valid is None:
            err = None
            pos = None

            def on_error(e, p):
                global err
                global pos
                err = e
                pos = p

            try:
                with self as archive:
                    scanner = archive.scanner
                    tok = scanner.scan(limit=1024, error=on_error)
                    archive._valid = (tok == self.scanner.TokOs)
            except:
                self.logger.warn("valid", exc_info=1)
                self._valid = False
        return self._valid

    @property
    def scanner(self):
        if self._scanner is None:
            self._scanner = IoStatScanner(self._filename)
        return self._scanner

    def from_memo(self):
        return self

    @property
    def identifier(self):
        if self.metrics:
            return self.metrics.timestamp
        return 0

    def to_progress(self, l):
        if self.metrics:
            return to_timestamp(self.metrics.timestamp)[0:l - 1]
        fn = self.filename
        if len(self.filename) < l:
            fn = os.path.basename(fn)
        return fn[0:l - 1]

    @property
    def filename(self):
        return self._filename

    @property
    def category(self):
        return self._category

    @property
    def timestamp(self):
        return self.start_timestamp

    @property
    def start_timestamp(self):
        return self._start_timestamp

    def close(self):
        if self._scanner is not None:
            self._scanner.close()
            self._scanner = None

    def add(self, metric):
        self.metrics.append(metric)

    @classmethod
    def _consume_whitespace(cls, scanner, tok):
        return cls._consume_until(scanner, tok, scanner.TokEOL, scanner.TokEOF, scanner.TokIgnore)

    @classmethod
    def _consume_to_eol(cls, scanner, tok):
        tok = cls._consume_to(scanner, tok, scanner.TokEOL, scanner.TokEOF)
        t = scanner.token()
        scanner.logger.info(t)
        return tok

    @classmethod
    def _consume_to(cls, scanner, tok, *tokens):
        scanner.logger.info("_consume_to_tokens: current token %s", str(tok))
        while tok not in tokens and tok != scanner.TokEOF:
            tok = scanner.scan()
            scanner.logger.info("_consume_to_tokens: current token %s", scanner.line())
        scanner.logger.debug("_consume_to_tokens: current token %s", scanner.token_to_string(tok))
        return tok

    @classmethod
    def _consume_until(cls, scanner, tok, *tokens):
        while tok in tokens:
            tok = scanner.scan()
        scanner.logger.debug("_consume_until_tokens: current token %s", scanner.token_to_string(tok))
        return tok

    @classmethod
    def _consume_start_line(cls, scanner, tok):
        assert scanner.TokOs == tok
        o = scanner.token()

        tok = scanner.scan()
        assert scanner.TokKernelVersion == tok
        kv = scanner.token()

        tok = scanner.scan()
        assert scanner.TokHostname == tok
        host = scanner.token().strip(u'()')

        tok = scanner.scan()
        assert scanner.TokDate == tok
        d = scanner.date_token()

        tok = scanner.scan()
        assert scanner.TokArch == tok
        arch = scanner.token().strip(u'_')

        tok = scanner.scan()
        assert scanner.TokCores == tok
        cores = int(scanner.token().strip(u'()').split()[0])

        return [tok, d, o, kv, host, arch, cores]

    @classmethod
    def _consume_timestamp(cls, scanner, tok):
        assert scanner.TokTimestamp == tok
        d = scanner.date_token()

        return tok, d

    @classmethod
    def _consume_cpu_report(cls, scanner, tok):
        assert scanner.TokCpuReport == tok
        t = scanner.token()
        assert 'avg-cpu:' == t

        headers = []
        while tok != scanner.TokEOL:
            tok = scanner.scan()
            if tok != scanner.TokEOL:
                t = scanner.token().lstrip('%')
                headers.append(t)

        # tok = cls._skip_to_start(scanner, tok)
        values = []
        tok = scanner.scan()
        while tok != scanner.TokEOL:
            values.append(scanner.float_token())
            tok = scanner.scan()

        assert len(headers) == len(values)

        return tok, zip(headers, values)

    @classmethod
    def _consume_device_report_header(cls, scanner, tok):
        assert scanner.TokDeviceReport == tok
        t = scanner.token()
        assert 'Device:' == t

        headers = []
        while tok != scanner.TokEOL:
            tok = scanner.scan()
            if tok != scanner.TokEOL:
                t = scanner.token().lstrip('%')
                headers.append(t)
        return tok, headers

    @classmethod
    def _consume_device_report(cls, scanner, tok):

        values = []

        assert tok == scanner.TokDeviceReportValue
        device = scanner.token()

        tok = scanner.scan()
        while tok != scanner.TokEOL:
            values.append(scanner.float_token())
            tok = scanner.scan()

        assert tok == scanner.TokEOL
        return tok, device, values

    @classmethod
    def _skip_to_start(cls, scanner, tok):
        if scanner.peek() == u'\n':
            while tok == scanner.TokEOL:
                tok = scanner.scan()
            p = scanner.pos()
        else:
            p = scanner.pos()
            tok = scanner.scan()
        return p, tok

    def iscan(self, flat=True, singular=True):
        scanner = self.scanner

        tok = scanner.TokEOL
        js = BSON()
        p = scanner.pos()
        while tok != scanner.TokEOF:
            _, tok = self._skip_to_start(scanner, tok)
            if scanner.TokEOF == tok:
                break
            if tok == scanner.TokOs:
                values = self._consume_start_line(scanner, tok)
                tok = values.pop(0)
                header = BSON(zip([u'date', u'OS', u'kernel', u'host', u'arch', u'cores'], values))
                header.pop(u'date')
                tok = self._consume_to_eol(scanner, tok)
                yield BSON(header)
            elif tok == scanner.TokTimestamp:
                tok, ts = self._consume_timestamp(scanner, tok)
                tok = scanner.scan()
                _, tok = self._skip_to_start(scanner, tok)
                tok, report = self._consume_cpu_report(scanner, tok)
                report = [(u'time', ts), (u'type', u'cpu')] + report # + [('filename', p.Filename), ('line', p.Line)]
                yield BSON(report)

            elif tok == scanner.TokDeviceReport:
                tok, header = self._consume_device_report_header(scanner, tok)
                assert tok == scanner.TokEOL

                tok = scanner.scan()
                while tok == scanner.TokDeviceReportValue:
                    tok, device, values = self._consume_device_report(scanner, tok)
                    assert tok == scanner.TokEOL

                    report = [(u'time', ts), (u'type', u'device'), (u'device', device)] + zip(header, values) # + \
                             # [('filename', p.Filename), ('line', p.Line)]
                    yield BSON(report)
                    tok = scanner.scan()

                if scanner.TokEOF == tok:
                    break
                else:
                    p, tok = self._skip_to_start(scanner, tok)
                    continue

                # tok = self._consume_to_eol(scanner, tok)
                # js[u'pos'] = {'filename': p.Filename, 'line': p.Line, 'offset': p.Offset, 'column': p.Column}
                # v = js
                #
                # self.logger.info(json.dumps(v, indent=3, default=JsonTranslater.translate))
                #
                # v = flatten(js, BSON(), singular=singular) if flat else js
                # yield v
                # if scanner.TokEOF == tok:
                #     break
                # else:
                #     js = BSON()
                #     if len(s):
                #         js[u'os'] = s
                #     p, tok = self._skip_to_start(scanner, tok)
                #     continue

            else:
                tok = self._consume_to_eol(scanner, tok)
                js[u'line'] = scanner.line()

            assert scanner.TokEOL == tok  # scanner.scan()
        self.logger.info('done')

    @property
    def metrics(self):
        return self.scan()

    def scan(self, flat=True):
        if self._stats is None:
            current = IoStatMetric()
            for ss in self.iscan(flat=flat, singular=True):
                current.add_metrics(ss)
            self._stats = current
        return self._stats


Archive.add(IoStatArchive)
