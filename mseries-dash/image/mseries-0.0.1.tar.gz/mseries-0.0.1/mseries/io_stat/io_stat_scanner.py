"""
Provides functions to read FTDC data from either an FTDC file or from
a file containing serverStatus JSON documents, one per line. Each
reader takes a filename argument and returns a generator that yields a
sequence of chunks. Each chunk is a map from tuples keys to lists, where
the tuple key represents a path through a JSON document from root to leaf,
and the list is a list of values for that path.
"""

from collections import OrderedDict
import json
from mseries.scanner.scanner import Scanner, seq, Redo, Token


class IoStatScanner(Scanner):
    # maybe TokAssign or sep would be better as it could also be a =
    TokOs = Token(next(seq), name='OS')
    TokKernelVersion = Token(next(seq), name='Kernel')
    TokHostname = Token(next(seq), name='hostname')
    TokDate = Token(next(seq), name='date')
    TokArch = Token(next(seq), name='arch')
    TokCores = Token(next(seq), name='cores')
    TokTimestamp = Token(next(seq), name='Timestamp')
    TokCpuReport = Token(next(seq), name='Cpu Report')
    TokCpuReportHeader = Token(next(seq), name='Cpu Report Header')
    TokCpuReportValue = Token(next(seq), name='Cpu Report Value')
    TokDeviceReport = Token(next(seq), name='Device Report')
    TokDeviceReportHeader = Token(next(seq), name='Device Report Header')
    TokDeviceReportValue = Token(next(seq), name='Device Report Value')

    ScanOs = 1 << TokOs
    ScanKernelVersion = 1 << TokKernelVersion
    ScanHostname = 1 << TokHostname
    ScanDate = 1 << TokDate
    ScanArch = 1 << TokArch
    ScanCores = 1 << TokCores
    ScanTimestamp = 1 << TokTimestamp
    ScanCpuReport = 1 << TokCpuReport
    ScanCpuReportHeader = 1 << TokCpuReportHeader
    ScanCpuReportValue = 1 << TokCpuReportValue
    ScanDeviceReport = 1 << TokDeviceReport
    ScanDeviceReportHeader = 1 << TokDeviceReportHeader
    ScanDeviceReportValue = 1 << TokDeviceReportValue

    ModeStrings = {
        ScanOs: repr(TokOs),
        ScanKernelVersion: repr(TokKernelVersion),
        ScanHostname: repr(TokHostname),
        ScanDate: repr(TokDate),
        ScanArch: repr(TokArch),
        ScanCores: repr(TokCores),
        ScanTimestamp: repr(TokTimestamp),
        ScanCpuReport: repr(TokCpuReport),
        ScanCpuReportHeader: repr(TokCpuReportHeader),
        ScanCpuReportValue: repr(TokCpuReportValue),
        ScanDeviceReport: repr(TokDeviceReport),
        ScanDeviceReportHeader: repr(TokDeviceReportHeader),
        ScanDeviceReportValue: repr(TokDeviceReportValue),
    }
    ModeStrings.update(Scanner.ModeStrings)

    GoTokens = Scanner.GoTokens | Scanner.ScanStart
    ScanStarting = Scanner.ScanStarting | ScanTimestamp | ScanOs | ScanCpuReport | ScanDeviceReport | ScanOs

    def __init__(self, filename, encoding='utf-8', sz=16381):
        Scanner.__init__(self, filename, encoding=encoding, sz=sz, name=__name__)

    def to_json(self):
        doc = OrderedDict([
            ('srcBuf', len(self.src_buf)),
            ('srcPos', self.src_pos),
            ('srcEnd', self.src_end),
            ('tokPos', self.tok_pos),
            ('tokEnd', self.tok_end),
            ('srcBufOffset', self._src_buf_offset),
            ('mode', self.mode_to_string(self.mode)),
            ('line', self._current_line),
            ('lineBuf', self._line_buf),
        ])
        return json.dumps(doc, indent=3)

    def is_valid(self):
        tok = self.scan(limit=2048)
        return tok == self.TokStartBracket

    def scan(self, limit=None, error=None, flat=False, hungry=False):
        terror, self.error = error, self.error
        ch = self.peek()
        redo = 0
        l = self._limit
        try:
            self._limit = limit

            while True:
                try:
                    self.tok_pos = -1
                    self._current_line = 0
                    if ch == u'\n':
                        self._line_buf = u''

                        # start collecting token text
                        ch = self.next()
                        if ch == self.EOF:
                            return self.TokEOF

                        self._current_line = self._line
                        self.mode |= self.ScanStarting
                        return self.TokEOL

                    if self._column > 1:
                        ch = self.skip_whitespace(ch, m=self.NoGoWhitespace)

                    # start collecting token text
                    self.tok_buf = u''
                    self.tok_pos = self.src_pos - self._last_char_len

                    # set token position
                    # (this is a slightly optimized version of the code in Pos())
                    self.offset = self._src_buf_offset + self.tok_pos
                    if self._column > 0:
                        # common case: last character was not a '\n'
                        self._current_line = self._line
                        self.column = self._column
                    else:
                        # last character was a '\n'
                        # (we cannot be at the beginning of the source
                        # since we have called next() at least once)
                        self._current_line = self._line - 1
                        self.column = self._last_line_len

                    # determine token value
                    tok = ch
                    if self.is_ident(ch, 0):

                        if self.mode & self.ScanDeviceReportValue != 0:
                            tok, ch = self.scan_device_report_value(ch)
                        elif self.mode & (self.ScanCpuReport | self.ScanDeviceReport | self.ScanOs) != 0:
                            txt, end = self.peek_to_rune(u':')
                            if txt == u'avg-cpu':
                                tok, ch = self.scan_cpu_report(ch)
                            elif txt == u'Device':
                                tok, ch = self.scan_device_report(ch)
                            elif txt.startswith(u'Linux'):
                                tok, ch = self.scan_os(ch)
                            else:
                                ch = self.next()
                        elif self.mode & self.ScanDeviceReportHeader != 0:
                            tok, ch = self.scan_device_report_header(ch)
                        elif self.mode & self.ScanDeviceReportValue != 0:
                            tok, ch = self.scan_device_report_value(ch)
                        elif self.mode & self.ScanArch != 0:
                            tok, ch = self.scan_arch(ch)
                        else:
                            ch = self.next()
                    elif self.is_decimal(ch):
                        if self.mode & self.ScanKernelVersion != 0:
                            tok, ch = self.scan_kernel(ch)
                        elif self.mode & self.ScanCpuReportValue != 0:
                            tok, ch = self.scan_cpu_report_value(ch)
                        elif self.mode & (self.ScanDeviceReportValue | self.ScanStart) != 0:
                            p = self.peek(offs=2)
                            if p != u'/':
                                tok, ch = self.scan_device_report_value(ch)
                            else:
                                tok, ch = self.scan_timestamp(ch)
                        # elif self.mode & self.ScanStart != 0:
                        #     tok, ch = self.scan_timestamp(ch)
                        elif self.mode & self.ScanDate != 0:
                            tok, ch = self.scan_date(ch)
                        else:
                            ch = self.next()
                    elif ch == u'(':
                        if self.mode & self.ScanHostname != 0:
                            tok, ch = self.scan_hostname(ch)
                        elif self.mode & self.ScanCores != 0:
                            tok, ch = self.scan_cores(ch)
                        else:
                            ch = self.next()
                    elif ch == u'%':
                        peek, end = self.peek_to_rune(u'\n')

                        if peek.startswith('%util') and self.mode & self.ScanDeviceReportHeader != 0:
                            tok, ch = self.scan_device_report_header(ch)
                        elif self.mode & self.ScanCpuReportHeader != 0:
                            tok, ch = self.scan_cpu_report_header(ch)
                        else:
                            ch = self.next()
                    elif ch == u' ':
                        if self.mode & self.ScanCpuReportValue != 0:
                            tok, ch = self.scan_cpu_report_value(ch)
                        else:
                            ch = self.next()
                    else:
                        if ch == self.EOF:
                            tok = self.TokEOF
                        elif ch == u'\n':
                            tok = self.TokEOL
                        else:
                            ch = self.next()

                    self.tok_end = self.src_pos - self._last_char_len
                    if ch == u'\n' and tok == self.TokDeviceReportHeader:
                        self.mode = self.ScanDeviceReportValue

                    if tok == self.TokEOL:
                        self.mode |= self.ScanStarting

                    self.ch = ch
                    # self.logger.info("current token %s, next char='%s'", self.token_to_string(tok), self.tr(self.ch))
                    self.logger.info("mode %s ", self.mode_to_string(self.mode))
                    return tok

                except Redo as e:
                    if redo > 10:
                        raise e
                    self.logger.debug("Redo start", exc_info=1)
                    self._line -= 1
                    redo += 1
                    if self.tok_pos > 0:
                        d = self.src_pos - self.tok_end
                        self.src_pos = self.tok_end
                        self._column -= d
                        ch = self.next()
        finally:
            self._limit = l
            self.error = terror

    def scan_kernel(self, ch):
        self.logger.debug("scan_kernel %s", ch)

        def is_kernel_rune(c, i):
            return c == '-' or c == '_' or c == '.' or c.isalpha() or c.isdigit() and i > 0

        ch = self._scan_identifier(m=is_kernel_rune)
        text = self._text().rstrip(u' ')
        self.logger.debug("scan_kernel %s", text)
        self.mode = self.ScanHostname
        return self.TokKernelVersion, ch

    def scan_hostname(self, ch):
        self.logger.debug("scan_hostname %s", ch)

        def is_hostname_rune(c, i):
            return c == '(' or c == '.' or c == '-' or c == ')' or c.isalpha() or c.isdigit() and i > 0

        ch = self._scan_identifier(m=is_hostname_rune)
        text = self._text().rstrip(u' ')
        self.logger.debug("scan_hostname %s", text)
        self.mode = self.ScanDate
        return self.TokHostname, ch

    def scan_date(self, ch):
        self.logger.debug("scan_date %s", ch)

        def is_date_rune(c, i):
            return c == '/' or c.isdigit() and i > 0

        ch = self._scan_identifier(m=is_date_rune)
        text = self._text().rstrip(u' ')
        self.logger.debug("scan_date %s", text)
        self.mode = self.ScanArch
        return self.TokDate, ch

    def scan_arch(self, ch):
        self.logger.debug("scan_arch %s", ch)

        def is_arch_rune(c, i):
            return c == '_' or c.isdigit()  or c.isalpha() and i > 0

        ch = self._scan_identifier(m=is_arch_rune)
        text = self._text().rstrip(u' ')
        self.logger.debug("scan_arch %s", text)
        self.mode = self.ScanCores
        return self.TokArch, ch

    def scan_cores(self, ch):
        self.logger.debug("scan_cores %s", ch)

        ch = self._scan_to(ch, u'\n')
        text = self._text().rstrip(u' \n')
        self.logger.debug("scan_cores %s", text)
        self.mode = self.ScanStart
        return self.TokCores, ch

    def scan_timestamp(self, ch):
        self.logger.debug("scan_timestamp %s", ch)

        ch = self._scan_to(ch, u'\n')
        text = self._text().rstrip(u' \n')
        self.logger.debug("scan_timestamp %s", text)
        self.mode = self.ScanStart | self.ScanCpuReport | self.ScanDeviceReport
        return self.TokTimestamp, ch

    def scan_os(self, ch):
        self.logger.debug("scan_starting %s", ch)

        ch = self._scan_identifier()
        text = self._text().rstrip(u' ')
        if text == u'Linux':
            self.mode = self.ScanKernelVersion
            return self.TokOs, ch
        elif text == u'avg-cpu:':
            ch = self.next()
            self.mode = self.ScanCpuReportHeader
            return self.TokCpuReport, ch
        else:
            self._scan_to(ch, u'\n')
            return self.TokIgnore, ch

    def scan_cpu_report(self, ch):
        self.logger.debug("scan_cpu_report %s", ch)

        def is_cpu_report_rune(c, i):
            return c == u'-' or c == u':' or c.isalpha() and i > 0

        ch = self._scan_identifier(m=is_cpu_report_rune)
        text = self._text().rstrip(u' :')
        if text == u'avg-cpu':
            self.mode = self.ScanCpuReportHeader
            return self.TokCpuReport, ch
        else:
            ch = self._scan_to(ch, u'\n')
            return self.TokIgnore, ch

    def scan_cpu_report_header(self, ch):
        self.logger.debug("scan_cpu_report_header %s", ch)

        def scan_cpu_report_header(c, i):
            return c == u'%' or c.isalpha() and i > 0

        ch = self._scan_identifier(m=scan_cpu_report_header)
        text = self._text().rstrip(u' :')
        self.logger.debug("scan_cpu_report_header %s", text)
        self.mode = self.ScanCpuReportHeader | self.ScanCpuReportValue
        return self.TokCpuReportHeader, ch

    def scan_cpu_report_value(self, ch):
        self.logger.debug("scan_cpu_report_value %s", ch)

        self.skip_whitespace(ch, m=self.NoGoWhitespace)

        def scan_cpu_report_value(c, i):
            return c == u'.' or c.isdigit() and i > 0

        ch = self._scan_identifier(m=scan_cpu_report_value)
        text = self._text().strip(u' ')
        self.logger.debug("scan_cpu_report_value %s", text)
        self.mode = self.ScanCpuReportValue
        return self.TokCpuReportValue, ch

    def scan_device_report(self, ch):
        self.logger.debug("scan_device_report%s", ch)

        def is_device_report_rune(c, i):
            return c == u'-' or c == u':' or c.isalpha() and i > 0

        ch = self._scan_identifier(m=is_device_report_rune)
        text = self._text().rstrip(u' ')
        if text == u'Device:':
            self.mode = self.ScanDeviceReportHeader
            return self.TokDeviceReport, ch
        else:
            ch = self._scan_to(ch, u'\n')
            return self.TokIgnore, ch

    def scan_device_report_header(self, ch):
        self.logger.debug("scan_device_report_header %s", ch)

        def scan_device_report_header(c, i):
            return c == u'%' or c == u'/' or c == u'-' or c.isalpha() and i > 0

        ch = self._scan_identifier(m=scan_device_report_header)
        # ch = self.next()
        text = self._text().rstrip(u' :')
        self.logger.debug("scan_device_report_header %s", text)
        self.mode = self.ScanDeviceReportHeader
        return self.TokDeviceReportHeader, ch

    def scan_device_report_value(self, ch):
        self.logger.debug("scan_device_report_value %s", ch)

        self.skip_whitespace(ch, m=self.NoGoWhitespace)

        def scan_device_report_value(c, i):
            return c == u'.' or c == u'-' or c.isdigit() or c.isalpha() and i > 0

        ch = self._scan_identifier(m=scan_device_report_value)
        text = self._text().strip(u' ')
        self.logger.debug("scan_device_report_value %s", text)
        self.mode = self.ScanDeviceReportValue
        return self.TokDeviceReportValue, ch
