#include <stdio.h>
#include "Python.h"
#include "rle.h"


static PyObject* _py_unpack(PyObject* self, PyObject* args) {
  const unsigned char*     rle=0;
  int64_t   rlesize=0;
  int64_t   start=0;
  int64_t*  sample=0;
  int64_t   samplesize=0;
  int64_t   ndocs=0; /* number of docs to fill */
  int64_t   nmetrics=0; /* number of fields / doc */
  int64_t*  deltas=0;
  int64_t   transpose=1;
  int64_t   rate=1;
  size_t    sz=0;
  PyObject* ret=0;

  info("%s starting\n", __func__);
  if (!PyArg_ParseTuple(args, "z#liiz#|il",&rle, &rlesize, &start, &ndocs, &nmetrics, &sample, &samplesize, &transpose, &rate)) {
    return NULL;
  }

  if(samplesize == 0) {
    sample = 0;
  }

//  Py_BEGIN_ALLOW_THREADS
  deltas = _unpack_all_and_fill(rle, rlesize, &sz, &start, ndocs, nmetrics, sample, transpose, rate);
//  Py_END_ALLOW_THREADS
  ret = Py_BuildValue("z#i", deltas, sz , start);

  if(deltas) {
    free(deltas);
  }

  return ret;
}

static char unpack_doc_string[] =
"native function to unpack run length encoded data from `buf`, starting from location `at`\n"
"\n"
"\n"
"        :Parameters:\n"
"          - `buf`: the buffer containing the data\n"
"          - `at`: the location in the buffer\n"
"          - `ndocs`: the number of docs\n"
"          - `nmetrics`: the number of metrics\n"
"          - `sample`: the packed reference sample\n"
"          - `transpose`: return an array of docs or an array of property\n"
"          - `rate`: the sample rate, -1 => only return the last sample\n";


static PyMethodDef RleMethods[] = {
  {"unpack", _py_unpack, METH_VARARGS, unpack_doc_string},
  {NULL, NULL, 0, NULL}
};

PyMODINIT_FUNC
initrle(void)
{
  info("%s STARTING\n", __func__);
  (void) Py_InitModule("mseries.native.rle", RleMethods);
}
