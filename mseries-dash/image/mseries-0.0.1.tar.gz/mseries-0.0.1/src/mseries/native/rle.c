#include <stdio.h>
#include <stdlib.h>
#include "Python.h"
#include "rle.h"

#define handle_pack_error(limit, ptr)                                   \
  do { if ((limit) && (ptr) >= (limit)) {fprintf(stderr, "Limit error: %s:%d.",__FILE__, __LINE__);  return 0;} } while (0)

static inline int64_t _unpack_unrolled(const unsigned char *data, int64_t *at, const unsigned char *limit);

int64_t _unpack_unrolled(const unsigned char *data, int64_t *at, const unsigned char *limit) {
  uint64_t b, result;
  unsigned char *ptr = (unsigned char *)(data + *at);

  handle_pack_error(limit, ptr);
  b = *(ptr++);
  result = b & 127;
  if (b < 128)
    goto gift_shop;

  handle_pack_error(limit, ptr);
  b = *(ptr++);
  result |= (b & 127) << 7;
  if (b < 128)
    goto gift_shop;

  handle_pack_error(limit, ptr);
  b = *(ptr++);
  result |= (b & 127) << 14;
  if (b < 128)
    goto gift_shop;

  handle_pack_error(limit, ptr);
  b = *(ptr++);
  result |= (b & 127) << 21;
  if (b < 128)
    goto gift_shop;

  handle_pack_error(limit, ptr);
  b = *(ptr++);
  result |= (b & 127) << 28;
  if (b < 128)
    goto gift_shop;

  handle_pack_error(limit, ptr);
  b = *(ptr++);
  result |= (b & 127) << 35;
  if (b < 128)
    goto gift_shop;

  handle_pack_error(limit, ptr);
  b = *(ptr++);
  result |= (b & 127) << 42;
  if (b < 128)
    goto gift_shop;

  handle_pack_error(limit, ptr);
  b = *(ptr++);
  result |= (b & 127) << 49;
  if (b < 128)
    goto gift_shop;

  handle_pack_error(limit, ptr);
  b = *(ptr++);
  result |= (b & 127) << 56;
  if (b < 128)
    goto gift_shop;

  handle_pack_error(limit, ptr);
  b = *(ptr++);
  result |= (b & 127) << 63;
  if (b < 2)
    goto gift_shop;
  return 0;
 //exit through the ...
 gift_shop:
  *at = ptr - data;
  return result;
}

/**
 * unpack the run length encoded in one go and fill with the correct values
 *
 * @param rle the array containing the RLE'ed data
 * @param start the stating position in rle
 * @param sample array of starting samples
 * @param ndocs the total number of docs to fill
 * @param nmetrics the number of metrics / doc
 * @param transpose true to transpose data
 * @param rate the sample rate, i.e. 1 in rate. If rate <=0 or rate > ndocs null is returned
 *        and the start position is unchanged. The samples are rounded up. Ona rate of 149
 *        with 150 docs this produces 2 docs. If rate is less than 1 or rate > ndocs, NULL is
 *        returned
 *
 * if transpose is false then ...
 *
 * there are nmetrics rows of ndocs columns:
 * pos = row * ndocs + col
 *
 * if transpose = true then ...
 *
 * there are nmetrics rows of ndocs columns
 * pos = row * nmetrics + col
 *
 * @return deltas (caller is responsible for free'ing)
 */
int64_t* _unpack_all_and_fill(const unsigned char * rle, int64_t rlesize, size_t *size, int64_t *start, int64_t ndocs, int64_t nmetrics ,int64_t *sample ,int64_t transpose, int64_t rate) {
    int64_t  delta = 0;
    int64_t* deltas;
    int64_t  current;
    int64_t  zero = 0;
    int64_t  d = 0; /* current doc */
    int64_t  m = 0; /* current metric */
    int64_t  docs =0;
    size_t   sz = 0;

    *size = 0;
    if(rate != -1 && (rate <= 0 || rate > ndocs) ) {
        return NULL;
    }

    docs = DIV_ROUND_INT(ndocs , abs(rate));
    *size = sz = docs * nmetrics  * sizeof(int64_t);

    deltas = (int64_t*)malloc(sz);
    if(!deltas){
        return 0;
    }

    int64_t o =0;
    for(m = 0; m < nmetrics; m++) {
        current = SAMPLE(sample,m);
        for(d = 0; d < ndocs ; d++) {
            if (zero) {
                delta = 0;
                zero--;
            } else {
              delta = _unpack_unrolled(rle, start, rle + rlesize);
                if (!delta) {
                  zero = _unpack_unrolled(rle, start, rle + rlesize);
                }
            }

            if(sample) {
                current += delta;
            } else {
                current = delta;
            }

            if ((rate == -1 && d == ndocs -1) || d % rate == 0) {
                if (transpose) {
                    o = ((d * nmetrics) / abs(rate)) + m;
                } else {
                    o = (m * docs) + (d / abs(rate)); // this is actually just pos
                }
                deltas[o] = current;
            }
        }
    }
    return deltas;
}
