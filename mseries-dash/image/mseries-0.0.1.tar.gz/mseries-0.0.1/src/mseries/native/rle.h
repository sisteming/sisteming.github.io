#define MASK  0x7F
#define MORE  0x80
#define SHIFT    7

// #define DEBUG 0
// #define INFO  1

#ifndef  DEBUG
#define  DEBUG 0
#endif

#define debug(fmt, ...) do { if (DEBUG) fprintf(stderr, fmt, __VA_ARGS__); } while (0)

#ifndef  INFO
#define  INFO 0
#endif

#define info(fmt, ...) do { if (INFO) printf(fmt, __VA_ARGS__); } while (0)

#define SAMPLE(s,p) (s ? s[p] : 0)
#define DIV_ROUND_INT(n,d) ((n + d -1) / d)

int64_t* _unpack_all_and_fill(const unsigned char * rle, int64_t rlesize, size_t *size, int64_t *start, int64_t ndocs, int64_t nmetrics ,int64_t *sample ,int64_t transpose, int64_t rate);
