#!/usr/bin/env python

import os
import re
import sys

from codecs import open

from setuptools import setup
from setuptools.command.test import test as TestCommand
from distutils.core import Extension


class PyTest(TestCommand):
    user_options = [('pytest-args=', 'a', "Arguments to pass into py.test")]

    def initialize_options(self):
        TestCommand.initialize_options(self)
        self.pytest_args = []

    def finalize_options(self):
        TestCommand.finalize_options(self)
        self.test_args = []
        self.test_suite = True

    def run_tests(self):
        import pytest

        errno = pytest.main(self.pytest_args)
        sys.exit(errno)


#
# generate tarball in sdist dir and install with:
#
#   $ python setup.py sdist
#   $ pip install ./dist/mseries-0.0.0.dev0.tar.gz
#
# may also require  --upgrade
#
#   $ pip install -r requirements.txt
#   $ pip install ./dist/mseries-0.0.0.dev0.tar.gz --upgrade
# Or
#
#   $ python setup.py develop
#
# Then run the following when finished:
#
#   $ python setup.py develop --uninstall
#
#
if sys.argv[-1] == 'publish':
    os.system('python setup.py sdist upload')
    sys.exit()

packages = [
    'mseries',
    'mseries.archive',
    'mseries.backup_agent',
    'mseries.ftdc',
    'mseries.io_stat',
    'mseries.native',
    'mseries.mongo_stat',
    'mseries.pipelines',
    'mseries.renderers',
    'mseries.scanner',
    'mseries.server_status',
    'mseries.tasks',
    'mseries.tools',
    'mseries.types',
    'mseries.utils',
    'mseries.writers',
]

# http://stackoverflow.com/questions/14399534/how-can-i-reference-requirements-txt-for-the-install-requires-kwarg-in-setuptool
# but apparently not a good idea
#
# from pip.req import parse_requirements
# requires = [str(ir.req) for ir in parse_requirements('requirements.txt', session='hacky')]

# there is a lot of date parsing, need to rationalize at some point
requires = ['progressbar2==3.12.0',
            'hexdump==3.3',
            'pymongo==3.4.0',
            'docopt==0.6.2',
            'retrying==1.3.3',
            'humanfriendly==2.3.2',
            'python-dateutil==2.6.0',
            'pytz==2016.10',
            'parsedatetime==2.1',
            'dateparser==0.5.1',
            ]

test_requirements = ['pytest>=2.8.0', 'pytest-httpbin==0.0.7', 'pytest-cov', 'nose', 'mock', 'hexdump', 'pylint', 'tox']

with open('mseries/__init__.py', 'r') as fd:
    __version__ = re.search(r'^__version__\s*=\s*[\'"]([^\'"]*)[\'"]',
                            fd.read(), re.MULTILINE).group(1)

if not __version__:
    raise RuntimeError('Cannot find version information')

with open('README.rst', 'r', 'utf-8') as f:
    readme = f.read()
with open('HISTORY.rst', 'r', 'utf-8') as f:
    history = f.read()

long_description = readme + '\n\n' + history

config = {
    'name': 'mseries',
    'version': __version__,
    'description': 'FTDC parser.',
    'long_description': long_description,
    'author': 'Jim OLeary',
    'author_email': 'jim.oleary@gmail.com',
    'url': 'https://github.com/10gen/support-tools/mseries',
    'packages': packages,
    'package_data': {'': ['LICENSE', 'NOTICE'], 'requests': ['*.pem']},
    'data_files': [('config', ['config/logging.ini'])],
    'entry_points': {
        "console_scripts": [
            "mseries=mseries.tools:main",
            "mseries-scan=mseries.tools:scan",
            "mseries-expand=mseries.tools:expand",
            "mseries-write=mseries.tools:write",
            "mseries-test=mseries.tools:test",
        ],
    },
    'package_dir': {'mseries': 'mseries'},
    'include_package_data': True,
    'install_requires': requires,
    'license': 'Apache 2.0',
    'zip_safe': False,
    'classifiers': (
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Natural Language :: English',
        'License :: OSI Approved :: Apache Software License',
        'Programming Language :: Python',
        'Programming Language :: Python :: 2 :: Only',
        'Programming Language :: Python :: 2.7',
        # 'Programming Language :: Python :: 3',
        # 'Programming Language :: Python :: 3.3',
        # 'Programming Language :: Python :: 3.4',
        # 'Programming Language :: Python :: 3.5',
        # 'Programming Language :: Python :: Implementation :: CPython',
        # 'Programming Language :: Python :: Implementation :: PyPy'
        # not working on pypy some error relating to bdist wheel
    ),
    'cmdclass': {'test': PyTest},
    'tests_require': test_requirements,
    'ext_modules':[Extension('mseries.native.rle', ['src/mseries/native/rle.c', 'src/mseries/native/wrap_rle.c'])]

}
setup(**config)
